%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         Decentralized Random-field Estimation for Sensor Networks                   %
%   Using Quantized Spatially Correlated Data and Fusion-center Feedback      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Linear trend case (Prediction)
%Fig.14 in the paper

 clear all;
 clc;

pdf_Nstd=inline('exp(-x.^2/2)/sqrt(2*pi)');
cdf_Nstd=inline('1-0.5*erfc(x/sqrt(2))');
invcdf_Nstd=inline('sqrt(2)*erfcinv(2*(1-x))');
load NodeLocationSlope.mat

%Parameters
L=1;                                %Number of trials
phi=0.5;                          %Field correlation strength
K=3;                                %Number of quantization levels
p_iteration=3;                  %Number of rounds
T=50;                               %number of MC samples
sigma2=1;                       %variance of noise
N=10;                               %Number of sensor nodes
Region_len=10;              %length of region
Scale=0.1;                       %density of the points to be predicted
M=(Region_len/Scale)^2-N-1;%Number of points to be predicted
%Prior specification
mu_alpha=zeros(3,1);
sigma2_alpha=[1,0,0;0,1,0;0,0,1];

Node_loc=Node_loc-Region_len/2;
H=[ones(N+1,1),Node_loc];

%Generate node Cov_Mtrx structure    
for mm=1:(N+1)
    for nn=1:(N+1)
        Cov_Mtrx(mm,nn)=sigma2*exp(-phi*distance(v_loc(mm,:),v_loc(nn,:)));
    end
end
Sigma=H*sigma2_alpha*H'+Cov_Mtrx;
Cov_yy=Sigma(1:N,1:N);
Syz=Sigma(1:N,N+1);
Segmaz=Sigma(N+1,N+1);
S=Cov_yy-(Syz*Syz')/Segmaz;
S_chol=(chol(S))';                     %Cholesky decomposition
S_chol_inv=inv(S_chol);
Cov_Mtrx_Inv=inv(Cov_Mtrx);
Omega=inv(inv(sigma2_alpha)+H'*Cov_Mtrx_Inv*H);
Omega_chol=(chol(Omega))';
%Generate entire field and entire Cov structure
space_loc=v_loc;
space_index=N+2;
space_flag=0;
for mm=0:(Region_len/Scale-1)
    for nn=0:(Region_len/Scale-1)
        space_flag=0;
        space_loc(space_index,:)=[nn*Scale,mm*Scale];
        for ll=1:(N+1)
            if space_loc(space_index,1)==v_loc(ll,1)&&space_loc(space_index,2)==v_loc(ll,2)
                space_flag=1;
            end
        end
        if space_flag==0
            space_index=space_index+1;
        end
    end
end
H_pred=[ones(M,1),space_loc(N+2:N+M+1,:)-5];
H_tot=[H;H_pred];

%Cov_ypre_v is recorded.
Q=H_pred-Cov_ypre_v*Cov_Mtrx_Inv*H;
W=[Q,Cov_ypre_v*Cov_Mtrx_Inv];

%Generate the diagonal of Cov_Pred
Delta_Cov_Mtrx_inv=Cov_ypre_v*Cov_Mtrx_Inv;
for nn=(N+2):(N+M+1)
     Cov_Pred_diag(nn-N-1,:)=sigma2-Delta_Cov_Mtrx_inv(nn-N-1,:)*Cov_ypre_v(nn-N-1,:)';
     Var_yPred_v(nn-N-1,:)=(H_pred(nn-N-1,:)'-H'*Cov_Mtrx_Inv*Cov_ypre_v(nn-N-1,:)')'*Omega*(H_pred(nn-N-1,:)'-H'*Cov_Mtrx_Inv*Cov_ypre_v(nn-N-1,:)')+Cov_Pred_diag(nn-N-1,:);
end
clear Delta_Cov_Mtrx_inv;
Cov_Complete=[zeros(N+1,1);Var_yPred_v];
MSE_recover=zeros(N+M+1,p_iteration);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for ii=1:L    
    %True parameter
    alpha(:,ii)=[0;2;-1];
    %Generate the measurement of the field
    X=ExpCorRandnFieldfcn(Region_len,Region_len,Scale,0,sigma2,phi);
    for mm=1:(N+M+1)
        e_tot(mm,:)=X(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1);
    end
    
    y_tot=H_tot*alpha(:,ii)+e_tot;
    V=y_tot(1:N+1);
    y=V(1:N);                                   %Observations by node
    z=V(N+1);                                  %Observation by fusion center
     
    m=H(1:N,:)*mu_alpha+(1/Segmaz)*Syz*(z-H(N+1,:)*mu_alpha);
    Linv_Mu=S_chol_inv*m;    
    
    %%%%%%%%Feedback method%%%%%%
    %Round 0
    C_fb{1}=sigma2_alpha-sigma2_alpha*(H(N+1,:))'*H(N+1,:)*sigma2_alpha/(Cov_Mtrx(N+1,N+1)+H(N+1,:)*sigma2_alpha*(H(N+1,:))');
    alpha_fb(:,1)=C_fb{1}*(inv(sigma2_alpha)*mu_alpha+(H(N+1,:))'*z/Segmaz);
    y_left=-inf*ones(N,1);
    y_right=inf*ones(N,1);

    for pp=1:p_iteration
        for nn=1:N
            r(pp,nn)=H(nn,:)*C_fb{pp}*H(nn,:)'+Cov_Mtrx(nn,nn);
            threshold_Gibbs(nn,1)=y_left(nn);
            threshold_std(nn,1)=(threshold_Gibbs(nn,1)-H(nn,:)*alpha_fb(:,pp))/sqrt(r(pp,nn));
            thresh_step_std=(cdf_Nstd((y_right(nn)-H(nn,:)*alpha_fb(:,pp))/sqrt(r(pp,nn)))-cdf_Nstd((y_left(nn)-H(nn,:)*alpha_fb(:,pp))/sqrt(r(pp,nn))))/K;
            thresh_value_std(nn,1)=cdf_Nstd(threshold_std(nn,1));
            for kk=2:K %each node find its thresholds
                 thresh_value_std(nn,kk)=thresh_value_std(nn,kk-1)+thresh_step_std;
                 threshold_std(nn,kk)=invcdf_Nstd(thresh_value_std(nn,kk));
                 threshold_Gibbs(nn,kk)=H(nn,:)*alpha_fb(:,pp)+sqrt(r(pp,nn))*threshold_std(nn,kk);
            end
            threshold_Gibbs(nn,K+1)=y_right(nn);
            threshold_std(nn,K+1)=(threshold_Gibbs(nn,K+1)-H(nn,:)*alpha_fb(:,pp))/sqrt(r(pp,nn));
            %Decide k value of each node
            k(nn)=1;
            while y(nn)>threshold_Gibbs(nn,k(nn))
                k(nn)=k(nn)+1;
            end
            y_left(nn)=max(threshold_Gibbs(nn,(k(nn)-1)),y_left(nn));
            y_right(nn)=min(threshold_Gibbs(nn,k(nn)),y_right(nn));
        end
        %Sample and fusion
        for tt=1:T
            xx=zeros(N,1);
            for mm=1:N
                z_left(mm)=(y_left(mm)-S_chol(mm,:)*xx-Linv_Mu(mm)*S_chol(mm,mm))/S_chol(mm,mm);
                z_right(mm)=(y_right(mm)-S_chol(mm,:)*xx-Linv_Mu(mm)*S_chol(mm,mm))/S_chol(mm,mm);
                zz(mm)=RejSample(z_left(mm),z_right(mm));
                xx(mm)=Linv_Mu(mm)+zz(mm);
            end
            yy(:,tt)=S_chol*xx;
            VV(:,tt)=[yy(:,tt);z];
            VV_2(:,:,tt)=VV(:,tt)*VV(:,tt)';
        end
        y_fb(:,pp)=sum(yy,2)/T;
        v_fb=[y_fb(:,pp);z];
        v_2_fb=sum(VV_2,3)/T;        
        SampleCov_v=v_2_fb-v_fb*v_fb';
        alpha_fb(:,pp)=Omega*inv(sigma2_alpha)*mu_alpha+Omega*H'*Cov_Mtrx_Inv*v_fb;
        y_pred(:,pp)=W*[alpha_fb(:,pp)',v_fb']';
        y_recover(:,pp)=[y_fb(:,pp);z;y_pred(:,pp)]; 
        for nn=(N+2):(N+M+1)
            Sample_Var_pred(nn-N-1,:)=(H_pred(nn-N-1,:)'-H'*Cov_Mtrx_Inv*Cov_ypre_v(nn-N-1,:)')'*Omega*(H_pred(nn-N-1,:)'-H'*Cov_Mtrx_Inv*Cov_ypre_v(nn-N-1,:)')+Cov_Pred_diag(nn-N-1,:)+(H*Omega*(H_pred(nn-N-1,:)'-H'*Cov_Mtrx_Inv*Cov_ypre_v(nn-N-1,:)')+Cov_ypre_v(nn-N-1,:)')'*Cov_Mtrx_Inv*(SampleCov_v)*Cov_Mtrx_Inv*(H*Omega*(H_pred(nn-N-1,:)'-H'*Cov_Mtrx_Inv*Cov_ypre_v(nn-N-1,:)')+Cov_ypre_v(nn-N-1,:)');
        end
        Sample_Var_tot(:,pp)=[diag(SampleCov_v);Sample_Var_pred];
        alpha_fb(:,pp+1)=alpha_fb(:,pp);
        error_y_fb(pp,ii)=(norm(y_fb(:,pp)-y))^2;
        %FC feedback
        error_alpha_fb{pp,ii}=(alpha_fb(:,pp)-alpha(:,ii)).^2;
        C_fb{pp+1}=Omega+Omega*H'*Cov_Mtrx_Inv*(v_2_fb-v_fb*v_fb')*Cov_Mtrx_Inv*H*Omega;          
    end
    alpha_mmse=Omega*inv(sigma2_alpha)*mu_alpha+Omega*H'*Cov_Mtrx_Inv*V;
    error_alpha_mmse{ii}=(alpha_mmse-alpha(:,ii)).^2;
    error_alpha_mmse_theo{ii}=diag(Omega);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                  Plotting          %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
for mm=1:(N+M+1)
       y_recover_img_p1(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1)=y_recover(mm,1);
       y_recover_img_p2(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1)=y_recover(mm,2);
       y_recover_img_p3(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1)=y_recover(mm,3);
       y_original_img(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1)=y_tot(mm);
       SampleVar_img_p1(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1)=Sample_Var_tot(mm,1);
       SampleVar_img_p2(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1)=Sample_Var_tot(mm,2);
       SampleVar_img_p3(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1)=Sample_Var_tot(mm,3);
       MSE_recover_img_LB(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1)=Cov_Complete(mm);
end

cmax=ceil(max([max(y_tot),max(max(y_recover_img_p1)),max(max(y_recover_img_p2)),max(max(y_recover_img_p3))]));
cmin=floor(min([min(y_tot),min(min(y_recover_img_p1)),min(min(y_recover_img_p2)),min(min(y_recover_img_p3))]));

figure;
pcolor((Scale-5):Scale:(Region_len-5),(Scale-5):Scale:(Region_len-5),y_original_img);
caxis([cmin,cmax]);
axis([Scale-5 Region_len-5 Scale-5 Region_len-5]);
shading flat;
colormap(hot);
colorbar;
hold on;
plot(Node_loc(1:10,1)+1.5*Scale,Node_loc(1:10,2)+1.5*Scale,'+c');
plot(1.5*Scale,1.5*Scale,'oc');
hold off;

figure;
pcolor((Scale-5):Scale:(Region_len-5),(Scale-5):Scale:(Region_len-5),y_recover_img_p1);
caxis([cmin,cmax]);
axis([Scale-5 Region_len-5 Scale-5 Region_len-5]);
shading flat;
colormap(hot);
colorbar;
hold on;
plot(Node_loc(1:10,1)+1.5*Scale,Node_loc(1:10,2)+1.5*Scale,'+c');
plot(1.5*Scale,1.5*Scale,'oc');
hold off;

figure;
pcolor((Scale-5):Scale:(Region_len-5),(Scale-5):Scale:(Region_len-5),y_recover_img_p2);
caxis([cmin,cmax]);
axis([Scale-5 Region_len-5 Scale-5 Region_len-5]);
shading flat;
colormap(hot);
colorbar;
hold on;
plot(Node_loc(1:10,1)+1.5*Scale,Node_loc(1:10,2)+1.5*Scale,'+c');
plot(1.5*Scale,1.5*Scale,'oc');
hold off;

figure;
pcolor((Scale-5):Scale:(Region_len-5),(Scale-5):Scale:(Region_len-5),y_recover_img_p3);
caxis([cmin,cmax]);
axis([Scale-5 Region_len-5 Scale-5 Region_len-5]);
shading flat;
colormap(hot);
colorbar;
hold on;
plot(Node_loc(1:10,1)+1.5*Scale,Node_loc(1:10,2)+1.5*Scale,'+c');
plot(1.5*Scale,1.5*Scale,'oc');
hold off;

figure;
pcolor((Scale-5):Scale:(Region_len-5),(Scale-5):Scale:(Region_len-5),SampleVar_img_p1);
caxis([0,5]);
axis([Scale-5 Region_len-5 Scale-5 Region_len-5]);
shading flat;
colormap(hot);
colorbar;
hold on;
plot(Node_loc(1:10,1)+1.5*Scale,Node_loc(1:10,2)+1.5*Scale,'+c');
plot(1.5*Scale,1.5*Scale,'oc');
hold off;

figure;
pcolor((Scale-5):Scale:(Region_len-5),(Scale-5):Scale:(Region_len-5),SampleVar_img_p2);
caxis([0,5]);
axis([Scale-5 Region_len-5 Scale-5 Region_len-5]);
shading flat;
colormap(hot);
colorbar;
hold on;
plot(Node_loc(1:10,1)+1.5*Scale,Node_loc(1:10,2)+1.5*Scale,'+c');
plot(1.5*Scale,1.5*Scale,'oc');
hold off;

figure;
pcolor((Scale-5):Scale:(Region_len-5),(Scale-5):Scale:(Region_len-5),SampleVar_img_p3);
caxis([0,5]);
axis([Scale-5 Region_len-5 Scale-5 Region_len-5]);
shading flat;
colormap(hot);
colorbar;
hold on;
plot(Node_loc(1:10,1)+1.5*Scale,Node_loc(1:10,2)+1.5*Scale,'+c');
plot(1.5*Scale,1.5*Scale,'oc');
hold off;

figure;
pcolor((Scale-5):Scale:(Region_len-5),(Scale-5):Scale:(Region_len-5),MSE_recover_img_LB);
caxis([0,5]);
axis([Scale-5 Region_len-5 Scale-5 Region_len-5]);
shading flat;
colormap(hot);
colorbar;
hold on;
plot(Node_loc(1:10,1)+1.5*Scale,Node_loc(1:10,2)+1.5*Scale,'+c');
plot(1.5*Scale,1.5*Scale,'oc');
hold off;
