%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         Decentralized Random-field Estimation for Sensor Networks                   %
%   Using Quantized Spatially Correlated Data and Fusion-center Feedback      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Linear trend case

%%%%%%%%    Abbreviations of variables   %%%%%%%%%%%%%%%%%
%All variables whose names end with "_nfb" correspond to the no-feedback
%method in the paper; "_fb" to the "feedback" method; "_sub" or
%"_subopt" to the suboptimal method.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
clc; 

pdf_Nstd=inline('exp(-x.^2/2)/sqrt(2*pi)');
cdf_Nstd=inline('1-0.5*erfc(x/sqrt(2))');
cdfcomp_Nstd=inline('0.5*erfc(x/sqrt(2))');
invcdf_Nstd=inline('sqrt(2)*erfcinv(2*(1-x))');
q_series=inline('(1-1/(x^2+2)+1/(x^2+2)/(x^2+4)-5/(x^2+2)/(x^2+4)/(x^2+6)+9/(x^2+2)/(x^2+4)/(x^2+6)/(x^2+8)-129/(x^2+2)/(x^2+4)/(x^2+6)/(x^2+8)/(x^2+10))/x');

L=5000;                           %Number of trials
phi=0.2;                           %Field correlation strength
K=3;                                 %Number of quantization levels
K_nfb=K;                         %Number of no feedback quantization levels
p_iteration=3;                  %Number of rounds
T=50;                               %number of MC samples
sigma2=1;                       %variance of noise
N=10;                               %Number of sensor nodes
Region_len=10;              %length of region
%Prior specification
mu_alpha=zeros(3,1);
sigma2_alpha=[25,0,0;0,1,0;0,0,1];
mu_alpha_nfb=mu_alpha;
sigma2_alpha_nfb=sigma2_alpha;

bit_count=zeros(p_iteration,K);
bit_count_sub=zeros(p_iteration,K);
bit_count_nfb=zeros(p_iteration,K_nfb);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ii=0;
while ii<L
	ii=ii+1;
    clc;
    display(['phi=',num2str(phi),', K=',num2str(K),', sigma2=',num2str(sigma2),' case ->',num2str(round(ii*100/L)),'% has completed']);
    %randomly place the nodes  
    loc_count=1;
    while loc_count<=N
        Node_num(loc_count,1)=unidrnd((Region_len*Region_len-1));
        if  Node_num(loc_count,1)==((Region_len/2)*10+Region_len/2)  %if collide with fusion center then reshuffle
            loc_count=loc_count-1;
        end
        if loc_count>1
           for jj=1:(loc_count-1)
              if  Node_num(loc_count,1)==Node_num(jj,1)  %reshuffle upon node collision
                   loc_count=loc_count-1;
              end
           end
        end
        loc_count=loc_count+1;
    end
    Node_loc(:,1)=mod(Node_num,10);
    Node_loc(:,2)=(Node_num-Node_loc(:,1))/10;
    Node_loc=Node_loc-Region_len/2;
    Fusion_loc=[0 0];
    v_loc=[Node_loc;Fusion_loc];
    H=[ones(N+1,1),v_loc];
    %Generate the true parameter
    alpha(:,ii)=mu_alpha+chol(sigma2_alpha)'*randn(3,1);
    %Compute covariance matrix
    for mm=1:(N+1)
        for nn=1:(N+1)
            Cov_Mtrx(mm,nn)=sigma2*exp(-phi*distance(v_loc(mm,:),v_loc(nn,:)));
        end
    end
    Sigma=H*sigma2_alpha*H'+Cov_Mtrx;
    Cov_yy=Sigma(1:N,1:N);
    Syz=Sigma(1:N,N+1);
    sigmaz=Sigma(N+1,N+1);
    S=Cov_yy-(Syz*Syz')/sigmaz;
    S_chol=(chol(S))';                     %Cholesky decomposition
    S_chol_inv=inv(S_chol);
    Cov_Mtrx_Inv=inv(Cov_Mtrx);
    Omega=inv(inv(sigma2_alpha)+H'*Cov_Mtrx_Inv*H);
    Omega_chol=(chol(Omega))';
    %Generate sensor observations
    L_chol=(chol(Cov_Mtrx))';
    V_std=randn(N+1,1);
    V=H*alpha(:,ii)+L_chol*V_std;
    y=V(1:N);                                   %Observations of the nodes
    z=V(N+1);                                  %Observation of the FC
    
    m=H(1:N,:)*mu_alpha+(1/sigmaz)*Syz*(z-H(N+1,:)*mu_alpha);
    Linv_Mu=S_chol_inv*m;
    
    %%%%%%%%%%%%%%%Analog MMSE estimation%%%%%%%%%%%%%%%%%%%%%
    alpha_mmse=Omega*inv(sigma2_alpha)*mu_alpha+Omega*H'*Cov_Mtrx_Inv*V;
    error_alpha_mmse{ii}=(alpha_mmse-alpha(:,ii)).^2;
    error_alpha_mmse_theo{ii}=diag(Omega);
    
    %%%%%%%%%%%%%%%%Decentralized estimation%%%%%%%%%%%%%%%%%%%%
    %Round 0
    C_fb{1}=sigma2_alpha-sigma2_alpha*(H(N+1,:))'*H(N+1,:)*sigma2_alpha/(Cov_Mtrx(N+1,N+1)+H(N+1,:)*sigma2_alpha*(H(N+1,:))');
    alpha_fb(:,1)=C_fb{1}*(inv(sigma2_alpha)*mu_alpha+(H(N+1,:))'*z/Cov_Mtrx(N+1,N+1));
    C_sub_fb{1}=C_fb{1};
    alpha_sub_fb(:,1)=alpha_fb(:,1);
    y_left=-inf*ones(N,1);
    y_right=inf*ones(N,1);
    y_left_sub=-inf*ones(N,1);
    y_right_sub=inf*ones(N,1);
    y_left_nfb=-inf*ones(N,1);
    y_right_nfb=inf*ones(N,1);
    %Round 1+
    for pp=1:p_iteration
        %%%%%%%%No feedback method (fixed quantization)%%%%%%
        %Quantization
        for nn=1:N
            r_nfb(nn)=H(nn,:)*sigma2_alpha_nfb*H(nn,:)'+Cov_Mtrx(nn,nn);
            threshold_nfb(nn,1)=y_left_nfb(nn);
            threshold_std(nn,1)=(threshold_nfb(nn,1)-H(nn,:)*mu_alpha_nfb)/sqrt(r_nfb(nn));
            thresh_step_std=(cdf_Nstd((y_right_nfb(nn)-H(nn,:)*mu_alpha_nfb)/sqrt(r_nfb(nn)))-cdf_Nstd((y_left_nfb(nn)-H(nn,:)*mu_alpha_nfb)/sqrt(r_nfb(nn))))/K_nfb;
            thresh_value_std(nn,1)=cdf_Nstd(threshold_std(nn,1));      
            for kk=2:K_nfb %each node find its thresholds
                 thresh_value_std(nn,kk)=thresh_value_std(nn,kk-1)+thresh_step_std;
                 threshold_std(nn,kk)=invcdf_Nstd(thresh_value_std(nn,kk));
                 threshold_nfb(nn,kk)=H(nn,:)*mu_alpha_nfb+sqrt(r_nfb(nn))*threshold_std(nn,kk);
            end
            threshold_nfb(nn,K_nfb+1)=y_right_nfb(nn);
            threshold_std(nn,K_nfb+1)=(threshold_nfb(nn,K_nfb+1)-H(nn,:)*mu_alpha_nfb)/sqrt(r_nfb(nn));
            %Decide k value of each node
            k_nfb(nn)=1;
            while y(nn)>threshold_nfb(nn,k_nfb(nn))
                k_nfb(nn)=k_nfb(nn)+1;
            end
            bit_count_nfb(pp,k_nfb(nn)-1)=bit_count_nfb(pp,k_nfb(nn)-1)+1;
            y_left_nfb(nn)=max(threshold_nfb(nn,(k_nfb(nn)-1)),y_left_nfb(nn));
            y_right_nfb(nn)=min(threshold_nfb(nn,k_nfb(nn)),y_right_nfb(nn));        
        end% of 'for nn=1:N'
        %Sample and fusion
        for tt=1:T
            xx=zeros(N,1);
            for mm=1:N
                z_left(mm)=(y_left_nfb(mm)-S_chol(mm,:)*xx-Linv_Mu(mm)*S_chol(mm,mm))/S_chol(mm,mm);
                z_right(mm)=(y_right_nfb(mm)-S_chol(mm,:)*xx-Linv_Mu(mm)*S_chol(mm,mm))/S_chol(mm,mm);
                zz(mm)=RejSample(z_left(mm),z_right(mm));
                xx(mm)=Linv_Mu(mm)+zz(mm);
            end
            yy_nfb(:,tt)=S_chol*xx;
            vv_nfb(:,tt)=[yy_nfb(:,tt);z];        
        end% of 'for tt=1:T'
        y_nfb(:,pp)=sum(yy_nfb,2)/T;
        v_nfb=[y_nfb(:,pp);z];
        alpha_nfb(:,pp)=Omega*inv(sigma2_alpha_nfb)*mu_alpha_nfb+Omega*H'*Cov_Mtrx_Inv*v_nfb;
        error_alpha_nfb{pp,ii}=(alpha_nfb(:,pp)-alpha(:,ii)).^2;
        error_y_nfb(pp,ii)=(norm(y_nfb(:,pp)-y))^2;
        clear ('thresh_value_std','threshold_std','xx','z_left','z_right','zz');        

        %%%%%%%%Suboptimal feedback method%%%%%%
        %Quantization
        if pp>1
            C_sub_fb{pp}=Omega;
        end
        for nn=1:N
            r_sub(pp,nn)=H(nn,:)*C_sub_fb{pp}*H(nn,:)'+Cov_Mtrx(nn,nn);
            threshold_sub(nn,1)=y_left_sub(nn);
            threshold_std(nn,1)=(threshold_sub(nn,1)-H(nn,:)*alpha_sub_fb(:,pp))/sqrt(r_sub(pp,nn));
            thresh_step_std=(cdf_Nstd((y_right_sub(nn)-H(nn,:)*alpha_sub_fb(:,pp))/sqrt(r_sub(pp,nn)))-cdf_Nstd((y_left_sub(nn)-H(nn,:)*alpha_sub_fb(:,pp))/sqrt(r_sub(pp,nn))))/K;
            thresh_value_std(nn,1)=cdf_Nstd(threshold_std(nn,1));
            for kk=2:K %each node find its thresholds
                 thresh_value_std(nn,kk)=thresh_value_std(nn,kk-1)+thresh_step_std;
                 threshold_std(nn,kk)=invcdf_Nstd(thresh_value_std(nn,kk));
                 threshold_sub(nn,kk)=H(nn,:)*alpha_sub_fb(:,pp)+sqrt(r_sub(pp,nn))*threshold_std(nn,kk);
            end
            threshold_sub(nn,K+1)=y_right_sub(nn);
            threshold_std(nn,K+1)=(threshold_sub(nn,K+1)-H(nn,:)*alpha_sub_fb(:,pp))/sqrt(r_sub(pp,nn));
            %Decide k value of each node
            k_sub(nn)=1;
            while y(nn)>threshold_sub(nn,k_sub(nn))
                k_sub(nn)=k_sub(nn)+1;
            end
            bit_count_sub(pp,(k_sub(nn)-1))=bit_count_sub(pp,(k_sub(nn)-1))+1;
            y_left_sub(nn)=max(threshold_sub(nn,(k_sub(nn)-1)),y_left_sub(nn));
            y_right_sub(nn)=min(threshold_sub(nn,k_sub(nn)),y_right_sub(nn));
        end
        %"Deterministic" sample and fusion
        xx=zeros(N,1);
        for mm=1:N
            z_left(mm)=(y_left_sub(mm)-S_chol(mm,:)*xx-Linv_Mu(mm)*S_chol(mm,mm))/S_chol(mm,mm);
            z_right(mm)=(y_right_sub(mm)-S_chol(mm,:)*xx-Linv_Mu(mm)*S_chol(mm,mm))/S_chol(mm,mm);
            if z_left(mm)>=7.5&z_right(mm)>=7.5     %For the case of tail far away from center, use the following approximation
                zz_exp=exp((z_left(mm))^2/2-(z_right(mm))^2/2);
                zz(mm)=(1-zz_exp)/(q_series(z_left(mm))-zz_exp*q_series(z_right(mm)));
            elseif z_left(mm)<=-7.5&z_right(mm)<=-7.5
                z_left_temp=z_left(mm);
                z_left(mm)=-z_right(mm);
                z_right(mm)=-z_left_temp;
                zz_exp=exp((z_left(mm))^2/2-(z_right(mm))^2/2);
                zz(mm)=(1-zz_exp)/(q_series(z_left(mm))-zz_exp*q_series(z_right(mm)));
                zz(mm)=-zz(mm);
            else
                zz(mm)=sqrt(1/2/pi)*(exp(-(z_left(mm))^2/2)-exp(-(z_right(mm))^2/2))/(cdf_Nstd(z_right(mm))-cdf_Nstd(z_left(mm)));
            end
            xx(mm)=Linv_Mu(mm)+zz(mm);
        end
        yy_sub=S_chol*xx;
        y_subopt(:,pp)=yy_sub(:,1);
        v_subopt(:,pp)=[y_subopt(:,pp);z];
        alpha_subopt(:,pp)=Omega*inv(sigma2_alpha)*mu_alpha+Omega*H'*Cov_Mtrx_Inv*v_subopt(:,pp);
        error_y_subopt(pp,ii)=(norm( y_subopt(:,pp)-y))^2;
        error_alpha_subopt{pp,ii}=(alpha_subopt(:,pp)-alpha(:,ii)).^2;
        %FC feedback
        alpha_sub_fb(:,pp+1)=alpha_subopt(:,pp);
        
        %%%%%%%%Feedback method%%%%%%
        %Quantization 
        for nn=1:N
            r(pp,nn)=H(nn,:)*C_fb{pp}*H(nn,:)'+Cov_Mtrx(nn,nn);
            threshold_fb(nn,1)=y_left(nn);
            threshold_std(nn,1)=(threshold_fb(nn,1)-H(nn,:)*alpha_fb(:,pp))/sqrt(r(pp,nn));
            thresh_step_std=(cdf_Nstd((y_right(nn)-H(nn,:)*alpha_fb(:,pp))/sqrt(r(pp,nn)))-cdf_Nstd((y_left(nn)-H(nn,:)*alpha_fb(:,pp))/sqrt(r(pp,nn))))/K;
            thresh_value_std(nn,1)=cdf_Nstd(threshold_std(nn,1));
            for kk=2:K %each node find its thresholds
                 thresh_value_std(nn,kk)=thresh_value_std(nn,kk-1)+thresh_step_std;
                 threshold_std(nn,kk)=invcdf_Nstd(thresh_value_std(nn,kk));
                 threshold_fb(nn,kk)=H(nn,:)*alpha_fb(:,pp)+sqrt(r(pp,nn))*threshold_std(nn,kk);
            end
            threshold_fb(nn,K+1)=y_right(nn);
            threshold_std(nn,K+1)=(threshold_fb(nn,K+1)-H(nn,:)*alpha_fb(:,pp))/sqrt(r(pp,nn));
            %Decide k value of each node
            k(nn)=1;
            while y(nn)>threshold_fb(nn,k(nn))
                k(nn)=k(nn)+1;
            end
            bit_count(pp,(k(nn)-1))=bit_count(pp,(k(nn)-1))+1;
            y_left(nn)=max(threshold_fb(nn,(k(nn)-1)),y_left(nn));
            y_right(nn)=min(threshold_fb(nn,k(nn)),y_right(nn));
        end
        %Sample and fusion
        for tt=1:T     
            xx=zeros(N,1);
            for mm=1:N
                z_left(mm)=(y_left(mm)-S_chol(mm,:)*xx-Linv_Mu(mm)*S_chol(mm,mm))/S_chol(mm,mm);
                z_right(mm)=(y_right(mm)-S_chol(mm,:)*xx-Linv_Mu(mm)*S_chol(mm,mm))/S_chol(mm,mm);
                zz(mm)=RejSample(z_left(mm),z_right(mm));
                xx(mm)=Linv_Mu(mm)+zz(mm);
            end
            yy(:,tt)=S_chol*xx;
            VV(:,tt)=[yy(:,tt);z];
            VV_2(:,:,tt)=VV(:,tt)*VV(:,tt)';
        end
        y_fb(:,pp)=sum(yy,2)/T;
        v_fb=[y_fb(:,pp);z];
        v_2_fb=sum(VV_2,3)/T;
        alpha_fb(:,pp)=Omega*inv(sigma2_alpha)*mu_alpha+Omega*H'*Cov_Mtrx_Inv*v_fb;
        error_y_fb(pp,ii)=(norm(y_fb(:,pp)-y))^2;
        error_alpha_fb{pp,ii}=(alpha_fb(:,pp)-alpha(:,ii)).^2;        
        %FC feedback
        alpha_fb(:,pp+1)=alpha_fb(:,pp);
        C_fb{pp+1}=Omega+Omega*H'*Cov_Mtrx_Inv*(v_2_fb-v_fb*v_fb')*Cov_Mtrx_Inv*H*Omega;
    end%of (for pp=1:p_iteration)
end

for pp=1: p_iteration
    MSE_alpha_fb{pp}=zeros(length(mu_alpha),1);
    MSE_alpha_subopt{pp}=zeros(length(mu_alpha),1);
    MSE_alpha_nfb{pp}=zeros(length(mu_alpha),1);
end
MSE_alpha_mmse=zeros(length(mu_alpha),1);
MSE_alpha_mmse_theo=zeros(length(mu_alpha),1);

for ii=1:L
    for pp=1: p_iteration
        MSE_alpha_fb{pp}=MSE_alpha_fb{pp}+error_alpha_fb{pp,ii};
        MSE_alpha_subopt{pp}=MSE_alpha_subopt{pp}+error_alpha_subopt{pp,ii};
        MSE_alpha_nfb{pp}=MSE_alpha_nfb{pp}+error_alpha_nfb{pp,ii};
    end
    MSE_alpha_mmse=MSE_alpha_mmse+error_alpha_mmse{ii};
    MSE_alpha_mmse_theo=MSE_alpha_mmse_theo+error_alpha_mmse_theo{ii};
end

for pp=1: p_iteration
    MSE_alpha_fb{pp}=MSE_alpha_fb{pp}/L;
    MSE_alpha_subopt{pp}=MSE_alpha_subopt{pp}/L;
    MSE_alpha_nfb{pp}=MSE_alpha_nfb{pp}/L;
end
MSE_alpha_mmse=MSE_alpha_mmse/L;
MSE_alpha_mmse_theo=MSE_alpha_mmse_theo/L;

MSE_y_fb=sum(error_y_fb,2)/N/L;
MSE_y_subopt=sum(error_y_subopt,2)/N/L;
MSE_y_nfb=sum(error_y_nfb,2)/N/L;

bit_budget=bit_count/N/L;
bit_budget_sub=bit_count_sub/N/L;
bit_budget_nfb=bit_count_nfb/N/L;

%%%%%%%%%%%%%%%%%%%Save data%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
save(['Slope','_L',num2str(L),'_K',num2str(K),'_phi',num2str(phi),'_NoiVar',num2str(sigma2),'.mat'],'N','phi','K','K_nfb','L','T','p_iteration','sigma2','sigma2_alpha','MSE_alpha_fb','MSE_alpha_mmse','MSE_alpha_mmse_theo','MSE_alpha_subopt','MSE_alpha_nfb','MSE_y_fb','MSE_y_subopt','MSE_y_nfb','bit_budget','bit_budget_sub','bit_budget_nfb','bit_count','bit_count_sub','bit_count_nfb');
