function z=RejSample(z_left,z_right)
%This function generates a sample from the truncated standard normal random
%variable with left and right boundaries specified by z_left and z_right


pdf_Nstd=inline('exp(-x.^2/2)/sqrt(2*pi)');

t1=0.45;
t2=2;
t3=0.7;
method=0;
NumLim=37.8;    %Numerical Limit for the sampler: for x>NumLim, pdf_Nstd(x)=0 numerically.

if z_right==inf
    if z_left<=t1
        method=1;
    else
        if z_left<=NumLim
            method=2;
        else
            method=21;
        end
    end
end

if z_left==-inf
    if z_right>=(-t1)
        method=3;
    else
        if abs(z_right)<=NumLim
             method=4;
        else
             method=41;
        end
    end
end

if z_left>(-inf)&&z_right<inf&&z_left<0&&z_right>0
    if pdf_Nstd(z_right)>=0.25&&pdf_Nstd(z_left)>=0.25
         method=6;
    else    
         method=5;
    end    
end

if z_left>(-inf)&&z_right<inf&&z_left>=0&&z_right>=0
    if z_left<=NumLim
        if z_right<=NumLim
            if pdf_Nstd(z_left)/pdf_Nstd(z_right)<=t2
                 method=7;
            else
                 if z_left<t3
                      method=8;
                 else
                      method=9;
                 end
            end
        else
            if z_left<t3
                 method=8;
            else
                 method=9;
            end
        end
    else
        method=91;
    end
end

if z_left>(-inf)&&z_right<inf&&z_left<0&&z_right<0
    if abs(z_right)<=NumLim
        if abs(z_left)<=NumLim
            if pdf_Nstd(z_right)/pdf_Nstd(z_left)<=t2
                method=10;
            else
                if abs(z_right)<t3
                      method=11;
                else
                      method=12;
                end
            end
        else
            if abs(z_right)<t3
                 method=11;
            else
                 method=12;
            end
        end
    else
        method=121;
    end
end

flag=0;
switch method
    case 0
        display('ERROR!!! Invalid boundaries!');
        z=inf;
    case 1
        while flag==0
            zz=randn(1);
            if zz>z_left
                flag=1;
            end
        end
        z=zz;
    case 2
        while flag==0
            zz=z_left+exprnd(1/z_left);
            r_acc=pdf_Nstd(zz)/pdf_Nstd(z_left)/exp(-z_left*(zz-z_left));
            if  rand(1)<r_acc
                  flag=1;
            end
        end
        z=zz;
    case 21
        z=z_left;
    case 3
        while flag==0
            zz=randn(1);
            if zz<z_right
                flag=1;
            end
        end
        z=zz;
    case 4
        while flag==0
            zz=abs(z_right)+exprnd(1/abs(z_right));
            r_acc=pdf_Nstd(zz)/pdf_Nstd(abs(z_right))/exp(-abs(z_right)*(zz-abs(z_right)));
            if  rand(1)<r_acc
                  flag=1;
            end
        end    
        z=-zz;
    case 41
        z=z_right;
    case 5
        while flag==0
            zz=randn(1);
            if zz>z_left&&zz<z_right
                flag=1;
            end
        end
        z=zz;
    case 6
        while flag==0
            zz=z_left+rand(1)*abs(z_right-z_left);
            if zz>z_left&&zz<z_right
                r_acc=exp(-zz^2/2);
            else
                r_acc=0;
            end
            if  rand(1)<r_acc
                  flag=1;
            end
        end    
        z=zz;
    case 7
        while flag==0
            zz=z_left+rand(1)*abs(z_right-z_left);
            if zz>z_left&&zz<z_right
                r_acc=pdf_Nstd(zz)/pdf_Nstd(z_left);
            else
                r_acc=0;
            end
            if  rand(1)<r_acc
                  flag=1;
            end
        end
        z=zz;
    case 8
        while flag==0
            zz=randn(1);
            zz=abs(zz);
            if zz>z_left&&zz<z_right
                flag=1;
            end
        end
        z=zz;
    case 9
        while flag==0
            zz=z_left+exprnd(1/z_left);
            if zz<z_right
                r_acc=pdf_Nstd(zz)/pdf_Nstd(z_left)/exp(-z_left*(zz-z_left));
            else
                r_acc=0;
            end
            if  rand(1)<r_acc
                  flag=1;
            end
        end
        z=zz;
    case 91
        z=z_left;
    case 10
        while flag==0
            zz=z_right-rand(1)*abs(z_right-z_left);
            if zz>z_left&&zz<z_right
                r_acc=pdf_Nstd(zz)/pdf_Nstd(z_right);
            else
                r_acc=0;
            end
            if  rand(1)<r_acc
                  flag=1;
            end
        end
        z=zz;
    case 11
        while flag==0
            zz=randn(1);
            zz=abs(zz);
            if zz>(-z_right)&&zz<(-z_left)
                flag=1;
            end
        end
        z=-zz;
    case 12
        while flag==0
            zz=abs(z_right)+exprnd(1/abs(z_right));
            if zz<abs(z_left)
                r_acc=pdf_Nstd(zz)/pdf_Nstd(abs(z_right))/exp(-abs(z_right)*(zz-abs(z_right)));
            else
                r_acc=0;
            end
            if  rand(1)<r_acc
                  flag=1;
            end
        end
        z=-zz;
    case 121
        z=z_right;
    otherwise
        display('Not able to sample.')    
end

