%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         Decentralized Random-field Estimation for Sensor Networks                   %
%   Using Quantized Spatially Correlated Data and Fusion-center Feedback      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Constant mean case (Prediction)
%Fig.6 in the paper

clear all;
clc;

pdf_Nstd=inline('exp(-x.^2/2)/sqrt(2*pi)');
cdf_Nstd=inline('1-0.5*erfc(x/sqrt(2))');
invcdf_Nstd=inline('sqrt(2)*erfcinv(2*(1-x))');
load NodeLocation.mat

L=5000;                            %Number of trials
phi=0.5;                             %Field correlation strength
K=2;                                   %Number of quantization levels
K_nfb=K;                           %Number of no feedback quantization levels
p_iteration=3;                    %Number of rounds
T=20;                                  %number of MC samples
N=10;                                  %Number of sensor nodes
Region_len=10;                 %length of region
sigma2=1;                          %noise variance
Scale=0.1;                          %density of the points to be predicted
M=(Region_len/Scale)^2-N-1;%Number of points to be predicted

%Prior specification
mu_alpha=0;
sigma2_alpha=25;
mu_alpha_nfb=mu_alpha;
sigma2_alpha_nfb=sigma2_alpha;

H=ones(N+1,1);
H_tot=ones(N+M+1,1);
H_pred=ones(M,1);

%Generate node Cov_Mtrx structure    
for mm=1:(N+1)
    for nn=1:(N+1)
        Cov_Mtrx(mm,nn)=sigma2*exp(-phi*distance(v_loc(mm,:),v_loc(nn,:)));
    end
end
Sigma=H*sigma2_alpha*H'+Cov_Mtrx;
Cov_yy=Sigma(1:N,1:N);
Syz=Sigma(1:N,N+1);
Segmaz=Sigma(N+1,N+1);
S=Cov_yy-(Syz*Syz')/Segmaz;
S_chol=(chol(S))';                     %Cholesky decomposition
S_chol_inv=inv(S_chol);

Cov_Mtrx_Inv=inv(Cov_Mtrx);
Omega=inv(inv(sigma2_alpha)+H'*Cov_Mtrx_Inv*H);

%Generate entire field and entire Cov structure
space_loc=v_loc;
space_index=N+2;
space_flag=0;
for mm=0:(Region_len/Scale-1)
    for nn=0:(Region_len/Scale-1)
        space_flag=0;
        space_loc(space_index,:)=[nn*Scale,mm*Scale];
        for ll=1:(N+1)
            if space_loc(space_index,1)==v_loc(ll,1)&&space_loc(space_index,2)==v_loc(ll,2)
                space_flag=1;
            end
        end
        if space_flag==0
            space_index=space_index+1;
        end
    end
end

for mm=1:(N+1)
    mm
    for nn=(N+2):(N+M+1)
        Cov_ypre_v(nn-N-1,mm)=sigma2*exp(-phi*distance(v_loc(mm,:),space_loc(nn,:)));
    end
end
Q=H_pred-Cov_ypre_v*Cov_Mtrx_Inv*H;
W=[Q,Cov_ypre_v*Cov_Mtrx_Inv];

%Generate the diagonal of Cov_Pred
for nn=(N+2):(N+M+1)
     Cov_Pred_diag(nn-N-1,:)=sigma2-Cov_ypre_v(nn-N-1,:)*Cov_Mtrx_Inv*Cov_ypre_v(nn-N-1,:)';
     Var_yPred_v(nn-N-1,:)=(H_pred(nn-N-1,:)-H'*Cov_Mtrx_Inv*Cov_ypre_v(nn-N-1,:)')'*Omega*(H_pred(nn-N-1,:)-H'*Cov_Mtrx_Inv*Cov_ypre_v(nn-N-1,:)')+Cov_Pred_diag(nn-N-1,:);
end
Cov_Complete=[zeros(N+1,1);Var_yPred_v];
MSE_recover=zeros(N+M+1,p_iteration);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ii=0;
while ii<L
    ii=ii+1;
    clc;
    display(['phi=',num2str(phi),', K=',num2str(K),', Knfb=',num2str(K_nfb),' case ->',num2str(round(ii*100/L)),'% has completed']);
    %Generate the true parameter
    alpha(ii)=mu_alpha+sqrt(sigma2_alpha)*randn(1);

    %Generate the measurements of the field
    X=ExpCorRandnFieldfcn(Region_len,Region_len,Scale,alpha(ii),sigma2,phi);
    for mm=1:(N+M+1)
        y_tot(mm,:)=X(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1);
    end
    
    V=y_tot(1:N+1);
    y=V(1:N);                                   %Observations by node
    z=V(N+1);                                  %Observation by fusion center
    
    m=H(1:N,:)*mu_alpha+(1/Segmaz)*Syz*(z-H(N+1,:)*mu_alpha);
    Linv_Mu=S_chol_inv*m;
    
    %%%%%%%%%%%%%%%Analog MMSE estimation%%%%%%%%%%%%%%%%%%%%%
    alpha_mmse=Omega*inv(sigma2_alpha)*mu_alpha+Omega*H'*Cov_Mtrx_Inv*V;
    error_alpha_mmse(ii)=(alpha_mmse-alpha(ii))^2;
    error_alpha_mmse_theo(ii)=1/(inv(sigma2_alpha)+ones(1,N+1)*Cov_Mtrx_Inv*ones(N+1,1));
    
    %%%%%%%%Feedback method%%%%%%
    %Round 0
    C_fb(1)=sigma2_alpha-sigma2_alpha*(H(N+1,:))'*H(N+1,:)*sigma2_alpha/(Cov_Mtrx(N+1,N+1)+H(N+1,:)*sigma2_alpha*(H(N+1,:))');
    alpha_fb(1)=C_fb(1)*(inv(sigma2_alpha)*mu_alpha+(H(N+1,:))'*z/Cov_Mtrx(N+1,N+1));
    y_left=-inf*ones(N,1);
    y_right=inf*ones(N,1);   
    for pp=1:p_iteration
        %Quantization         
        for nn=1:N
            r(pp,nn)=H(nn,:)*C_fb(pp)*H(nn,:)'+Cov_Mtrx(nn,nn);
            threshold_Gibbs(nn,1)=y_left(nn);
            threshold_std(nn,1)=(threshold_Gibbs(nn,1)-H(nn,:)*alpha_fb(pp))/sqrt(r(pp,nn));
            thresh_step_std=(cdf_Nstd((y_right(nn)-H(nn,:)*alpha_fb(pp))/sqrt(r(pp,nn)))-cdf_Nstd((y_left(nn)-H(nn,:)*alpha_fb(pp))/sqrt(r(pp,nn))))/K;
            thresh_value_std(nn,1)=cdf_Nstd(threshold_std(nn,1));
            for kk=2:K %each node find its thresholds
                 thresh_value_std(nn,kk)=thresh_value_std(nn,kk-1)+thresh_step_std;
                 threshold_std(nn,kk)=invcdf_Nstd(thresh_value_std(nn,kk));
                 threshold_Gibbs(nn,kk)=H(nn,:)*alpha_fb(pp)+sqrt(r(pp,nn))*threshold_std(nn,kk);
            end
            threshold_Gibbs(nn,K+1)=y_right(nn);
            threshold_std(nn,K+1)=(threshold_Gibbs(nn,K+1)-H(nn,:)*alpha_fb(pp))/sqrt(r(pp,nn));
            %Decide k value of each node
            k(nn)=1;
            while y(nn)>threshold_Gibbs(nn,k(nn))
                k(nn)=k(nn)+1;
            end
            y_left(nn)=max(threshold_Gibbs(nn,(k(nn)-1)),y_left(nn));
            y_right(nn)=min(threshold_Gibbs(nn,k(nn)),y_right(nn));
        end
        %Sample and fusion
        for tt=1:T
            xx=zeros(N,1);
            for mm=1:N
                z_left(mm)=(y_left(mm)-S_chol(mm,:)*xx-Linv_Mu(mm)*S_chol(mm,mm))/S_chol(mm,mm);
                z_right(mm)=(y_right(mm)-S_chol(mm,:)*xx-Linv_Mu(mm)*S_chol(mm,mm))/S_chol(mm,mm);
                zz(mm)=RejSample(z_left(mm),z_right(mm));
                xx(mm)=Linv_Mu(mm)+zz(mm);
            end
            yy(:,tt)=S_chol*xx;
            VV(:,tt)=[yy(:,tt);z];
            VV_2(:,:,tt)=VV(:,tt)*VV(:,tt)';
        end
        y_fb(:,pp)=sum(yy,2)/T;
        v_fb=[y_fb(:,pp);z];
        v_2_fb=sum(VV_2,3)/T;
        alpha_fb(pp)=Omega*inv(sigma2_alpha)*mu_alpha+Omega*H'*Cov_Mtrx_Inv*v_fb;
        y_pred(:,pp)=W*[alpha_fb(pp)',v_fb']';
        y_recover(:,pp)=[y_fb(:,pp);z;y_pred(:,pp)];
        error_y_fb(pp,ii)=(norm(y_fb(:,pp)-y))^2;
        error_y_pred(pp,ii)=(norm(y_pred(:,pp)-y_tot(N+2:N+M+1)))^2;
        error_recover(:,pp)=(y_recover(:,pp)-y_tot).^2;
        error_alpha_fb(pp,ii)=(alpha_fb(pp)-alpha(ii))^2;        
        %FC feedback
        alpha_fb(pp+1)=alpha_fb(pp);
        C_fb(pp+1)=Omega+Omega*H'*Cov_Mtrx_Inv*(v_2_fb-v_fb*v_fb')*Cov_Mtrx_Inv*H*Omega;
    end%of 'for pp=1:p_iteration'
    MSE_recover=MSE_recover+error_recover;
end

MSE_alpha_fb=sum(error_alpha_fb,2)/L;
MSE_y_fb=sum(error_y_fb,2)/N/L;
MSE_alpha_mmse=sum(error_alpha_mmse,2)/L;
MSE_alpha_mmse_theo=sum(error_alpha_mmse_theo,2)/L;
MSE_y_pred=sum(error_y_pred,2)/M/L;
MSE_recover=MSE_recover/L;

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                  Plotting          %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
for mm=1:(N+M+1)
       MSE_recover_img_p1(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1)=MSE_recover(mm,1);
       MSE_recover_img_p2(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1)=MSE_recover(mm,2);
       MSE_recover_img_p3(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1)=MSE_recover(mm,3);
       MSE_recover_img_LB(round(space_loc(mm,2)/Scale)+1,round(space_loc(mm,1)/Scale)+1)=Cov_Complete(mm);
end

figure;
pcolor(Scale:Scale:Region_len,Scale:Scale:Region_len,MSE_recover_img_p1);
caxis([0,1.5]);
axis([Scale Region_len Scale Region_len]);
shading flat;
colormap(hot);
colorbar;
hold on;
plot(v_loc(1:10,1)+1.5*Scale,v_loc(1:10,2)+1.5*Scale,'+w');
plot(5.15,5.15,'ow');
hold off;

figure;
pcolor(Scale:Scale:Region_len,Scale:Scale:Region_len,MSE_recover_img_p2);
caxis([0,1.5]);
axis([Scale Region_len Scale Region_len]);
shading flat;
colormap(hot);
colorbar;
hold on;
plot(v_loc(1:10,1)+1.5*Scale,v_loc(1:10,2)+1.5*Scale,'+w');
plot(5.15,5.15,'ow');
hold off;

figure;
pcolor(Scale:Scale:Region_len,Scale:Scale:Region_len,MSE_recover_img_p3);
caxis([0,1.5]);
axis([Scale Region_len Scale Region_len]);
shading flat;
colormap(hot);
colorbar;
hold on;
plot(v_loc(1:10,1)+1.5*Scale,v_loc(1:10,2)+1.5*Scale,'+w');
plot(5.15,5.15,'ow');
hold off;

figure;
pcolor(Scale:Scale:Region_len,Scale:Scale:Region_len,MSE_recover_img_LB);
caxis([0,1.5]);
axis([Scale Region_len Scale Region_len]);
shading flat;
colormap(hot);
colorbar;
hold on;
plot(v_loc(1:10,1)+1.5*Scale,v_loc(1:10,2)+1.5*Scale,'+w');
plot(5.15,5.15,'ow');
hold off;

