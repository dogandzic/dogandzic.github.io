function X=ExpCorRandnFieldfcn(X_len,Y_len,Scale,alpha,segma2,phi)
%Generate 2-d correlated random Gaussian field according to 
%correlation function r(t)=segma2*exp{-^phi*|t|}
%The size of the field is X_len by Y_len and the mean of the field
% is alpha with the variance subject to segma2
%INPUT: 
%X_len is the x-axis length of the field i.e. the field is [0, X_len] wide
%X_len is the y-axis length of the field i.e. the field is [0, Y_len] long
%Scale is the step size of both X and Y direction
%alpha is the mean of the field
%segma2 and phi are the parameters in the exponential correlation function

if (X_len/Scale)-round(X_len/Scale)~=0
    display('ERROR: X_len/Scale is NOT integer!!!')
    keyboard;
end

if (Y_len/Scale)-round(Y_len/Scale)~=0
    display('ERROR: Y_len/Scale is NOT integer!!!')
    keyboard;
end

%Find suitable g and thus m
g(1)=ceil(log2(2*(X_len/Scale)));
g(2)=ceil(log2(2*(Y_len/Scale)));
m=2.^g;
m_bar=m(1)*m(2);

%Find the Eigenvalues of the extented matrix C
for x_idx=1:m(1)
    if x_idx>=0&&x_idx<=(m(1)/2)
        h_telta(1)=x_idx;
    else
        h_telta(1)=x_idx-m(1);
    end
    h_telta(1)=h_telta(1)-1;
    for y_idx=1:m(2)
        if y_idx>=0&&y_idx<=(m(2)/2)
           h_telta(2)=y_idx;
        else
           h_telta(2)=y_idx-m(2);
        end
        h_telta(2)=h_telta(2)-1;
        c(y_idx,x_idx)=segma2*exp(-phi*norm(h_telta.*Scale));
    end
end

lamda=fft2(c);
lamda=real(lamda);

%The main procedure
m_cross=floor(m/2)+1;
m_bar_cross=m_cross(1)*m_cross(1);

step=0;
while step~=7
    switch step
        case 0   %Step 0
            r=-1;
            step=1;
        case 1
            r=r+1;
            j(1)=mod(r,m_cross(1));
            j(2)=floor(r/m_cross(1));
            A=[0 0];
            if j(1)>0&&j(1)<(m(1)/2)
                A(1)=1;
            end
             if j(2)>0&&j(2)<(m(2)/2)
                A(2)=1;
             end
            Xi=sum(A);
            if Xi>0
                step=3;
            else
                step=2;
            end
        case 2
            a(j(2)+1,j(1)+1)=m_bar^(-0.5)*sqrt(lamda(j(2)+1,j(1)+1))*randn(1);
            step=6;
        case 3
            if Xi==2
                B{1}=[1];
                Bc{1}=[2];
                B{2}=[1 2];
                Bc{2}=NaN;
            end
            if Xi==1
                B{1}=find(A==1);
                Bc{1}=NaN;
            end
            s=0;
            step=4;
        case 4
            s=s+1;
            for l=1:2
                if ismember(l,B{s})
                    j1(l)=m(l)-j(l);
                else
                    j1(l)=j(l);
                end
                if ismember(l,Bc{s})
                    j2(l)=m(l)-j(l);
                else
                    j2(l)=j(l);
                end
            end
            step=5;
        case 5
            U=randn(1);
            V=randn(1);
            a(j1(2)+1,j1(1)+1)=(2*m_bar)^(-0.5)*sqrt(lamda(j1(2)+1,j1(1)+1))*(U+i*V);
            a(j2(2)+1,j2(1)+1)=(2*m_bar)^(-0.5)*sqrt(lamda(j1(2)+1,j1(1)+1))*(U-i*V);
            if s<2^(Xi-1)
                step=4;
            else
                step=6;
            end
        case 6
            if r<(m_bar_cross-1)
                step=1;
            else
                step=7;
            end            
    end    
end

%Step 7
X=fft2(a);
X=X(1:(Y_len/Scale),1:(X_len/Scale));
X=real(X);
X=X+alpha;
