function [s_hat,Count,loglikelihood]=DMECME(y,Phi,Phit,Psi,Psit,r,varargin)
% Difference Map ECME Algorithm (DM-ECME): 
% Coded by Kun Qiu (kqiu@iastate.edu)
% Last updated Jun. 17, 2011
% 
% 
% Function usage
% =======================================================
% INPUT(compulsory):
% y:                               the measurement column vector
% Phi:                           the sampling function handle (which computes Phi*z)
% Phit:                          the adjoint sampling function handle that computes Phi^T*y
% Psi:                           the sparsifying basis function handle (which computes Psi*z)
% Psit:                          the adjoint sparsifying basis function handle that computes Psi^T*y
% r:                               the sparsity level of the signal to be recovered
% 
% INPUT(optional):
% 'beta':                       the beta parameter of the difference map iteration (0.6 <= |beta| <= 1)
%                                   (default=1)
% 'InitialSig':                 the mx1 initial signal transform coefficients estimate
%                                   (default=zeros(m,1))
% 'Thresh':                   tolerance threshold for stopping the algorithm
%                                   (default=1e-14)
% 'Thresh_DM':           tolerance threshold for stopping the difference map inner loop
%                                   (default value is euqal to the value of 'Thresh')
% 'Max_Iter':                maximum number of iterations
%                                   (default=2000)
% 'Visibility':                 Option to monitor the reconstruction process (valued in {0,1})
%                                   0: do not monitor
%                                   1: do monitor
%                                   (default=0)
% ========================================================
% OUTPUT:
% s_hat:              the signal transform coefficients estimate
% Count:             Count of the number of iterations
% loglikelihood:  the log-likelihood function
% ========================================================

if (nargin-length(varargin))~=6
    error('Missing required inputs!');
end

N=length(y);
m=length(Phit(y));
ms=round(sqrt(m));

%Setting default values for the optional inputs
beta=1;
s_init=zeros(m,1);
thresh=1e-14;
thresh_DM=thresh;
MAX_ITER=2000;
Visibility=0;

%Read the optional inputs
if (rem(length(varargin),2)==1)
    error('Optional inputs must go by pairs!');
else
    for i=1:2:(length(varargin)-1)
        switch upper(varargin{i})
            case upper('beta')
                beta=varargin{i+1};
            case upper('InitialSig')
                s_init=varargin{i+1};
            case upper('Thresh')
                thresh=varargin{i+1};
            case upper('Thresh_DM')
                thresh_DM=varargin{i+1};
            case upper('Max_Iter')
                MAX_ITER=varargin{i+1};
            case upper('Visibility')
                Visibility=varargin{i+1};     
            otherwise
                error(['Unrecognized optional input: ''' varargin{i} '''']);
        end
    end
end

%Initialization
exit_flag=0;
p=0;
s_DM_pre=s_init;
s_pre=inf*ones(m,1);
loglikelihood_max=-inf;
while ~exit_flag
    p=p+1;
    DM_exit_flag=0;
    while ~DM_exit_flag
        Pa_s=Proj_A(s_DM_pre,r,m);
        Pb_s=Proj_B(s_DM_pre,Psi,Psit,ms);
        fa=Pa_s-(Pa_s-s_DM_pre)/beta;
        fb=Pb_s+(Pb_s-s_DM_pre)/beta;
        s_DM=s_DM_pre+beta*(Proj_A(fb,r,m)-Proj_B(fa,Psi,Psit,ms));
        gap_DM=norm(s_DM-s_DM_pre)^2/m;
        if gap_DM<thresh_DM
            DM_exit_flag=1;
            s_new=Proj_B(fa,Psi,Psit,ms);
        else
            s_DM_pre=s_DM;
        end
    end
    Phi_Psi_s=Phi(reshape(Psi(reshape(s_new,ms,ms)),m,1));
    sigma2_hat=norm(y-Phi_Psi_s)^2/N;
    loglikelihood(p)=-N/2*log(2*pi*sigma2_hat)-N/2;
    if loglikelihood(p)>loglikelihood_max;
        loglikelihood_max=loglikelihood(p);
        s_new_max=s_new;
    end
    gap=norm(s_new-s_pre)^2/m;
    if Visibility
        clc;
        display(['DM-ECME reconstruction (','r=',num2str(r),', beta=',num2str(beta),')']);
        display(['Iter=',num2str(p),'(max=',num2str(MAX_ITER),'), gap=',num2str(gap),'(target=',num2str(thresh),')']);
    end
    if (gap<thresh)|(p>=MAX_ITER)
        exit_flag=1;
    else
        s_pre=s_new;
        s_DM_pre=s_pre+reshape(Psit(reshape(Phit(y-Phi_Psi_s),ms,ms)),m,1);
    end
end

s_hat=s_new_max;
Count=p;

return;

function Pa=Proj_A(x,r,m)
[x_sort,x_index]=sort(abs(x),'descend');
Pa=zeros(m,1);
Pa(x_index(1:r))=x(x_index(1:r));
return;

function Pb=Proj_B(x,Psi,Psit,ms)
Pb=reshape(x,[ms ms]);
u=Psi(Pb);
u=max(u,0);
Pb=Psit(u);
Pb=Pb(:);
return;



