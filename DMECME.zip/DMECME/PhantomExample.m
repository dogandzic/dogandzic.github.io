%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                               Compressive Sensing Image Reconstruction                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Coded by Kun Qiu
%Last updated at Jun. 17, 2011

clear all
clc
close all

path(path, './subfunctions');
path(path,'./Algorithms');
addpath(genpath(fullfile(pwd,'./Algorithms/FPC_AS')));

%Number of trials
TrialNum=1;
%Number of radial lines
RadialNum=38;
%Noise variance
sigma2=0;

Img2D=phantom(256);
img_name='Phantom';
scale=max(Img2D(:))-min(Img2D(:));
[my,mx]=size(Img2D);
m=my*mx;

%Sampling operator
% number of radial lines in the Fourier domain
[M,Mh,mh,mhi]=LineMask(RadialNum,mx);
OMEGA=mhi;
smpl_pattern=fftshift(M);

Phi=@(z) A_fhp(z,OMEGA);
Phit=@(z) At_fhp(z,OMEGA,mx);

%Sparsifying basis
dwt_L=6;                                     %levels of wavelet transform
wav=daubcqf(2);
W=@(z) midwt(z,wav,dwt_L);
Wt=@(z) mdwt(z,wav,dwt_L);

wav_coeff=Wt(Img2D);
r_init=length(find(abs(wav_coeff(:))>0));    %sparsity level for hard thresholding methods

%Effective sensing operator
H=@(z) H_idwt1d(Phi,z,wav,dwt_L,my,mx);
Ht=@(z) Ht_dwt1d(Phit,z,wav,dwt_L,my,mx);

for ii=1:TrialNum

    %Add noise
    Img2D_noisy=Img2D+sqrt(sigma2)*randn(my,mx);
    Imgcntr=Img2D_noisy(:);
    % taking measurements
    y=Phi(Imgcntr);
    N=length(y);
    Nratio=N/m;

    %Reconstruction
    thresh=1e-14;           %Convergence tolerance for Hard thresholding methods

    %solve by Back Projection method
    clc
    display('Now Back Projection');
    s_BackProj=Ht(y);
    s_BackProj=reshape(s_BackProj,[my mx]);
    Img2D_BackProj=W(s_BackProj);
    PSNR_BackProj=psnr(Img2D,Img2D_BackProj,scale);
    error_BackProj(ii)=norm(Img2D_BackProj(:)-Img2D(:))^2/m;

    %solve by Difference Map Expectation-conditional Maximization Either (DM-ECME) Method
    clc
    display('Now DM-ECME');
    s_init=zeros(m,1);
    beta=1;
    thresh_DM=1e-14;
    MAX_ITER=2000;
    r_DMECME=r_init;    %Sparsity level
    [s_DMECME,Count_DMECME,loglikelihood_DMECME]=DMECME(y,Phi,Phit,W,Wt,r_DMECME,'beta',beta,'InitialSig',s_init,...
                                                                                                    'Thresh',thresh,'Max_Iter',MAX_ITER,'Visibility',1);
    s_DMECME=reshape(s_DMECME,[my mx]);
    Img2D_DMECME=W(s_DMECME);
    PSNR_DMECME=psnr(Img2D,Img2D_DMECME,scale);
    error_DMECME(ii)=norm(Img2D_DMECME(:)-Img2D(:))^2/m;

    %solve by Sparse Poisson-Intensity Reconstruction with Gaussian noise (SPIRAL_G) method
    clc
    display('Now SPIRAL_G');
    tau_SPIRAL=1e-5*max(abs(Ht(y)));
    maxiter=2000;
    miniter=0;
    stopcriterion=5;
    tolerance=thresh;
    verbose=100;
    z_init=zeros(m,1);
    subtolerance=1e-5;
    [Img1D_SPIRAL,Count_SPIRAL]=SPIRALTAP_mod(y,Phi,tau_SPIRAL,'penalty','ONB','AT',Phit,'W',W,'WT',Wt,'noisetype','gaussian',...
                                                                'initialization',z_init,'maxiter',maxiter,'miniter',miniter,'stopcriterion',stopcriterion,'tolerance',tolerance,...
                                                                'subtolerance',subtolerance,'monotone',0,'saveobjective',0,'savereconerror',0,'savecputime',1,...
                                                                'savesolutionpath',0,'verbose',verbose);
    Img2D_SPIRAL=reshape(Img1D_SPIRAL,[my mx]);
    PSNR_SPIRAL=psnr(Img2D,Img2D_SPIRAL,scale);
    error_SPIRAL(ii)=norm(Img2D_SPIRAL(:)-Img2D(:))^2/m;

    %solve by Expectation-conditional Maximization Either (ECME) method 
    %equivalent to Iterative Hard thresholding (IHT) for this example
    clc
    display('Now ECME');
    r_ECME=r_init;
    [s_ECME,Count_ECME]=hard_l0_Mterm_mod(y,H,m,r_ECME,thresh,'P_trans',Ht,'step_size',1);
    s_ECME=reshape(s_ECME,[my mx]);
    Img2D_ECME=W(s_ECME);
    PSNR_ECME=psnr(Img2D,Img2D_ECME,scale); 
    error_ECME(ii)=norm(Img2D_ECME(:)-Img2D(:))^2/m;

    %solve by Normalized Iterative Hard Thresholding (NIHT) method
    clc
    display('Now NIHT');
    r_NIHT=r_init;
    [s_NIHT,Count_NIHT]=hard_l0_Mterm_mod(y,H,m,r_NIHT,thresh,'P_trans',Ht);
    s_NIHT=reshape(s_NIHT,[my mx]);
    Img2D_NIHT=W(s_NIHT);
    PSNR_NIHT=psnr(Img2D,Img2D_NIHT,scale); 
    error_NIHT(ii)=norm(Img2D_NIHT(:)-Img2D(:))^2/m;

    %solve by Fixed Point Continuation Active Set (FPC_AS) method
    clc
    display('Now FPC_AS');
    A_FPC=A_operator(H, Ht);
    tau_FPC=(1e-4)*max(abs(Ht(y)));
    [s_FPC,Out_FPC]=FPC_AS(m,A_FPC,y,tau_FPC,[]);
    s_FPC=reshape(s_FPC,[my mx]);
    Img2D_FPC=W(s_FPC);
    PSNR_FPC=psnr(Img2D,Img2D_FPC,scale);
    error_FPC(ii)=norm(Img2D_FPC(:)-Img2D(:))^2/m;

    %solve by GPSR_BB
    clc
    display('Now GPSR_BB');
    tau_GPSR=(1e-4)*max(abs(Ht(y)));
    [s_GPSR,s_GPSRdb,objective,times,debias_start,mses]=GPSR_BB(y,H,tau_GPSR,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
    s_GPSR=reshape(s_GPSR,[my mx]);
    Img2D_GPSR=W(s_GPSR);
    PSNR_GPSR=psnr(Img2D,Img2D_GPSR,scale);
    error_GPSR(ii)=norm(Img2D_GPSR(:)-Img2D(:))^2/m;
    if ~isempty(s_GPSRdb)
        s_GPSRdb=reshape(s_GPSRdb,[my mx]);
        Img2D_GPSRdb=W(s_GPSRdb);
        PSNR_GPSRdb=psnr(Img2D,Img2D_GPSRdb,scale);
    end

end

MSE_BackProj=sum(error_BackProj)/TrialNum;
MSE_SPIRAL=sum(error_SPIRAL)/TrialNum;
MSE_GPSR=sum(error_GPSR)/TrialNum;
MSE_DMECME=sum(error_DMECME)/TrialNum;
MSE_ECME=sum(error_ECME)/TrialNum;
MSE_NIHT=sum(error_NIHT)/TrialNum;

if TrialNum==1
    %Plotting
    clc
    display('Now plotting...');
    figure
    subplot(2,4,1)
    imagesc(smpl_pattern);
    colormap(gray);
    box off
    axis off
    title('(a) The sampling pattern');
    subplot(2,4,2)
    imagesc(Img2D)
    colormap(gray)
    box off
    axis off
    title('(b) Raw image');
    subplot(2,4,3)
    imagesc(Img2D_BackProj)
    colormap(gray)
    box off
    axis off
    title(['(c) Back projectiom (PSNR=',num2str(PSNR_BackProj),')']);
    subplot(2,4,4)
    imagesc(Img2D_GPSR)
    colormap(gray)
    box off
    axis off
    title(['(d) GPSR (PSNR=',num2str(PSNR_GPSR),')']);
    subplot(2,4,5)
    imagesc(Img2D_ECME)
    colormap(gray)
    box off
    axis off
    title(['(e) ECME_S (PSNR=',num2str(PSNR_ECME),')']);
    subplot(2,4,6)
    imagesc(Img2D_NIHT)
    colormap(gray)
    box off
    axis off
    title(['(f) NIHT (PSNR=',num2str(PSNR_NIHT),')']);
    subplot(2,4,7)
    imagesc(Img2D_SPIRAL)
    colormap(gray)
    box off
    axis off
    title(['(g) SPIRAL_G (PSNR=',num2str(PSNR_SPIRAL),')']);
    subplot(2,4,8)
    imagesc(Img2D_DMECME)
    colormap(gray)
    box off
    axis off
    title(['(h) DM-ECME (PSNR=',num2str(PSNR_DMECME),')']);
end

save([img_name,num2str(my),'by',num2str(mx),'_RadialNum',num2str(RadialNum),'_Noise',num2str(sigma2),'_Trial',num2str(TrialNum),'.mat']);
