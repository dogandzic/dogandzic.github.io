%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                               Compressive Sensing Image Reconstruction                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Coded by Kun Qiu
%Last updated at Jun. 17, 2011

clear all
clc
close all

path(path, './subfunctions');
path(path,'./Algorithms');
path(path,'./Images');
addpath(genpath(fullfile(pwd,'./Algorithms/FPC_AS')));

%Number of radial lines
RadialNum=85;

load Wrist.mat
img_name='Wrist';
scale=max(Img2D(:))-min(Img2D(:));
[my,mx]=size(Img2D);
m=my*mx;
Imgcntr=Img2D(:);

%Sampling operator
% number of radial lines in the Fourier domain
[M,Mh,mh,mhi]=LineMask(RadialNum,mx);
OMEGA=mhi;

Phi=@(z) A_fhp(z,OMEGA);
Phit=@(z) At_fhp(z,OMEGA,mx);

%Sparsifying basis
dwt_L=8;                                     %levels of wavelet transform
wav=daubcqf(8);
W=@(z) midwt(z,wav,dwt_L);
Wt=@(z) mdwt(z,wav,dwt_L);

%Effective sensing operator
H=@(z) H_idwt1d(Phi,z,wav,dwt_L,my,mx);
Ht=@(z) Ht_dwt1d(Phit,z,wav,dwt_L,my,mx);

% taking measurements
y=Phi(Imgcntr);
N=length(y);
Nratio=N/m;

%Reconstruction
thresh=1e-14;           %Convergence tolerance for Hard thresholding methods

%solve by Back Projection
clc
display('Now Back Projection');
s_BackProj=Ht(y);
s_BackProj=reshape(s_BackProj,[my mx]);
Img2D_BackProj=W(s_BackProj);
PSNR_BackProj=psnr(Img2D,Img2D_BackProj,scale);

%solve by Difference Map Expectation-conditional Maximization Either (DM-ECME) Method
clc
display('Now DM-ECME');
s_init=zeros(m,1);
beta=1;
thresh_DM=1e-14;
MAX_ITER=2000;
r_DMECME=30000;    %Sparsity level
[s_DMECME,Count_DMECME,loglikelihood_DMECME]=DMECME(y,Phi,Phit,W,Wt,r_DMECME,'beta',beta,'InitialSig',s_init,...
                                                                                                'Thresh',thresh,'Max_Iter',MAX_ITER,'Visibility',1);
s_DMECME=reshape(s_DMECME,[my mx]);
Img2D_DMECME=W(s_DMECME);
PSNR_DMECME=psnr(Img2D,Img2D_DMECME,scale);

%solve by Sparse Poisson-Intensity Reconstruction with Gaussian noise (SPIRAL_G) method
clc
display('Now SPIRAL_G');
tau_SPIRAL=1e-7*max(abs(Ht(y)));
maxiter=2000;
miniter=0;
stopcriterion=5;
tolerance=thresh;
verbose=100;
z_init=zeros(m,1);
subtolerance=1e-5;
[Img1D_SPIRAL,Count_SPIRAL]=SPIRALTAP_mod(y,Phi,tau_SPIRAL,'penalty','ONB','AT',Phit,'W',W,'WT',Wt,'noisetype','gaussian',...
                                                            'initialization',z_init,'maxiter',maxiter,'miniter',miniter,'stopcriterion',stopcriterion,'tolerance',tolerance,...
                                                            'subtolerance',subtolerance,'monotone',0,'saveobjective',0,'savereconerror',0,'savecputime',1,...
                                                            'savesolutionpath',0,'verbose',verbose);
Img2D_SPIRAL=reshape(Img1D_SPIRAL,[my mx]);
PSNR_SPIRAL=psnr(Img2D,Img2D_SPIRAL,scale);

%solve by Expectation-conditional Maximization Either (ECME) method 
%equivalent to Iterative Hard thresholding (IHT) for this example
clc
display('Now ECME');
r_ECME=6000;
[s_ECME,Count_ECME]=hard_l0_Mterm_mod(y,H,m,r_ECME,thresh,'P_trans',Ht,'step_size',1);
s_ECME=reshape(s_ECME,[my mx]);
Img2D_ECME=W(s_ECME);
PSNR_ECME=psnr(Img2D,Img2D_ECME,scale); 

%solve by Normalized Iterative Hard Thresholding (NIHT) method
clc
display('Now NIHT');
r_NIHT=6000;
[s_NIHT,Count_NIHT]=hard_l0_Mterm_mod(y,H,m,r_NIHT,thresh,'P_trans',Ht);
s_NIHT=reshape(s_NIHT,[my mx]);
Img2D_NIHT=W(s_NIHT);
PSNR_NIHT=psnr(Img2D,Img2D_NIHT,scale); 

%solve by Fixed Point Continuation Active Set (FPC_AS) method
clc
display('Now FPC_AS');
A_FPC=A_operator(H, Ht);
tau_FPC=(1e-4)*max(abs(Ht(y)));
[s_FPC,Out_FPC]=FPC_AS(m,A_FPC,y,tau_FPC,[]);
s_FPC=reshape(s_FPC,[my mx]);
Img2D_FPC=W(s_FPC);
PSNR_FPC=psnr(Img2D,Img2D_FPC,scale);

%solve by GPSR_BB
clc
display('Now GPSR_BB');
tau_GPSR=(1e-4)*max(abs(Ht(y)));
[s_GPSR,s_GPSRdb,objective,times,debias_start,mses]=GPSR_BB(y,H,tau_GPSR,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
s_GPSR=reshape(s_GPSR,[my mx]);
Img2D_GPSR=W(s_GPSR);
PSNR_GPSR=psnr(Img2D,Img2D_GPSR,scale);
if ~isempty(s_GPSRdb)
    s_GPSRdb=reshape(s_GPSRdb,[my mx]);
    Img2D_GPSRdb=W(s_GPSRdb);
    PSNR_GPSRdb=psnr(Img2D,Img2D_GPSRdb,scale);
end

%Plotting
clc
display('Now plotting...');
figure
subplot(2,3,1)
imagesc(Img2D)
colormap(gray)
box off
axis off
title('(a) Raw image');
subplot(2,3,2)
imagesc(Img2D_BackProj)
colormap(gray)
box off
axis off
title(['(b) Back projectiom (PSNR=',num2str(PSNR_BackProj),')']);
subplot(2,3,3)
imagesc(Img2D_GPSR)
colormap(gray)
box off
axis off
title(['(c) GPSR (PSNR=',num2str(PSNR_GPSR),')']);
subplot(2,3,4)
imagesc(Img2D_ECME)
colormap(gray)
box off
axis off
title(['(d) ECME_S (PSNR=',num2str(PSNR_ECME),')']);
subplot(2,3,5)
imagesc(Img2D_SPIRAL)
colormap(gray)
box off
axis off
title(['(e) SPIRAL_G (PSNR=',num2str(PSNR_SPIRAL),')']);
subplot(2,3,6)
imagesc(Img2D_DMECME)
colormap(gray)
box off
axis off
title(['(f) DM-ECME (PSNR=',num2str(PSNR_DMECME),')']);

save([img_name,num2str(my),'by',num2str(mx),'_RadialNum',num2str(RadialNum),'.mat']);
