function [s_hat,A_index,Count,GML_record]=AHT(H,Ht,y,z_init,FIR_len,visibility)
% Automatic Hard Thresholding (AHT) routine: 
% Coded by Kun Qiu (kqiu@iastate.edu)
% updated Feb 16, 2010
% 
% 
% Function usage
% =======================================================
% INPUT(compulsory):
% H:                              the function handle that computes H*x
% Ht:                             the adjoint function handle that computes H^T*y
% y:                               the measurement column vector
% z_init:                        the initial signal estimate
% FIR_len:                   the moving average length
% 
% INPUT(optional):
% visibility:                    Option to view the reconstruction process
%                                   0: do not view
%                                   1: do view
%                                   (default=0)
% ========================================================
% OUTPUT:
% s_hat:              the signal estimate
% A_index:          the estimated support set
% Count:             Count of the number of EM iterations
% GML_record:  the GML value of final estimate
% ========================================================


if nargin<5
    error('Missing required inputs!');
end

if nargin<6
    visibility=0;
end

N=length(y);
m=length(Ht(y));
ytyN=y'*y/N;

%Initialization
z=z_init;
r=1;

expand=1;
compress=0;
exit_flag=0;
Count=0;
Cycle=1;
p=0;
A_index_record_pre=[];
GML_star=-inf;
GML_record=-inf;
state_str='Expanding';

%Main iteration
while ~exit_flag
    Count=Count+1;
    p=p+1;
    
    %One EM step
    [z_sort,z_index]=sort(abs(z),'descend');
    A_index=z_index(1:r)';
    s_A=z(A_index);
    s_hat=zeros(m,1);
    s_hat(A_index)=s_A;
    y_hat=H(s_hat);
    delta2=norm(y-y_hat)^2/N;
    z=s_hat+Ht(y-y_hat);
    GML(p)=-0.5*(N-r-2)*log(delta2/ytyN)-0.5*r*log(N/m);
    if p>=FIR_len
        MvAvgGML(p)=mean(GML(p-FIR_len+1:p));
    else
        MvAvgGML(p)=-inf;
    end
    
    if GML(p)>GML_star
        GML_star=GML(p);
        A_index_star=A_index;
        s_A_star=s_A;
        r_star=r;
        z_star=z;
    end
    
    GML_plot=GML(p);
    
    if visibility
        clc
        display(['GML=',num2str(GML_plot),' ',state_str]);
        display(['Cycle=',num2str(Cycle),' Count=',num2str(Count),' r=',num2str(r)]);
    end    
    
    if expand
        state_str='Expanding';
        if (p<=FIR_len|MvAvgGML(p)>=MvAvgGML(p-1)|GML(p)>=MvAvgGML(p-1))%&r<N/2
            %Expansion
            r=r+1;
        else
            expand=0;
            clear GML
            clear MvAvgGML
            p=0;
            compress=1;
            expand=0;
        end
    end

    if compress
        state_str='Shrinking';
        if (p<=FIR_len|MvAvgGML(p)>=MvAvgGML(p-1)|GML(p)>=MvAvgGML(p-1))&r>2            
            %compress
            r=r-1;
        else
            compress=0;
            A_index=A_index_star;
            s_A=s_A_star;
            r=r_star;
            z=z_star;
            clear GML
            clear MvAvgGML
            GML_plot=GML_star;
        end
    end%if compress

    %Reset step
    if ~(expand|compress)
        if GML_record<GML_star
            GML_record=GML_star;
            s_A_record=s_A;
            r_record=r;
            z_record=z;
            A_index_record=A_index;
            GML_star=-inf;
            z=z_init;
            Cycle=Cycle+1;
            expand=1;
            compress=0;
            p=0;
        end
        if length(union(A_index_record_pre,A_index_record))==length(intersect(A_index_record_pre,A_index_record))
            exit_flag=1;
        end
        A_index_record_pre=A_index_record;    
    end
end

A_index=A_index_record;
s_hat=zeros(m,1);
s_hat(A_index_record)=s_A_record;


