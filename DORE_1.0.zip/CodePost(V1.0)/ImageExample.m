%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                               Compressive Sensing Image Reconstruction                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Coded by Kun Qiu
%Last updated at Feb. 17, 2010

clear all
clc
close all


path(path, './subfunctions');
path(path,'./Algorithms');


RadialNum=43;

Img2D=phantom(256);
img_name='Phantom';
[my,mx]=size(Img2D);
m=my*mx;
Img2Dbar=mean(Img2D(:));
Img2Dcntr=Img2D-Img2Dbar;
Imgcntr=Img2Dcntr(:);
scale=max(Imgcntr)-min(Imgcntr);


%Sampling operator
% number of radial lines in the Fourier domain
[M,Mh,mh,mhi]=LineMask(RadialNum,mx);
OMEGA=mhi;
smpl_pattern=fftshift(M);

Phi=@(z) A_fhp(z,OMEGA);
Phit=@(z) At_fhp(z,OMEGA,mx);

% taking measurements
y=Phi(Imgcntr);
N=length(y);
Nratio=N/m;
%Effective sensing operator
dwt_L=6;                                     %levels of wavelet transform
wav=daubcqf(2);
H=@(z) H_idwt1d(Phi,z,wav,dwt_L,my,mx);
Ht=@(z) Ht_dwt1d(Phit,z,wav,dwt_L,my,mx);

W=@(z) midwt(z,wav,dwt_L);
Wt=@(z) mdwt(z,wav,dwt_L);

phantom_coeff=Wt(Img2D);
r_init=length(find(abs(phantom_coeff(:))>0));    %sparsity level for hard thresholding methods


%Reconstruction
thresh=1e-14;           %Convergence tolerance for Hard thresholding methods

%solve by Back Projection
s_BackProj=Ht(y);
s_BackProj=reshape(s_BackProj,[my mx]);
Img2D_BackProj=W(s_BackProj);
Img2D_BackProj=Img2D_BackProj+Img2Dbar;
PSNR_BackProj=psnr(Img2D,Img2D_BackProj,scale);

%solve by GPSR_BB
tic;
tau=0.1*max(abs(Ht(y)));
[s_GPSR0,s_GPSRdb0,objective,times,debias_start,mses]=GPSR_BB(y,H,tau,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
s_GPSR0=reshape(s_GPSR0,[my mx]);
Img2D_GPSR0=W(s_GPSR0);
Img2D_GPSR0=Img2D_GPSR0+Img2Dbar;
PSNR_GPSR0=psnr(Img2D,Img2D_GPSR0,scale);
t_GPSR0=toc;
if ~isempty(s_GPSRdb0)
    s_GPSRdb0=reshape(s_GPSRdb0,[my mx]);
    Img2D_GPSRdb0=W(s_GPSRdb0);
    Img2D_GPSRdb0=Img2D_GPSRdb0+Img2Dbar;
    PSNR_GPSRdb0=psnr(Img2D,Img2D_GPSRdb0,scale);
end

%solve by GPSR_BB
tic;
tau=0.001*max(abs(Ht(y)));
[s_GPSR,s_GPSRdb,objective,times,debias_start,mses]=GPSR_BB(y,H,tau,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR=toc;
s_GPSR=reshape(s_GPSR,[my mx]);
Img2D_GPSR=W(s_GPSR);
Img2D_GPSR=Img2D_GPSR+Img2Dbar;
PSNR_GPSR=psnr(Img2D,Img2D_GPSR,scale);
if ~isempty(s_GPSRdb)
    s_GPSRdb=reshape(s_GPSRdb,[my mx]);
    Img2D_GPSRdb=W(s_GPSRdb);
    Img2D_GPSRdb=Img2D_GPSRdb+Img2Dbar;
    PSNR_GPSRdb=psnr(Img2D,Img2D_GPSRdb,scale);
end

%solve by ADOREls
tic;
Len_thresh=500;          
z_init=zeros(m,1);
[s_ADORE,A_index_ADORE,Count_ADORE,Golden_Iter,USS]=ADORE(H,Ht,y,'SearchLen',Len_thresh,'Thresh',thresh);
t_ADORE=toc;
s_ADORE=reshape(s_ADORE,[my mx]);
Img2D_ADORE=W(s_ADORE);
Img2D_ADORE=Img2D_ADORE+Img2Dbar;
PSNR_ADORE=psnr(Img2D,Img2D_ADORE,scale);

%solve by DORE
tic;
z_init=zeros(m,1);
[s_DORE,A_index_DORE,Count_DORE]=DORE(H,Ht,y,r_init,'Thresh',thresh,'visibility',0);
t_DORE=toc;
z_DORE=s_DORE+Ht(y-H(s_DORE));
s_DORE=reshape(s_DORE,[my mx]);
Img2D_DORE=W(s_DORE);
Img2D_DORE=Img2D_DORE+Img2Dbar;
PSNR_DORE=psnr(Img2D,Img2D_DORE,scale);
z_DORE=reshape(z_DORE,[my mx]);
Img2D_DOREz=W(z_DORE);
Img2D_DOREz=Img2D_DOREz+Img2Dbar;
PSNR_DOREz=psnr(Img2D,Img2D_DOREz,scale);

%solve by AHT
tic;
z_init=zeros(m,1);
FIR_len=100;          %the moving average filter length
visibility=0;
[s_AHT,A_index_AHT,Count_AHT]=AHT(H,Ht,y,z_init,FIR_len,visibility);
t_AHT=toc;
z_AHT=s_AHT+Ht(y-H(s_AHT));
s_AHT=reshape(s_AHT,[my mx]);
Img2D_AHT=W(s_AHT);
Img2D_AHT=Img2D_AHT+Img2Dbar;
PSNR_AHT=psnr(Img2D,Img2D_AHT,scale);
z_AHT=reshape(z_AHT,[my mx]);
Img2D_AHTz=W(z_AHT);
Img2D_AHTz=Img2D_AHTz+Img2Dbar;
PSNR_AHTz=psnr(Img2D,Img2D_AHTz,scale);

%solve by IHTls
tic;
[s_IHT,Count_IHT]=hard_l0_Mterm_mod(y,H,m,r_init,thresh,'P_trans',Ht,'step_size',1);
t_IHT=toc;
z_IHT=s_IHT+Ht(y-H(s_IHT));
s_IHT=reshape(s_IHT,[my mx]);
Img2D_IHT=W(s_IHT);
Img2D_IHT=Img2D_IHT+Img2Dbar;
PSNR_IHT=psnr(Img2D,Img2D_IHT,scale);
z_IHT=reshape(z_IHT,[my mx]);
Img2D_IHTz=W(z_IHT);
Img2D_IHTz=Img2D_IHTz+Img2Dbar;
PSNR_IHTz=psnr(Img2D,Img2D_IHTz,scale);

%solve by NIHTls
tic;
[s_NIHT,Count_NIHT]=hard_l0_Mterm_mod(y,H,m,r_init,thresh,'P_trans',Ht);
t_NIHT=toc;
z_NIHT=s_NIHT+Ht(y-H(s_NIHT));
s_NIHT=reshape(s_NIHT,[my mx]);
Img2D_NIHT=W(s_NIHT);
Img2D_NIHT=Img2D_NIHT+Img2Dbar;
PSNR_NIHT=psnr(Img2D,Img2D_NIHT,scale);
z_NIHT=reshape(z_NIHT,[my mx]);
Img2D_NIHTz=W(z_NIHT);
Img2D_NIHTz=Img2D_NIHTz+Img2Dbar;
PSNR_NIHTz=psnr(Img2D,Img2D_NIHTz,scale);

%Plotting
figure(1)
subplot(3,2,1)
imagesc(Img2Dcntr)
colormap(gray)
box off
axis off
title('(a) Raw image');
subplot(3,2,2)
imagesc(smpl_pattern);
colormap(gray);
box off
axis off
title('(b) The sampling pattern');
subplot(3,2,3)
imagesc(Img2D_BackProj)
colormap(gray)
box off
axis off
title(['(c) Back projectiom recovery (PSNR=',num2str(PSNR_BackProj),')']);
subplot(3,2,4)
imagesc(Img2D_GPSR0)
colormap(gray)
box off
axis off
title(['(d) GPSR_0 recovery (PSNR=',num2str(PSNR_GPSR),')']);
subplot(3,2,5)
imagesc(Img2D_GPSR)
colormap(gray)
box off
axis off
title(['(e) GPSR recovery (PSNR=',num2str(PSNR_GPSR),')']);
subplot(3,2,6)
imagesc(Img2D_DORE)
colormap(gray)
box off
axis off
title(['(f) DORE recovery (PSNR=',num2str(PSNR_DORE),')']);

save([img_name,num2str(my),'by',num2str(mx),'_RadialNum',num2str(RadialNum),'_thresh',num2str(thresh),'.mat']);

