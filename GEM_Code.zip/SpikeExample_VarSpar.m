%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Quantized Compressive Sensing Reconstruction Example (1-d example)    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Coded by Kun Qiu (kqiu@iastate.edu)
%Last updated (Aug. 23, 2011)

clear all
clc
close all

path(path,'./Algorithms');

TrialNum=1000;         %number of trials
N=400;                      %number of measurements
m=500;                      %number of underlying signal length
T=20;                        %number of spikes
NumBin=3;                %number of quantization bins (3, 4, 8 or 16)
sigma2=1e-4;             %noise variance
r=45;                         %sparsity
thresh=1e-13;             %convergence threshold for the algorithms


switch NumBin
    case 3
        Quant_thresh=[-inf,-0.09,0.09,inf]; %3 bins
    case 4 
        Quant_thresh=[-inf,-0.13,0,0.13,inf]; %4 bins
    case 8 
        Quant_thresh=[-inf,-0.23,-0.13,-0.06,0,0.06,0.13,0.23,inf]; %8 bins
    case 16 
        Quant_thresh=[-inf,-0.3,-0.23,-0.17,-0.13,-0.09,-0.06,-0.03,0,0.03,0.06,0.09,0.13,0.17,0.23,0.3,inf]; %16 bins
end


for ll=1:TrialNum
    %Signal and measurement model
    Psi=eye(m);           %the sparsity basis
    Phi=randn(N,m)/sqrt(m);
    H=Phi*Psi;              %effective sensing matrix
    
    rho_H=max(svd(H));

    %Sparse signal generation
    s=zeros(m,1);
    q=randperm(m);
    s(q(1:T))=sign(randn(T,1));
    noi=sqrt(sigma2)*randn(N,1);      %noise

    %Take measurements
    y=Phi*s+noi;
    %Quantization
    u=inf*ones(N,1);
    l=-inf*ones(N,1);
    for qq=1:length(Quant_thresh)-1
        ind=intersect(find(y>=Quant_thresh(qq)),find(y<Quant_thresh(qq+1)));
        num_bin(:,qq)=length(ind);
        u(ind)=Quant_thresh(qq+1);
        l(ind)=Quant_thresh(qq);
    end
    
    
    %solve by GEM
    tic;
    stepsize=1/rho_H^2;
    [s_GEM,Count_GEM,sigma2_GEM]=GEM(H,[],l,u,r,'Visibility',0,'Thresh',thresh,'StepSize',stepsize);
    t_GEM(ll)=toc;
    error_GEM(ll)=norm(s_GEM-s)^2/m;
    
    %solve by IHT (corresponding to GEM in the limiting case)
    tic;
    stepsize=1/rho_H^2;
    [s_IHT,Count_IHT]=hard_l0_Mterm_mod(y,H,m,r,thresh,'step_size',stepsize);
    t_IHT=toc;
    error_IHT(ll)=norm(s_IHT-s)^2/m;
    
    
    %solve by FPC
    tic;
    lambda=400;
    sigma2_para=sigma2;
    tau=sigma2/rho_H^2;
    beta=0.5;
    [s_FPC,Count_FPC]=l1_fpc(H,[],l,u,sigma2_para,lambda,'tau',tau,'beta',beta,'Thresh',thresh);
    t_FPC(ll)=toc;
    error_FPC(ll)=norm(s_FPC-s)^2/m;
    
    %solve by FPCsoft (corresponding to FPC in the limiting case)
    tic;
    lambda=400;
    sigma2_para=sigma2;
    tau=sigma2/rho_H^2;
    beta=0.5;
    [s_FPCsoft,Count_FPCsoft]=l1_fpc_soft(H,[],y,sigma2_para,lambda,'tau',tau,'beta',beta,'Thresh',thresh);
    t_FPCsoft(ll)=toc;
    error_FPCsoft(ll)=norm(s_FPCsoft-s)^2/m;
    
    %solve by clairvoyant estimate
    x_LS=zeros(m,1);
    HA=H(:,q(1:T));
    x_LS(q(1:T))=HA\y;
    error_LS(ll)=norm(x_LS-s)^2/m;
    
    clc
    display(['Trial ',num2str(ll),' completed (total ',num2str(TrialNum),' trials)']);
end

MSE_IHT=sum(error_IHT)/TrialNum;
TimeAvg_IHT=sum(t_IHT)/TrialNum;
CountAvg_IHT=sum(Count_IHT)/TrialNum;

MSE_GEM=sum(error_GEM)/TrialNum;
TimeAvg_GEM=sum(t_GEM)/TrialNum;
CountAvg_GEM=sum(Count_GEM)/TrialNum;

MSE_FPC=sum(error_FPC)/TrialNum;
TimeAvg_FPC=sum(t_FPC)/TrialNum;
CountAvg_FPC=sum(Count_FPC)/TrialNum;

MSE_FPCsoft=sum(error_FPCsoft)/TrialNum;
TimeAvg_FPCsoft=sum(t_FPCsoft)/TrialNum;
CountAvg_FPCsoft=sum(Count_FPCsoft)/TrialNum;

MSE_LS=sum(error_LS)/TrialNum;

if TrialNum==1
    figure
    set(gcf,'color','white');
    subplot(5,1,1);
    stem(s,'Marker','none','linewidth',2,'color','k');
    axis([1,m,-1.5,+1.5]);
    title('True signal');
    box off
    subplot(5,1,2);
    stem(s_GEM,'Marker','none','linewidth',2,'color','k');
    axis([1,m,-1.5,+1.5]);
    title('GEM estimated signal');
    box off
    subplot(5,1,3);
    stem(s_IHT,'Marker','none','linewidth',2,'color','k');
    axis([1,m,-1.5,+1.5]);
    title('GEM_{\infty} estimated signal');
    box off
    subplot(5,1,4);
    stem(s_FPC,'Marker','none','linewidth',2,'color','k');
    axis([1,m,-1.5,+1.5]);
    title('FPC estimated signal');
    box off
    subplot(5,1,5);
    stem(s_FPCsoft,'Marker','none','linewidth',2,'color','k');
    axis([1,m,-1.5,+1.5]);
    title('FPC_{\infty} estimated signal');
    box off
else
    clear H HA Phi Psi
    save(['Spike_GEM_VarSpar_TrialNum',num2str(TrialNum),'_NumBin',num2str(NumBin),'_r',num2str(r),'_N',num2str(N),'_T',num2str(T),'_sigma2-',num2str(sigma2),'.mat']);
end

