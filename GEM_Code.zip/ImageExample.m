%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                    Quantized Compressive Sensing Image Reconstruction                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Coded by Kun Qiu
%Last updated at Aug. 23, 2011

clear all
clc
close all

path(path, './subfunctions');
path(path,'./Algorithms');
path(path,'./Images');

Nratio=0.8;                         %Downsample ratio
NumBin=16;                       %Number of quantization bins (3, 4, 8 or 16)
thresh=1e-10;

Img2D=double(imread('lena.bmp'));
img_name='Lena';
[my,mx]=size(Img2D);
m=my*mx;
Imgcntr=Img2D(:);
scale=max(Imgcntr)-min(Imgcntr);

m=length(Img2D(:));
N=round(m*Nratio);

%Sensing operator using Structurally Random Matrices
Ifull=1:m;
Phi=@(z) sro(1, z, Ifull, N, m, my, mx, '2DDCT', [], [], [], 'RS');
Phit=@(z) sro(2, z, Ifull, N, m, my, mx, '2DDCT', [], [], [], 'RS');

% taking measurements
y=Phi(Imgcntr);

%Effective sensing operator
dwt_L=6;                                     %levels of wavelet transform
wav=daubcqf(8);
H=@(z) H_idwt1d(Phi,z,wav,dwt_L,my,mx);
Ht=@(z) Ht_dwt1d(Phit,z,wav,dwt_L,my,mx);

W=@(z) midwt(z,wav,dwt_L);
Wt=@(z) mdwt(z,wav,dwt_L);

x_temp=zeros(N,1);
x_temp(round(N/2))=1;
rho_H=norm(Ht(x_temp));  %A crude estimate of the spectral norm of H

% quantization
switch NumBin 
    case 3 
        Quant_thresh=[-inf,-49,49,inf]; %3 bins
    case 4 
        Quant_thresh=[-inf,-75,0,75,inf]; %4 bins
    case 8 
        Quant_thresh=[-inf,-128,-75,-36,0,36,75,128,inf]; %8 bins
    case 16 
        Quant_thresh=[-inf,-170,-128,-98,-75,-55,-36,-17.5,0,17.5,36,55,75,98,128,170,inf]; %16 bins
end

u=inf*ones(N,1);
l=-inf*ones(N,1);
for qq=1:length(Quant_thresh)-1
    ind=intersect(find(y>=Quant_thresh(qq)),find(y<Quant_thresh(qq+1)));
    num_bin(:,qq)=length(ind);
    u(ind)=Quant_thresh(qq+1);
    l(ind)=Quant_thresh(qq);
end

%solve by GEM
tic;
s_init=zeros(m,1);
r_init=4000*Nratio;
[s_GEM,Count_GEM,sigma2_GEM,z_GEM]=GEM(H,Ht,l,u,r_init,'Visibility',1,'Thresh',thresh,'InitialSig',s_init);
t_GEM=toc;
s_GEM=reshape(s_GEM,[my mx]);
Img2D_GEM=W(s_GEM);
PSNR_GEM=psnr(Img2D,Img2D_GEM,scale);
z_GEM=reshape(z_GEM,[my mx]);
Img2D_GEMz=W(z_GEM);
PSNR_GEMz=psnr(Img2D,Img2D_GEMz,scale);
t_GEM=toc;

%solve by FPC
tic;
lambda=0.1;
sigma2_para=10;
tau=sigma2_para/rho_H^2;
beta=0.5;
[s_FPC,Count_FPC,z_FPC]=l1_fpc(H,Ht,l,u,sigma2_para,lambda,'tau',tau,'beta',beta,'Thresh',thresh);
t_FPC=toc;
A_index_FPC=find(abs(s_FPC)>0)';
s_FPC=reshape(s_FPC,[my mx]);
Img2D_FPC=W(s_FPC);
PSNR_FPC=psnr(Img2D,Img2D_FPC,scale);
z_FPC=reshape(z_FPC,[my mx]);
Img2D_FPCz=W(z_FPC);
PSNR_FPCz=psnr(Img2D,Img2D_FPCz,scale);


%Plotting
figure
subplot(2,4,[2,3])
imagesc(Img2D)
colormap(gray)
box off
axis off
title('(a) Raw image');
subplot(2,4,[5,6])
imagesc(Img2D_FPCz)
colormap(gray)
box off
axis off
title(['(b) FPC recovery (PSNR=',num2str(PSNR_FPCz),')']);
subplot(2,4,[7,8])
imagesc(Img2D_GEMz)
colormap(gray)
box off
axis off
title(['(c) GEM recovery (PSNR=',num2str(PSNR_GEMz),')']);

save([img_name,'_Nratio',num2str(Nratio),'_NumBin',num2str(NumBin),'.mat']);


