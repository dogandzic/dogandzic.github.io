function [s_hat,Count,s_nonsparse]=l1_fpc(H,Ht,l,u,sigma2,lambda,varargin)
% l1_fpc method for quantized compressed sensing
% Proposed by Argyrios Zymnis, Stephen Boyd, and Emmanuel Candes 
% in the paper "Compressed Sensing With Quantized Measurements"
% Coded by Kun Qiu (kqiu@iastate.edu)
% Last updated Aug. 23, 2011
% 
% 
% Function usage
% =======================================================
% INPUT(compulsory):
% H:                              the sensing matrix (H can be either an matrix or function handle that computes H*x)
% Ht:                             the adjoint function handle that computes H^T*y (if H is a matrix, just input [])
% l:                                the lower threshold of the quantization interval
% u:                               the lower threshold of the quantization interval
% sigma2:                     the noise variance parameter 
% lambda:                     the tunning parameter controling the sparsity level 
% 
% INPUT(optional):
% 'InitialSig':                 the mx1 initial signal estimate
%                                   (default=zeros(m,1))
% 'Thresh':                   tolerance threshold for stopping the algorithm
%                                   (default=1e-14)
% 'tau':                          the \tau parameter 
%                                  (default=1/spectral_norm(H)^2)
% 'beta':                       the continuation papameter
%                                  (default=0.5)
% ========================================================
% OUTPUT:
% s_hat:              the signal estimate
% Count:             Count of the number of FPC iterations
% s_nonsparse: the non-sparse signal estimate, useful for reconstructing approximately sparse signal
% ========================================================

if (nargin-length(varargin))~=6
    error('Missing required inputs!');
end

if isa(H, 'function_handle')
    N=length(l);
    m=length(Ht(l));
    x_temp=zeros(N,1);
    x_temp(round(N/2))=1;
    rho_H=norm(Ht(x_temp));  %A crude estimate of the spectral norm of H
else
    rho_H=max(svd(H));
    Ht=@(x) H'*x;
    H=@(x) H*x;
    N=length(l);
    m=length(Ht(l));
end

sigma=sqrt(sigma2);

%Setting default values for the optional inputs
s_init=zeros(m,1);
epsilon=1e-13;
tau=1/rho_H^2;
beta=0.5;

%Read the optional inputs
if (rem(length(varargin),2)==1)
    error('Optional inputs must go by pairs!');
else
    for i=1:2:(length(varargin)-1)
        switch upper(varargin{i})
            case upper('InitialSig')
                s_init=varargin{i+1};
            case upper('Thresh')
                epsilon=varargin{i+1};
            case upper('tau')
                tau=varargin{i+1};
            case upper('beta')
                beta=varargin{i+1};   
            otherwise
                error(['Unrecognized optional input: ''' varargin{i} '''']);
        end
    end
end

%Initialization
s_pre=s_init;
s_new=s_init;
Hs_pre=H(s_pre);
u_std=(u-Hs_pre)/sigma;
l_std=(l-Hs_pre)/sigma;
delta_f=compute_delta_f(u_std,l_std,sigma);
lambda_max=max(abs(delta_f));
lambda_tilde=lambda_max;
Count=0;

%Main Iteration
while lambda_tilde>lambda
    p=0;
    exit_flag=0;
    lambda_tilde=beta*lambda_tilde;
    while ~exit_flag
        p=p+1;
        
        Hs_pre=H(s_pre);
        u_std=(u-Hs_pre)/sigma;
        l_std=(l-Hs_pre)/sigma;
        delta_f=compute_delta_f(u_std,l_std,sigma);
        s_new=s_pre-tau*Ht(delta_f);
        s_new=sign(s_new).*max(0,abs(s_new)-tau*lambda_tilde);
        
        gap=norm(s_new-s_pre)^2/m;
        if mod(p,inf)==0
            clc
            display(['lambda=',num2str(lambda_tilde),', Iteration=',num2str(p),', gap=',num2str(gap),' (target=',num2str(epsilon),')']);
        end
        if gap<epsilon|p>=10000
            Count=Count+p;
            exit_flag=1;
        else
            s_pre=s_new;
        end
    end
end

s_hat=s_new;
Hs_pre=H(s_hat);
u_std=(u-Hs_pre)/sigma;
l_std=(l-Hs_pre)/sigma;
delta_f=compute_delta_f(u_std,l_std,sigma);
s_nonsparse=s_hat-tau*Ht(delta_f);
return;

function cdf_diff=compute_cdfdiff(u_std,l_std)
    u_std_temp=u_std;
    l_std_temp=l_std;
    ind=find(l_std>0);
    u_std_temp(ind)=-l_std(ind);
    l_std_temp(ind)=-u_std(ind);
    cdf_diff=normcdf(u_std_temp,0,1)-normcdf(l_std_temp,0,1);
return

function delta_f=compute_delta_f(u_std,l_std,sigma)
    b0 = 0.2316419;
    b1 = 0.319381530;
    b2 = -0.356563782;
    b3 = 1.781477937; 
    b4 = -1.821255978; 
    b5 = 1.330274429;

    f=@(x) b1./(1+b0.*x)+b2./(1+b0.*x).^2+b3./(1+b0.*x).^3+b4./(1+b0.*x).^4+b5./(1+b0.*x).^5;
    
    cdf_diff=compute_cdfdiff(u_std,l_std);
    pdf_diff=normpdf(u_std,0,1)-normpdf(l_std,0,1);
    delta_f=pdf_diff./cdf_diff/sigma;
    pdf_ratio=exp(-(u_std.^2-l_std.^2)/2);
    ind1=find(sign(u_std)==sign(l_std)&abs(u_std)>10&abs(l_std)>10&isfinite(pdf_ratio));
    delta_f(ind1)=-sign(u_std(ind1)).*abs( (pdf_ratio(ind1)-1)./(pdf_ratio(ind1).*f(abs(u_std(ind1))) - f(abs(l_std(ind1))) ) )/sigma;
    ind2=find(sign(u_std)==sign(l_std)&abs(u_std)>10&abs(l_std)>10&~isfinite(pdf_ratio));
    delta_f(ind2)=abs( 1./f(abs(u_std(ind2))) )/sigma;
return


