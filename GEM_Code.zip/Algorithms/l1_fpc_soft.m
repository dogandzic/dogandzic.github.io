function [s_hat,Count]=l1_fpc_soft(H,Ht,y,sigma2,lambda,varargin)
% l1_fpc (soft-thresholding) method for compressed sensing
% This is the limiting case of the l1_fpc method for quantized compressed sensing
% proposed by Argyrios Zymnis, Stephen Boyd, and Emmanuel Candes 
% in the paper "Compressed Sensing With Quantized Measurements"
% Coded by Kun Qiu (kqiu@iastate.edu)
% Last updated Aug. 23, 2011
% 
% 
% Function usage
% =======================================================
% INPUT(compulsory):
% H:                              the sensing matrix (H can be either an matrix or function handle that computes H*x)
% Ht:                             the adjoint function handle that computes H^T*y (if H is a matrix, just input [])
% y:                               the unquantized compressed sensing measurements
% sigma2:                     the noise variance parameter 
% lambda:                     the tunning parameter controling the sparsity level 
% 
% INPUT(optional):
% 'InitialSig':                 the mx1 initial signal estimate
%                                   (default=zeros(m,1))
% 'Thresh':                   tolerance threshold for stopping the algorithm
%                                   (default=1e-14)
% 'tau':                          the \tau parameter 
%                                  (default=1/spectral_norm(H)^2)
% 'beta':                       the continuation papameter
%                                  (default=0.5)
% ========================================================
% OUTPUT:
% s_hat:              the signal estimate
% Count:             Count of the number of FPC iterations
% ========================================================

if (nargin-length(varargin))~=5
    error('Missing required inputs!');
end

if isa(H, 'function_handle')
    N=length(y);
    m=length(Ht(y));
    x_temp=zeros(N,1);
    x_temp(round(N/2))=1;
    rho_H=norm(Ht(x_temp));  %A crude estimate of the spectral norm of H
else
    rho_H=max(svd(H));
    Ht=@(x) H'*x;
    H=@(x) H*x;
    N=length(y);
    m=length(Ht(y));
end

%Setting default values for the optional inputs
s_init=zeros(m,1);
epsilon=1e-13;
tau=1/rho_H^2;
beta=0.5;

%Read the optional inputs
if (rem(length(varargin),2)==1)
    error('Optional inputs must go by pairs!');
else
    for i=1:2:(length(varargin)-1)
        switch upper(varargin{i})
            case upper('InitialSig')
                s_init=varargin{i+1};
            case upper('Thresh')
                epsilon=varargin{i+1};
            case upper('tau')
                tau=varargin{i+1};
            case upper('beta')
                beta=varargin{i+1};   
            otherwise
                error(['Unrecognized optional input: ''' varargin{i} '''']);
        end
    end
end

%Initialization
s_pre=s_init;
lambda_max=max(abs(y))/sigma2;
lambda_tilde=lambda_max;
Count=0;

%Main Iteration
while lambda_tilde>lambda
    p=0;
    exit_flag=0;
    lambda_tilde=beta*lambda_tilde;
    while ~exit_flag
        p=p+1;
        
        Hs_pre=H(s_pre);
        s_new=s_pre+tau*Ht(y-Hs_pre)/sigma2;
        s_new=sign(s_new).*max(0,abs(s_new)-tau*lambda_tilde);
        
        gap=norm(s_new-s_pre)^2/m;
        if mod(p,inf)==0
            clc
            display(['lambda=',num2str(lambda_tilde),', Iteration=',num2str(p),', gap=',num2str(gap),' (target=',num2str(epsilon),')']);
        end
        if gap<epsilon|p>=10000
            Count=Count+p;
            exit_flag=1;
        else
            s_pre=s_new;
        end
    end
end

s_hat=s_new;
return;

