function [s_hat,Count,sigma2,s_EB]=GEM(H,Ht,l,u,r,varargin)
% Generalized EM Thresholding routine for quantized compressed sensing: 
% Coded by Kun Qiu (kqiu@iastate.edu)
% Last updated Aug. 23, 2011
% 
% 
% Function usage
% =======================================================
% INPUT(compulsory):
% H:                              the sensing matrix (H can be either an matrix or function handle that computes H*x)
% Ht:                             the adjoint function handle that computes H^T*y (if H is a matrix, just input [])
% l:                                the lower threshold of the quantization interval
% u:                               the lower threshold of the quantization interval
% r:                                the sparsity level of the signal to be recovered
% 
% INPUT(optional):
% 'InitialSig':                 the mx1 initial signal estimate
%                                   (default=zeros(m,1))
% 'Thresh':                   tolerance threshold for stopping the algorithm
%                                   (default=1e-14)
% 'StepSize':               the stepsize parameter
%                                   (default=1/rho_H^2/2)
% 'Visibility':                 Option to view the reconstruction process (valued in {0,1})
%                                   0: do not view
%                                   1: do view
%                                   (default=0)
% ========================================================
% OUTPUT:
% s_hat:              the signal estimate
% A_index:          the estimated support set
% Count:             Count of the number of EM iterations
% sigma2:           the variance component estimate
% s_EB;              the non-sparse empirical Bayesian signal estimate, useful for reconstructing approximately sparse signal
% ========================================================

if (nargin-length(varargin))~=5
    error('Missing required inputs!');
end

if isa(H, 'function_handle')
    N=length(l);
    m=length(Ht(l));
    x_temp=zeros(N,1);
    x_temp(round(N/2))=1;
    rho_H=norm(Ht(x_temp));  %A crude estimate of the spectral norm of H
else
    rho_H=max(svd(H));
    Ht=@(x) H'*x;
    H=@(x) H*x;
    N=length(l);
    m=length(Ht(l));
end

%Setting default values for the optional inputs
s_init=zeros(m,1);
thresh=1e-13;
Visibility=0;
epsilon=1/rho_H^2/2;

%Read the optional inputs
if (rem(length(varargin),2)==1)
    error('Optional inputs must go by pairs!');
else
    for i=1:2:(length(varargin)-1)
        switch upper(varargin{i})
            case upper('InitialSig')
                s_init=varargin{i+1};
            case upper('Thresh')
                thresh=varargin{i+1};
            case upper('StepSize')
                epsilon=varargin{i+1};
            case upper('Visibility')
                Visibility=varargin{i+1};     
            otherwise
                error(['Unrecognized optional input: ''' varargin{i} '''']);
        end
    end
end

%Initialization
s_pre=s_init;
ind_u_inf=find(u==inf);
ind_l_inf=find(l==-inf);
y_hat=(l+u)/2;
y_hat(ind_u_inf)=l(ind_u_inf);
y_hat(ind_l_inf)=u(ind_l_inf);
sigma2_pre=norm(y_hat)^2/N;
sigma_pre=sqrt(sigma2_pre);

exit_flag=0;
p=0;
while ~exit_flag
    p=p+1;
   
    Hs_pre=H(s_pre);
    u_std=(u-Hs_pre)/sigma_pre;
    l_std=(l-Hs_pre)/sigma_pre;
    cdf_diff=compute_cdfdiff(u_std,l_std);
    pdf_u_std=normpdf(u_std,0,1);
    pdf_l_std=normpdf(l_std,0,1);
    pdf_diff=pdf_u_std-pdf_l_std;
    delta=-pdf_diff./cdf_diff;
    y_hat=Hs_pre+sigma_pre*delta;
    u_std_times_pdf_u_std=u_std.*pdf_u_std;
    u_std_times_pdf_u_std(ind_u_inf)=0;
    l_std_times_pdf_l_std=l_std.*pdf_l_std;
    l_std_times_pdf_l_std(ind_l_inf)=0;
    xi=delta.^2+(u_std_times_pdf_u_std-l_std_times_pdf_l_std)./cdf_diff;
    trCov=sigma2_pre*sum(1-xi);
    
    z=s_pre+epsilon*Ht(y_hat-Hs_pre);
    [z_sort,z_index]=sort(abs(z),'descend');
    A_index=z_index(1:r)';
    s_A=z(A_index);
    s_new=zeros(m,1);
    s_new(A_index)=s_A;
    Hs_new=H(s_new);
    sigma2_new=(norm(y_hat-Hs_new)^2+trCov)/N;
    sigma_new=sqrt(sigma2_new);
            
    gap=norm(s_new-s_pre)^2/m;
    if Visibility
        clc;
        display(['Iteration=',num2str(p),', gap=',num2str(gap),' (target=',num2str(thresh),')']);
    end
    if gap<thresh
        exit_flag=1;
    else
        s_pre=s_new;
        Hs_pre=Hs_new;
        sigma2_pre=sigma2_new;
        sigma_pre=sigma_new;
     end
end

s_hat=s_new;
Count=p;
sigma2=sigma2_new;
s_EB=z;
return;

function cdf_diff=compute_cdfdiff(u_std,l_std)
    u_std_temp=u_std;
    l_std_temp=l_std;
    ind=find(l_std>0);
    u_std_temp(ind)=-l_std(ind);
    l_std_temp(ind)=-u_std(ind);
    cdf_diff=normcdf(u_std_temp,0,1)-normcdf(l_std_temp,0,1);
return


