%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Matlab Codes package of sparse signal reconstruction from 
quantized noisy measurements via GEM hard thresholding
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Version: 1.0
Date updated: Aug. 23, 2011

Authors: K. Qiu and A. Dogandzic
The Matlab codes are written and debugged by Kun Qiu.
Tested Configurations: Matlab 7.2.0.232(R2006a) on PC

The codes in this package are free programs. You are welcome 
to use them for academic purposes. If you use this code in your 
research and publications, please put a reference to our paper. 
If you find any bug or have any suggestion, please contact the 
authors through email: kqiu@iastate.edu and/or ald@iastate.edu

%%%%%%%%%%%%%%% File list %%%%%%%%%%%%%%%%
--root folder
�SpikeExample.m�:	   This is the test file of the one-dimensional 
                           spike signal reconstruction example by varying 
                           the number of measurement.

�SpikeExample_VarSpar.m�:  This is the test file of the one-dimensional 
                           spike signal reconstruction example by varying 
                           the signal sparsity level for GEM algorithm.

�ImageExample.m�:	   This is the test file of the two-dimensional 
                           �Lena� image reconstruction example.

�ImageExample2.m�:	   This is the test file of the two-dimensional 
                           �CameraMan� image reconstruction example.

--folder �Algorithms�
�GEM.m�:	           Our core GEM reconstruction function.

�hard_l0_Mterm_mod.m�:	   The (normalized) iterative hard thresholding 
                           algorithms by T. Blumensath and M. E. Davies; 
                           the original file "hard_l0_Mterm.m" can be 
                           downloaded at: 
                           http://www.personal.soton.ac.uk/tb1m08/ sparsify/sparsify.html
                           Kun Qiu has modified the original file to 
                           incorporate a common convergence criterion.

�l1_fpc.m�:	           l1_fpc method for quantized compressed sensing 
                           by Argyrios Zymnis, Stephen Boyd, and 
                           Emmanuel Candes, in the paper 
                           "Compressed Sensing With Quantized Measurements". 
                           Coded by Kun Qiu.

�l1_fpc_soft.m�:	   l1_fpc (soft-thresholding) method for compressed 
                           sensing. This is the limiting case of the l1_fpc 
                           method for quantized compressed sensing. Coded 
                           by Kun Qiu.

--folder �subfunctions�
The files in this folder are useful in implementing the sampling and sparsifying 
operators in the function handle form. Most of them are from Rice wavelet toolbox 
and can be downloaded from http://www-dsp.rice.edu/software/rice-wavelet-toolbox. 
Files �A_fhp.m�, �At_fhp�, and �LineMask� are from l1-magic suite: 
http://www.acm.caltech.edu/l1magic/. Files �H_idwt1d.m�, �Ht_dwt1d.m� and �psnr.m� 
are created or added by Kun Qiu.

--folder �Images�
The folder contains the test image.

%%%%%%%%%%%%%%% Quick Start %%%%%%%%%%%%%%%%%
As a quick demo, open �SpikeExample.m� or �ImageExample.m� file and run.

%%%%%%%%%%%%%%%% To reproduce the figures %%%%%%%%%%%%%%%%
To reproduce Fig.1.(a), we need to run �SpikeExample.m� file where we vary the 
parameters for the number of measurements �N� and the number of quantization 
bins �NumBin�.

To reproduce Fig.1.(b), we need to run �SpikeExample_VarSpar.m� file where we 
vary the parameters for the signal sparsity level �r� and the number of 
quantization bins �NumBin�.

To reproduce Fig.2.(a), we need to run �ImageExample.m� file where we vary the 
parameters for the subsampling factor �Nratio� and the number of quantization 
bins �NumBin�.

To reproduce Fig.2.(b), we need to run �ImageExample2.m� file where we vary the 
parameters for the subsampling factor �Nratio� and the number of quantization 
bins �NumBin�.











