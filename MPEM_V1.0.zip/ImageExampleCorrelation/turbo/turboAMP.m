% This Matlab function implements the Turbo iterations 
% for Turbo AMP reconstruction for Compressive Imaging
% using Markov random tree. 
% 
% turboAMP version 1.1

% Copyright (c) Subhojit Som and Philip Schniter, 2011
% Email: som.4@osu.edu, schniter@ece.osu.edu
%
% Last modified: February 10, 2013
%
% Changes:
% Version 1.1: 
% 1) Supprots function handles for A
% 2) Supports un-normalized A and signal (x)

function [ x_hat, s_hat ] = turboAMP( y, A, At, bp_param, scale, modelParams)

    
    if exist('modelParams', 'var')
        [~, f]=initializeModelParams(bp_param);
    else
        [modelParams, f]=initializeModelParams(bp_param);
    end
    
    dim=bp_param.s(end,:);
    M =length(y);
   
    if ~isa(A, 'function_handle')
        N = size(A,2);
        matrixNorm = norm(A,'fro')/sqrt(N);
        H = @(z) A*z;
        Ht = @(z) A'*z;
    else
        
        
        
        N = length(At(y));        
        numProbe=10;
        matrixNorm=0;
        for nP=1:numProbe
            matrixNorm=matrixNorm+(norm(A(randn(N,1)),'fro')^2)/N/numProbe;
        end
        matrixNorm=sqrt(matrixNorm);
        H = @(z) A(z);
        Ht = @(z) At(z);
    end
    
    
    % normalize measurement matrix
    Hn = @(z) (1/matrixNorm) * H(z);
    Htn = @(z) (1/matrixNorm) * Ht(z);

    if exist('scale', 'var')
        modelParams.Gamma_j(:,2)=modelParams.Gamma_j(:,2)*((scale*matrixNorm)^2);
	modelParams.sig2x=modelParams.sig2x*((scale*matrixNorm)^2);
        if(bp_param.gmm)
            modelParams.sig2x_small=modelParams.sig2x_small*((scale*matrixNorm)^2);
        end

        modelParams.Gamma(:,2)=modelParams.Gamma(:,2)*((scale*matrixNorm)^2);
	modelParams.sig2w=modelParams.sig2w*((scale*matrixNorm)^2);
    end

    
    signature=bp_param.s;
    Le_max=bp_param.Le_max;
    p1_approx=modelParams.p1_approx;
    level=double(reshape(f.returnLevel(),dim));

    
%     NMSEdB=NaN*ones(bp_param.iterTurbo,1);
    
    x_hat_old=zeros(N,1);
    
    Le_spdec=modelParams.Le_spdec;
    
    
    
    % iterate
    for i=1:bp_param.iterTurbo,
        % display(['Turbo Iteration: ' num2str(i) '...'])
       
        La_speq = Le_spdec;
    
        if bp_param.warm,				% warm start
            if i==1, 
                state.c = 100*modelParams.sig2x; % conv_viz2mat(computeVar(signature),signature); 	% BP: initial variances of residual 
                state.z = y;             	% BP: initial means of residual 
                state.mu = zeros(N,1);             	% BP: used when shortcut==2
            end;

            if(bp_param.projOnImage)
                [x_hat, Le_speq, state] = spe_wt(y,Hn,Htn,conv_viz2mat(La_speq,signature),bp_param,modelParams,state);
            else
                [x_hat, Le_speq, state] = spe_wt(y,Hn,Htn,La_speq,bp_param,modelParams,state);
            end
        else				% cold start
            if(bp_param.projOnImage)
                [x_hat, Le_speq] = spe_wt(y,Hn,conv_viz2mat(La_speq,signature),bp_param,modelParams);
            else
                [x_hat, Le_speq] = spe_wt(y,Hn,La_speq,bp_param,modelParams);
            end
        end

        if(bp_param.projOnImage)
            Le_speq=conv_mat2viz(Le_speq,signature);
            x_hat=conv_mat2viz(x_hat,signature);
        end
    
       
        Le_speq = max(-Le_max,min(Le_max,Le_speq)); 
      
%        x_err = x_hat-x_true;
%        NMSEdB(i) = 20*log10(norm(x_err)/norm(x_true));

    
       % sparsity decoding
       La_spdec = Le_speq; 
       [Le_spdec, s_hat] = hmt_spd(La_spdec,signature,f, p1_approx);
       Le_spdec = max(-Le_max,min(Le_max,Le_spdec));



       f.updateProbParams(s_hat);
       if(bp_param.projOnImage)
           modelParams.sig2x=conv_viz2mat(estimate_sigma(f,x_hat,s_hat,modelParams.Gamma_j),signature);
           if(bp_param.gmm)
               modelParams.sig2x_small=conv_viz2mat(estimate_sigma(f,x_hat,1-s_hat,modelParams.GammaSmall_j),signature);
           end
       else
           modelParams.sig2x=estimate_sigma(f,x_hat,s_hat,modelParams.Gamma_j);
           if(bp_param.gmm)
               modelParams.sig2x_small=estimate_sigma(f,x_hat,1-s_hat,modelParams.GammaSmall_j);
           end
       end
        if(bp_param.projOnImage)
            modelParams.sig2w=1/(M+0.5*modelParams.Gamma(1))*(sum((y-Hn(reshape(waverec2(conv_viz2mat(x_hat,signature),signature,'db1'),N,1))).^2)+0.5*modelParams.Gamma(2));   
        else
            modelParams.sig2w=1/(M+0.5*modelParams.Gamma(1))*(sum((y-Hn(x_hat)).^2)+0.5*modelParams.Gamma(2));
        end
       p1_approx=(modelParams.Beta_approx(1)+numel(s_hat & (level(:)==-1)))/(sum(modelParams.Beta_approx)+numel(level(:)==-1));





        diff=norm(x_hat-x_hat_old);
        x_hat_old=x_hat;
        if(diff<bp_param.tolTurbo)
            % display(['Turbo done at iteration ' num2str(i)]);
            break;
        end

    end %iter

     x_hat = x_hat / matrixNorm;

     if(bp_param.projOnImage)
         x_hat=reshape(x_hat,dim);
         x_hat=wave_mat2vec(x_hat,signature);
         x_hat=waverec2(x_hat,signature,'db1');
         x_hat=x_hat(:);
     end
     



end

