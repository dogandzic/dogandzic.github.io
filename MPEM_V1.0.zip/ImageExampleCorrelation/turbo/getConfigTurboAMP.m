% This Matlab function sets the algorithm parameters 
% for the Turbo AMP reconstruction for Compressive Imaging. 
% 
% turboAMP version 1.1 
% Copyright (c) Subhojit Som and Philip Schniter, 2013
% Email: som.4@osu.edu, schniter@ece.osu.edu
%
% Last modified: February 10, 2013

function [ params ] = getConfigTurboAMP()


    %%% settings for turbo AMP algorithm
    params.iterTurbo=10;   % number of turbo iterations
    params.tolTurbo=1e-5;  % tolerance for convergnece of turbo
    params.warm=1;         % warm start for turbo
    params.tolAMP=1e-5;    % tolerance for convergence of AMP
    params.iterAMP=10;     % number of AMP iterations
    params.gmm=1;          % 0: Bernoulli-Gaussian model, 1: Gaussian mixture model
    params.Le_max=20;      % maximum value of extrinsic log-likelihood 
    params.highSNR=true;   % the SNR is high, make it false for low snr 

    
end

