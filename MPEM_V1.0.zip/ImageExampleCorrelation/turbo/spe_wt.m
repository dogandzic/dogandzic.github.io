% This Matlab function implements the Sparsity Pattern
% Equalization (SPE) for Turbo AMP reconstruction for Compressive Imaging
% using Markov random tree. 
% 
% turboAMP version 1.1 
% Copyright (c) Subhojit Som and Philip Schniter, 2011
% Email: som.4@osu.edu, schniter@ece.osu.edu
%
% Last modified: February 10, 2013
%
% Changes:
% Version 1.1: 
% 1) Supprots function handles for A
% 2) Supports un-normalized A and signal (x)

function [x_hat, Le, state_out] = spe_wt(y, H, Ht, La, params, modelParams, state_in)



    M =length(y);
    N = length(Ht(y));
    
 
    sig2w = modelParams.sig2w;
    sig2xu = modelParams.sig2x;	
    if(params.gmm)
        sig2xu_small=modelParams.sig2x_small;
    end
    tol = params.tolAMP;
    iterMax = params.iterAMP;
 
    if length(sig2xu) == 1, sig2xu = sig2xu*ones(N,1); end;
    if(params.gmm)
        if length(sig2xu_small) == 1, sig2xu_small = sig2xu_small*ones(N,1); end;
    end

 % initialize algorithm state
    if (nargin==6),
        c = 100*sig2xu; 		% variance of residual 
        mu = zeros(N,1);		% posterior means
        z = y;
    elseif nargin==7,
        c = state_in.c;
        z = state_in.z;
        mu = state_in.mu;
    end

    sig2x = sig2xu;
    if(params.gmm)
        sig2x_small =sig2xu_small;
    end
 
 % initialize
    lam = 1./(1+exp(-La));	% prior bit probabilities
    oneN = ones(N,1);
    %  oneM = ones(M,1);

    x_hat_old=zeros(N,1);
    k=0;

%  for k=1:iter,
    while(1)
        k=k+1;

        if(params.projOnImage)
            theta =  reshape(wavedec2(reshape(Ht(z),params.s(end,:)),params.numLevels,'db1'),N,1)+ mu; % mean of projected residual
        else
            theta =  Ht(z) + mu;	% mean of projected residual
        end

  % output messages
        if(params.gmm)
            alpha_small=sig2x_small./(c+sig2x_small);
        end
        alpha = sig2x./(c+sig2x);
        if(params.gmm)
            beta = (oneN-lam)./lam.*sqrt((c+sig2x)./(c+sig2x_small));
            zeta = 0.5*(sig2x-sig2x_small)./(c+sig2x_small)./(c+sig2x);
        else
            beta = (oneN-lam)./lam.*sqrt((c+sig2x)./c);
            zeta = 0.5*sig2x./c./(c+sig2x);
        end
        gam = beta.*exp(-zeta.*(theta.^2));
        if(params.gmm)
            mu = (alpha+alpha_small.*gam)./(gam+1).*theta; % posterior coef means
        else
            mu = alpha./(gam+1).*theta;
        end
        x_hat = mu; % ./normA;				% remove unit-column-norm-A scaling 
        if(params.gmm)
            v = gam./((1+gam).^2).*(theta.^2).*(alpha-alpha_small).^2+ mu.*c./theta;
        else
            v = gam.*(mu.^2) + mu.*c./theta;	% posterior coef variances
        end
  
        Le = log((1-lam)./lam./gam);
 
        if(params.gmm)
            deriv = (gam.*alpha_small.*(1-2*zeta.*(theta.^2)./(gam+1)) + alpha.*(1+2*zeta.*(theta.^2).*gam./(gam+1)))./(1+gam);
        else
            deriv = alpha.*(gam.*(1+2*zeta.*(theta.^2))+1)./((gam+1).^2);
        end
        c = (sig2w + sum(v)/M)*ones(N,1);		% variances of residual (a further shortcut)

        if(params.projOnImage)
            z = y - H(reshape(waverec2(mu,params.s,'db1'),N,1)) + z*sum(deriv)/M;		% incorporate onsager term 
        else
            z = y - H(mu) + z*sum(deriv)/M;		
        end
   
   
        diff=norm(x_hat-x_hat_old);
        x_hat_old=x_hat;

 
        if(diff<tol)
            % display(['SPE done at iteration ' num2str(k)]);
            break;
        end
        if(k== iterMax)
            % display(['SPE reached maximum iterations '  num2str(k)]);
            break;
        end
    end;% k 

     % output state for warm start
     state_out.c = c;
     state_out.z = z;
     state_out.mu = mu;
end


