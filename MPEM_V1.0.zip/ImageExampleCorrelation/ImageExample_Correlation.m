%%%% Compressive Sensing 2-D Image Example %%%%
% 
% Coded by Zhao Song, ECpE, ISU
% Email: zhaosong@iastate.edu
% Last modified on: Aug. 4th, 2013


clear all;
close all; 
clc;

Nratio=0.3;   % N/p
thresh=1e-2;  % convergence threshold for hard thresholding methods   

num_MC=10;

covc=0.2;
    
path(path,'./utils/');
path(path,'./hmt/');
path(path,'./turbo/');
path(path, './subfunctions');
path(path,'./Algorithms');
addpath(genpath(fullfile(pwd,'./Algorithms/FPC_AS')));

Nerror_tAMP=zeros(num_MC,1);
Nerror_mpem=zeros(num_MC,1);
Nerror_mpem_opt=zeros(num_MC,1);
Nerror_fpc_as1=zeros(num_MC,1);
Nerror_fpc_as2=zeros(num_MC,1);
Nerror_fpc_as3=zeros(num_MC,1);
Nerror_fpc_as4=zeros(num_MC,1);
Nerror_fpc_as5=zeros(num_MC,1);
Nerror_fpc_as6=zeros(num_MC,1);
Nerror_fpc_as7=zeros(num_MC,1);
Nerror_fpc_as8=zeros(num_MC,1);
Nerror_fpc_as9=zeros(num_MC,1);
Nerror_GPSR1=zeros(num_MC,1);
Nerror_GPSR2=zeros(num_MC,1);
Nerror_GPSR3=zeros(num_MC,1);
Nerror_GPSR4=zeros(num_MC,1);
Nerror_GPSR5=zeros(num_MC,1);
Nerror_GPSR6=zeros(num_MC,1);
Nerror_GPSR7=zeros(num_MC,1);
Nerror_GPSR8=zeros(num_MC,1);
Nerror_GPSR9=zeros(num_MC,1);
Nerror_GPSRdb1=zeros(num_MC,1);
Nerror_GPSRdb2=zeros(num_MC,1);
Nerror_GPSRdb3=zeros(num_MC,1);
Nerror_GPSRdb4=zeros(num_MC,1);
Nerror_GPSRdb5=zeros(num_MC,1);
Nerror_GPSRdb6=zeros(num_MC,1);
Nerror_GPSRdb7=zeros(num_MC,1);
Nerror_GPSRdb8=zeros(num_MC,1);
Nerror_GPSRdb9=zeros(num_MC,1);
Nerror_IHT_tree=zeros(num_MC,1);
Nerror_NIHT=zeros(num_MC,1);
Nerror_vb=zeros(num_MC,1);
Nerror_vb2=zeros(num_MC,1);


t_tAMP=zeros(num_MC,1);
t_mpem=zeros(num_MC,1);
t_fpc_as1=zeros(num_MC,1);
t_fpc_as2=zeros(num_MC,1);
t_fpc_as3=zeros(num_MC,1);
t_fpc_as4=zeros(num_MC,1);
t_fpc_as5=zeros(num_MC,1);
t_fpc_as6=zeros(num_MC,1);
t_fpc_as7=zeros(num_MC,1);
t_fpc_as8=zeros(num_MC,1);
t_fpc_as9=zeros(num_MC,1);
t_GPSR1=zeros(num_MC,1);
t_GPSR2=zeros(num_MC,1);
t_GPSR3=zeros(num_MC,1);
t_GPSR4=zeros(num_MC,1);
t_GPSR5=zeros(num_MC,1);
t_GPSR6=zeros(num_MC,1);
t_GPSR7=zeros(num_MC,1);
t_GPSR8=zeros(num_MC,1);
t_GPSR9=zeros(num_MC,1);
t_IHT_tree=zeros(num_MC,1);
t_NIHT=zeros(num_MC,1);
t_vb=zeros(num_MC,1);
t_vb2=zeros(num_MC,1);

%%% read image file %%% 
img_name='cameraman';
X=imread('cameraman.tif');
X=double(X);
X=X(21:148,71:198);
Img2D=X;
[my,mx]=size(Img2D);
scale=max(Img2D(:))-min(Img2D(:));
Img2Dbar=mean(Img2D(:));
Xcntr=Img2D-Img2Dbar;
X=Xcntr;
dim=size(Img2D);       % dimension of the image
p=prod(dim);           % total number of pixels
projonimage=0;

SNRdB_true=Inf;        % SNR  in dB 
numLevels=4;           % wavelet tree depth 

%%% settings for turbo AMP algorithm

params.projOnImage=0;  % 0: proj on wavelet trandsform, 1: proj on image

%%% wavelet trandform of the image %%%
[waveC, signature]=wavedec2(X,numLevels,'db1');
iW=wave_vec2mat(waveC,signature);

if(params.projOnImage) 
    x_true=X(:);
else
    x_true=iW(:);
end

N=round(Nratio*p);     % Number of measurements 

cov=covc.^(toeplitz([0:N-1]));

for jj=1:num_MC

Phi0=randn(N, p);
Phi0=(chol(cov))'*Phi0;
rho_H=max(svds(Phi0));
Phi=Phi0/rho_H;         % we plan to add aribitary rho_Phi in the future      
Phit=Phi';

H=@(z) Phi*z;
Ht=@(z) Phit*z;

W=@(z) waverec2(z,signature,'db1');
Wt=@(z) wavedec2(z,dwt_L,'db1');

% Take the measurement
y = Phi*x_true;

sig2w_true=norm(y)^2/N*10^(-SNRdB_true/10);     
w=sqrt(sig2w_true)*randn(N,1);
y=y+w;


%%%%%%%%%%%%%%%%%%%%% Solve by turbo-AMP with FunctionHandle version

params = getConfigTurboAMP();
params.projOnImage=0;  % 0: proj on wavelet trandsform, 1: proj on image
params.numLevels=numLevels;
params.s=signature;

xRange=255; 

tic
[x_hat, s_hat]=turboAMP(y,Phi,Phit,params,xRange);
t_tAMP(jj)=toc;
x_hat=reshape(x_hat, my, mx);
x_hat=wave_mat2vec(x_hat, signature);
Img_tAMP=W(x_hat);
Img_tAMP=Img_tAMP+Img2Dbar;
PSNR_tAMP=psnr(Img2D,Img_tAMP,scale);
Nerror_tAMP(jj)=(norm(Img2D(:)-Img_tAMP(:)))^2/(norm(Img2D(:)))^2;

clear params f

%%%%%%%%%%%%%%%%%%%%% Solve by TSWCSvb
theta0=waveC(:);
v=Phi*theta0;
[IdxParent, IdxChildren, Ms]=WaveRelation2D(waveC, signature);
tic;
s_vb = TSWCSvb_mod(Phi, v, Ms, IdxParent', IdxChildren');
t_vb(jj) = toc;
s_vb = s_vb(:);
Img_VB=W(s_vb);    
Img_VB=Img_VB+Img2Dbar;
PSNR_VB=psnr(Img2D,Img_VB,scale);
Nerror_vb(jj)= (norm(Img2D(:)-Img_VB(:)))^2/(norm(Img2D(:)))^2;

tic;
s_vb2 = TSWCSvb(Phi, v, Ms, IdxParent', IdxChildren');
t_vb2(jj) = toc;
s_vb2 = s_vb2(:);
Img_VB2=W(s_vb2);    
Img_VB2=Img_VB2+Img2Dbar;
PSNR_VB2=psnr(Img2D,Img_VB2,scale);
Nerror_vb2(jj)= (norm(Img2D(:)-Img_VB2(:)))^2/(norm(Img2D(:)))^2;

%%%%%%%%%%%%%%%%%%%%% Solve by MP-EM

Img2Dparas.W=W;
Img2Dparas.scale=scale;
Img2Dparas.bar=Img2Dbar;
Img2Dparas.img=Img2D;
Img2Dparas.signature=signature;

% Parameters used in MP-EM
paras.Ph=0.2;
paras.Pl=1e-5;
paras.Proot=0.2;
paras.gamma2=1000;
paras.epsilon2=0.1;
paras.signature=signature;
paras.threshold=thresh;
paras.projonimage=projonimage;
paras.visibility=0;
paras.gridlength=16;
paras.d=2;

tic;
[s_hat_mpem,q_hat_mpem,posterior_mpem,object_prob_mpem,Count_mpem,sigma2_mpem,sparsity_mpem,error_mpem, PSNRs, Errors]=MPEM(y,H,Ht,numLevels,paras,Img2Dparas);
t_mpem(jj)=toc;
s_hat_mpem=reshape(s_hat_mpem, my, mx);
s_hat_mpem=wave_mat2vec(s_hat_mpem,signature);
Img2D_mpem=W(s_hat_mpem);
Img2D_mpem=Img2D_mpem+Img2Dbar;
PSNR_mpem=psnr(Img2D,Img2D_mpem,scale);
PSNR_mpem_opt=max(PSNRs);
Nerror_mpem(jj)=(norm(Img2D(:)-Img2D_mpem(:)))^2/(norm(Img2D(:)))^2;
Nerror_mpem_opt(jj)=min(Errors);


%%%%%%%%%%%%%%%%%%%%% Solve by FPC_AS
M=[];
opts.record=-1;

mu_as1=1e-1*max(abs(Ht(y)));
tic
[s_fpc_as1,fpc_as_out1]=FPC_AS(p,Phi,y,mu_as1,M,opts);
t_fpc_as1(jj)=toc;
s_fpc_as1=reshape(s_fpc_as1, my, mx);
s_fpc_as1=wave_mat2vec(s_fpc_as1, signature);
Img2D_fpc_as1=W(s_fpc_as1);
Img2D_fpc_as1=Img2D_fpc_as1+Img2Dbar;
PSNR_fpc_as1=psnr(Img2D,Img2D_fpc_as1,scale);
Nerror_fpc_as1(jj)=(norm(Img2D(:)-Img2D_fpc_as1(:)))^2/(norm(Img2D(:)))^2;

mu_as2=1e-2*max(abs(Ht(y)));
tic
[s_fpc_as2,fpc_as_out2]=FPC_AS(p,Phi,y,mu_as2,M,opts);
t_fpc_as2(jj)=toc;
s_fpc_as2=reshape(s_fpc_as2, my, mx);
s_fpc_as2=wave_mat2vec(s_fpc_as2, signature);
Img2D_fpc_as2=W(s_fpc_as2);
Img2D_fpc_as2=Img2D_fpc_as2+Img2Dbar;
PSNR_fpc_as2=psnr(Img2D,Img2D_fpc_as2,scale);
Nerror_fpc_as2(jj)=(norm(Img2D(:)-Img2D_fpc_as2(:)))^2/(norm(Img2D(:)))^2;

mu_as3=1e-3*max(abs(Ht(y)));
tic
[s_fpc_as3,fpc_as_out3]=FPC_AS(p,Phi,y,mu_as3,M,opts);
t_fpc_as3(jj)=toc;
s_fpc_as3=reshape(s_fpc_as3, my, mx);
s_fpc_as3=wave_mat2vec(s_fpc_as3, signature);
Img2D_fpc_as3=W(s_fpc_as3);
Img2D_fpc_as3=Img2D_fpc_as3+Img2Dbar;
PSNR_fpc_as3=psnr(Img2D,Img2D_fpc_as3,scale);
Nerror_fpc_as3(jj)=(norm(Img2D(:)-Img2D_fpc_as3(:)))^2/(norm(Img2D(:)))^2;


mu_as4=1e-4*max(abs(Ht(y)));
tic
[s_fpc_as4,fpc_as_out4]=FPC_AS(p,Phi,y,mu_as4,M,opts);
t_fpc_as4(jj)=toc;
s_fpc_as4=reshape(s_fpc_as4, my, mx);
s_fpc_as4=wave_mat2vec(s_fpc_as4, signature);
Img2D_fpc_as4=W(s_fpc_as4);
Img2D_fpc_as4=Img2D_fpc_as4+Img2Dbar;
PSNR_fpc_as4=psnr(Img2D,Img2D_fpc_as4,scale);
Nerror_fpc_as4(jj)=(norm(Img2D(:)-Img2D_fpc_as4(:)))^2/(norm(Img2D(:)))^2;

mu_as5=1e-5*max(abs(Ht(y)));
tic
[s_fpc_as5,fpc_as_out5]=FPC_AS(p,Phi,y,mu_as5,M,opts);
t_fpc_as5(jj)=toc;
s_fpc_as5=reshape(s_fpc_as5, my, mx);
s_fpc_as5=wave_mat2vec(s_fpc_as5, signature);
Img2D_fpc_as5=W(s_fpc_as5);
Img2D_fpc_as5=Img2D_fpc_as5+Img2Dbar;
PSNR_fpc_as5=psnr(Img2D,Img2D_fpc_as5,scale);
Nerror_fpc_as5(jj)=(norm(Img2D(:)-Img2D_fpc_as5(:)))^2/(norm(Img2D(:)))^2;

mu_as6=1e-6*max(abs(Ht(y)));
tic
[s_fpc_as6,fpc_as_out6]=FPC_AS(p,Phi,y,mu_as6,M,opts);
t_fpc_as6(jj)=toc;
s_fpc_as6=reshape(s_fpc_as6, my, mx);
s_fpc_as6=wave_mat2vec(s_fpc_as6, signature);
Img2D_fpc_as6=W(s_fpc_as6);
Img2D_fpc_as6=Img2D_fpc_as6+Img2Dbar;
PSNR_fpc_as6=psnr(Img2D,Img2D_fpc_as6,scale);
Nerror_fpc_as6(jj)=(norm(Img2D(:)-Img2D_fpc_as6(:)))^2/(norm(Img2D(:)))^2;

mu_as7=1e-7*max(abs(Ht(y)));
tic
[s_fpc_as7,fpc_as_out7]=FPC_AS(p,Phi,y,mu_as7,M,opts);
t_fpc_as7(jj)=toc;
s_fpc_as7=reshape(s_fpc_as7, my, mx);
s_fpc_as7=wave_mat2vec(s_fpc_as7, signature);
Img2D_fpc_as7=W(s_fpc_as7);
Img2D_fpc_as7=Img2D_fpc_as7+Img2Dbar;
PSNR_fpc_as7=psnr(Img2D,Img2D_fpc_as7,scale);
Nerror_fpc_as7(jj)=(norm(Img2D(:)-Img2D_fpc_as7(:)))^2/(norm(Img2D(:)))^2;

mu_as8=1e-8*max(abs(Ht(y)));
tic
[s_fpc_as8,fpc_as_out8]=FPC_AS(p,Phi,y,mu_as8,M,opts);
t_fpc_as8(jj)=toc;
s_fpc_as8=reshape(s_fpc_as8, my, mx);
s_fpc_as8=wave_mat2vec(s_fpc_as8, signature);
Img2D_fpc_as8=W(s_fpc_as8);
Img2D_fpc_as8=Img2D_fpc_as8+Img2Dbar;
PSNR_fpc_as8=psnr(Img2D,Img2D_fpc_as8,scale);
Nerror_fpc_as8(jj)=(norm(Img2D(:)-Img2D_fpc_as8(:)))^2/(norm(Img2D(:)))^2;

mu_as9=1e-9*max(abs(Ht(y)));
tic
[s_fpc_as9,fpc_as_out9]=FPC_AS(p,Phi,y,mu_as9,M,opts);
t_fpc_as9(jj)=toc;
s_fpc_as9=reshape(s_fpc_as9, my, mx);
s_fpc_as9=wave_mat2vec(s_fpc_as9, signature);
Img2D_fpc_as9=W(s_fpc_as9);
Img2D_fpc_as9=Img2D_fpc_as9+Img2Dbar;
PSNR_fpc_as9=psnr(Img2D,Img2D_fpc_as9,scale);
Nerror_fpc_as9(jj)=(norm(Img2D(:)-Img2D_fpc_as9(:)))^2/(norm(Img2D(:)))^2;


%%%%%%%%%%%%%%%%%%%%% Solve by GPSR_BB

tau1=1e-1*max(abs(Ht(y)));
tic;
[s_GPSR1,s_GPSRdb1,objective1,times1,debias_start1,mses1]=GPSR_BB(y,H,tau1,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR1(jj)=toc;
s_GPSR1=reshape(s_GPSR1, my, mx);
s_GPSR1=wave_mat2vec(s_GPSR1, signature);
Img2D_GPSR1=W(s_GPSR1);
Img2D_GPSR1=Img2D_GPSR1+Img2Dbar;
PSNR_GPSR1=psnr(Img2D,Img2D_GPSR1,scale);
Nerror_GPSR1(jj)=(norm(Img2D(:)-Img2D_GPSR1(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb1)
    s_GPSRdb1=reshape(s_GPSRdb1, my, mx);
    s_GPSRdb1=wave_mat2vec(s_GPSRdb1, signature);
    Img2D_GPSRdb1=W(s_GPSRdb1);
    Img2D_GPSRdb1=Img2D_GPSRdb1+Img2Dbar;
    PSNR_GPSRdb1=psnr(Img2D,Img2D_GPSRdb1,scale);
    Nerror_GPSRdb1(jj)=(norm(Img2D(:)-Img2D_GPSRdb1(:)))^2/(norm(Img2D(:)))^2;
end

tau2=1e-2*max(abs(Ht(y)));
tic;
[s_GPSR2,s_GPSRdb2,objective2,times2,debias_start2,mses2]=GPSR_BB(y,H,tau2,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR2(jj)=toc;
s_GPSR2=reshape(s_GPSR2, my, mx);
s_GPSR2=wave_mat2vec(s_GPSR2, signature);
Img2D_GPSR2=W(s_GPSR2);
Img2D_GPSR2=Img2D_GPSR2+Img2Dbar;
PSNR_GPSR2=psnr(Img2D,Img2D_GPSR2,scale);
Nerror_GPSR2(jj)=(norm(Img2D(:)-Img2D_GPSR2(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb2)
    s_GPSRdb2=reshape(s_GPSRdb2, my, mx);
    s_GPSRdb2=wave_mat2vec(s_GPSRdb2, signature);
    Img2D_GPSRdb2=W(s_GPSRdb2);
    Img2D_GPSRdb2=Img2D_GPSRdb2+Img2Dbar;
    PSNR_GPSRdb2=psnr(Img2D,Img2D_GPSRdb2,scale);
    Nerror_GPSRdb2(jj)=(norm(Img2D(:)-Img2D_GPSRdb2(:)))^2/(norm(Img2D(:)))^2;
end

tau3=1e-3*max(abs(Ht(y)));
tic;
[s_GPSR3,s_GPSRdb3,objective3,times3,debias_start3,mses3]=GPSR_BB(y,H,tau3,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR3(jj)=toc;
s_GPSR3=reshape(s_GPSR3, my, mx);
s_GPSR3=wave_mat2vec(s_GPSR3, signature);
Img2D_GPSR3=W(s_GPSR3);
Img2D_GPSR3=Img2D_GPSR3+Img2Dbar;
PSNR_GPSR3=psnr(Img2D,Img2D_GPSR3,scale);
Nerror_GPSR3(jj)=(norm(Img2D(:)-Img2D_GPSR3(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb3)
    s_GPSRdb3=reshape(s_GPSRdb3, my, mx);
    s_GPSRdb3=wave_mat2vec(s_GPSRdb3, signature);
    Img2D_GPSRdb3=W(s_GPSRdb3);
    Img2D_GPSRdb3=Img2D_GPSRdb3+Img2Dbar;
    PSNR_GPSRdb3=psnr(Img2D,Img2D_GPSRdb3,scale);
    Nerror_GPSRdb3(jj)=(norm(Img2D(:)-Img2D_GPSRdb3(:)))^2/(norm(Img2D(:)))^2;
end

tau4=1e-4*max(abs(Ht(y)));
tic;
[s_GPSR4,s_GPSRdb4,objective4,times4,debias_start4,mses4]=GPSR_BB(y,H,tau4,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR4(jj)=toc;
s_GPSR4=reshape(s_GPSR4, my, mx);
s_GPSR4=wave_mat2vec(s_GPSR4, signature);
Img2D_GPSR4=W(s_GPSR4);
Img2D_GPSR4=Img2D_GPSR4+Img2Dbar;
PSNR_GPSR4=psnr(Img2D,Img2D_GPSR4,scale);
Nerror_GPSR4(jj)=(norm(Img2D(:)-Img2D_GPSR4(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb4)
    s_GPSRdb4=reshape(s_GPSRdb4, my, mx);
    s_GPSRdb4=wave_mat2vec(s_GPSRdb4, signature);
    Img2D_GPSRdb4=W(s_GPSRdb4);
    Img2D_GPSRdb4=Img2D_GPSRdb4+Img2Dbar;
    PSNR_GPSRdb4=psnr(Img2D,Img2D_GPSRdb4,scale);
    Nerror_GPSRdb4(jj)=(norm(Img2D(:)-Img2D_GPSRdb4(:)))^2/(norm(Img2D(:)))^2;
end

tau5=1e-5*max(abs(Ht(y)));
tic;
[s_GPSR5,s_GPSRdb5,objective5,times5,debias_start5,mses5]=GPSR_BB(y,H,tau5,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR5(jj)=toc;
s_GPSR5=reshape(s_GPSR5, my, mx);
s_GPSR5=wave_mat2vec(s_GPSR5, signature);
Img2D_GPSR5=W(s_GPSR5);
Img2D_GPSR5=Img2D_GPSR5+Img2Dbar;
PSNR_GPSR5=psnr(Img2D,Img2D_GPSR5,scale);
Nerror_GPSR5(jj)=(norm(Img2D(:)-Img2D_GPSR5(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb5)
    s_GPSRdb5=reshape(s_GPSRdb5, my, mx);
    s_GPSRdb5=wave_mat2vec(s_GPSRdb5, signature);
    Img2D_GPSRdb5=W(s_GPSRdb5);
    Img2D_GPSRdb5=Img2D_GPSRdb5+Img2Dbar;
    PSNR_GPSRdb5=psnr(Img2D,Img2D_GPSRdb5,scale);
    Nerror_GPSRdb5(jj)=(norm(Img2D(:)-Img2D_GPSRdb5(:)))^2/(norm(Img2D(:)))^2;
end

tau6=1e-6*max(abs(Ht(y)));
tic;
[s_GPSR6,s_GPSRdb6,objective6,times6,debias_start6,mses6]=GPSR_BB(y,H,tau6,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR6(jj)=toc;
s_GPSR6=reshape(s_GPSR6, my, mx);
s_GPSR6=wave_mat2vec(s_GPSR6, signature);
Img2D_GPSR6=W(s_GPSR6);
Img2D_GPSR6=Img2D_GPSR6+Img2Dbar;
PSNR_GPSR6=psnr(Img2D,Img2D_GPSR6,scale);
Nerror_GPSR6(jj)=(norm(Img2D(:)-Img2D_GPSR6(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb6)
    s_GPSRdb6=reshape(s_GPSRdb6, my, mx);
    s_GPSRdb6=wave_mat2vec(s_GPSRdb6, signature);
    Img2D_GPSRdb6=W(s_GPSRdb6);
    Img2D_GPSRdb6=Img2D_GPSRdb6+Img2Dbar;
    PSNR_GPSRdb6=psnr(Img2D,Img2D_GPSRdb6,scale);
    Nerror_GPSRdb6(jj)=(norm(Img2D(:)-Img2D_GPSRdb6(:)))^2/(norm(Img2D(:)))^2;
end

tau7=1e-7*max(abs(Ht(y)));
tic;
[s_GPSR7,s_GPSRdb7,objective7,times7,debias_start7,mses7]=GPSR_BB(y,H,tau7,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR7(jj)=toc;
s_GPSR7=reshape(s_GPSR7, my, mx);
s_GPSR7=wave_mat2vec(s_GPSR7, signature);
Img2D_GPSR7=W(s_GPSR7);
Img2D_GPSR7=Img2D_GPSR7+Img2Dbar;
PSNR_GPSR7=psnr(Img2D,Img2D_GPSR7,scale);
Nerror_GPSR7(jj)=(norm(Img2D(:)-Img2D_GPSR7(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb7)
    s_GPSRdb7=reshape(s_GPSRdb7, my, mx);
    s_GPSRdb7=wave_mat2vec(s_GPSRdb7, signature);
    Img2D_GPSRdb7=W(s_GPSRdb7);
    Img2D_GPSRdb7=Img2D_GPSRdb7+Img2Dbar;
    PSNR_GPSRdb7=psnr(Img2D,Img2D_GPSRdb7,scale);
    Nerror_GPSRdb7(jj)=(norm(Img2D(:)-Img2D_GPSRdb7(:)))^2/(norm(Img2D(:)))^2;
end

tau8=1e-8*max(abs(Ht(y)));
tic;
[s_GPSR8,s_GPSRdb8,objective8,times8,debias_start8,mses8]=GPSR_BB(y,H,tau8,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR8(jj)=toc;
s_GPSR8=reshape(s_GPSR8, my, mx);
s_GPSR8=wave_mat2vec(s_GPSR8, signature);
Img2D_GPSR8=W(s_GPSR8);
Img2D_GPSR8=Img2D_GPSR8+Img2Dbar;
PSNR_GPSR8=psnr(Img2D,Img2D_GPSR8,scale);
Nerror_GPSR8(jj)=(norm(Img2D(:)-Img2D_GPSR8(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb8)
    s_GPSRdb8=reshape(s_GPSRdb8, my, mx);
    s_GPSRdb8=wave_mat2vec(s_GPSRdb8, signature);
    Img2D_GPSRdb8=W(s_GPSRdb8);
    Img2D_GPSRdb8=Img2D_GPSRdb8+Img2Dbar;
    PSNR_GPSRdb8=psnr(Img2D,Img2D_GPSRdb8,scale);
    Nerror_GPSRdb8(jj)=(norm(Img2D(:)-Img2D_GPSRdb8(:)))^2/(norm(Img2D(:)))^2;
end

tau9=1e-9*max(abs(Ht(y)));
tic;
[s_GPSR9,s_GPSRdb9,objective9,times9,debias_start9,mses9]=GPSR_BB(y,H,tau9,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR9(jj)=toc;
s_GPSR9=reshape(s_GPSR9, my, mx);
s_GPSR9=wave_mat2vec(s_GPSR9, signature);
Img2D_GPSR9=W(s_GPSR9);
Img2D_GPSR9=Img2D_GPSR9+Img2Dbar;
PSNR_GPSR9=psnr(Img2D,Img2D_GPSR9,scale);
Nerror_GPSR9(jj)=(norm(Img2D(:)-Img2D_GPSR9(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb9)
    s_GPSRdb9=reshape(s_GPSRdb9, my, mx);
    s_GPSRdb9=wave_mat2vec(s_GPSRdb9, signature);
    Img2D_GPSRdb9=W(s_GPSRdb9);
    Img2D_GPSRdb9=Img2D_GPSRdb9+Img2Dbar;
    PSNR_GPSRdb9=psnr(Img2D,Img2D_GPSRdb9,scale);
    Nerror_GPSRdb9(jj)=(norm(Img2D(:)-Img2D_GPSRdb9(:)))^2/(norm(Img2D(:)))^2;
end


%%%%%%%%%%%% Setting sparsity for hard thresholding methods
slope1=2000;
r_init1=floor(slope1*Nratio);

slope2=2500;
r_init2=floor(slope2*Nratio);

%%%%%%%%%%%%%%%%%%%%% Solve by NIHT

tic;
[s_NIHT,Count_NIHT]=hard_l0_Mterm_mod(y,H,p,r_init1,thresh,'P_trans',Ht);
t_NIHT(jj)=toc;
s_NIHT=reshape(s_NIHT, my, mx);
s_NIHT=wave_mat2vec(s_NIHT, signature);
Img2D_NIHT=W(s_NIHT);
Img2D_NIHT=Img2D_NIHT+Img2Dbar;
PSNR_NIHT=psnr(Img2D,Img2D_NIHT,scale);
Nerror_NIHT(jj)=(norm(Img2D(:)-Img2D_NIHT(:)))^2/(norm(Img2D(:)))^2;


%%%%%%%%%%%%%%%%%%%%% Solve by MB-IHT

tic;
[s_IHT_tree,Count_IHT_tree]=IHT_tree(y,H,p,r_init2,thresh,numLevels,signature,projonimage,'P_trans',Ht,'step_size',1);
t_IHT_tree(jj)=toc;
s_IHT_tree=reshape(s_IHT_tree, my, mx);
s_IHT_tree=wave_mat2vec(s_IHT_tree, signature);
Img2D_IHT_tree=W(s_IHT_tree);
Img2D_IHT_tree=Img2D_IHT_tree+Img2Dbar;
PSNR_IHT_tree=psnr(Img2D,Img2D_IHT_tree,scale);
Nerror_IHT_tree(jj)=(norm(Img2D(:)-Img2D_IHT_tree(:)))^2/(norm(Img2D(:)))^2;

clear f
end

clear Phi Phit Phi0 H Ht W Wt cov

nmse_tAMP=mean(Nerror_tAMP);
nmse_mpem=mean(Nerror_mpem);
nmse_mpem_opt=mean(Nerror_mpem_opt);
nmse_GPSR1=mean(Nerror_GPSR1);
nmse_GPSR2=mean(Nerror_GPSR2);
nmse_GPSR3=mean(Nerror_GPSR3);
nmse_GPSR4=mean(Nerror_GPSR4);
nmse_GPSR5=mean(Nerror_GPSR5);
nmse_GPSR6=mean(Nerror_GPSR6);
nmse_GPSR7=mean(Nerror_GPSR7);
nmse_GPSR8=mean(Nerror_GPSR8);
nmse_GPSR9=mean(Nerror_GPSR9);
nmse_GPSRdb1=mean(Nerror_GPSRdb1);
nmse_GPSRdb2=mean(Nerror_GPSRdb2);
nmse_GPSRdb3=mean(Nerror_GPSRdb3);
nmse_GPSRdb4=mean(Nerror_GPSRdb4);
nmse_GPSRdb5=mean(Nerror_GPSRdb5);
nmse_GPSRdb6=mean(Nerror_GPSRdb6);
nmse_GPSRdb7=mean(Nerror_GPSRdb7);
nmse_GPSRdb8=mean(Nerror_GPSRdb8);
nmse_GPSRdb9=mean(Nerror_GPSRdb9);
nmse_fpc_as1=mean(Nerror_fpc_as1);
nmse_fpc_as2=mean(Nerror_fpc_as2);
nmse_fpc_as3=mean(Nerror_fpc_as3);
nmse_fpc_as4=mean(Nerror_fpc_as4);
nmse_fpc_as5=mean(Nerror_fpc_as5);
nmse_fpc_as6=mean(Nerror_fpc_as6);
nmse_fpc_as7=mean(Nerror_fpc_as7);
nmse_fpc_as8=mean(Nerror_fpc_as8);
nmse_fpc_as9=mean(Nerror_fpc_as9);
nmse_NIHT=mean(Nerror_NIHT);
nmse_IHT_tree=mean(Nerror_IHT_tree);
nmse_vb=mean(Nerror_vb);
nmse_vb2=mean(Nerror_vb2);

save([img_name,num2str(my),'by',num2str(mx),'_dwtLevel_',num2str(numLevels),'_Covariance_',num2str(covc),'_thresh_',num2str(thresh),'.mat']);
