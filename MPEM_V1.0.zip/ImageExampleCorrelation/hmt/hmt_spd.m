% This Matlab function implements the wrapper of Sparsity Pattern
% Decoding (SPD) for Turbo AMP reconstruction for Compressive Imaging
% using Markov random tree. 
% 
% turboAMP version 1.0 
% Copyright (c) Subhojit Som and Philip Schniter, 2011
% Email: som.4@osu.edu, schniter@ece.osu.edu
%
% Last modified: July 30, 2011

function [ Le_spdec, s_hat] = hmt_spd( La_spdec, s, f, p1_approx )

% La_spdec=wave_vec2mat(La_spdec,s);
% La_spdec=La_spdec(:);

a_spdec=1./(1+exp(-La_spdec));


f.setPot(a_spdec,'nodePot');
f.forwardBackward();
e_spdec=f.computePot('extrinsic');
marginalPot=f.computePot('marginal');

e_spdec=reshape(e_spdec,s(end,:)); 
e_spdec(1:s(1,1),1:s(1,2))=p1_approx; % approximation coefficients
e_spdec=e_spdec(:);
Le_spdec=log(e_spdec)-log(1-e_spdec);


marginalPot=reshape(marginalPot,s(end,:)); 
a_spdecM=reshape(a_spdec,s(end,:));
marginalPot(1:s(1,1),1:s(1,2))=a_spdecM(1:s(1,1),1:s(1,2));
marginalPot=marginalPot(:);

s_hat=(marginalPot>0.5);



end

