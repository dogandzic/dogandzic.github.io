% This Matlab function generates the quadree structure to be used
% for Turbo AMP reconstruction for Compressive Imaging
% using Markov random tree. 
% 
% turboAMP version 1.0 
% Copyright (c) Subhojit Som and Philip Schniter, 2011
% Email: som.4@osu.edu, schniter@ece.osu.edu
%
% Last modified: July 30, 2011
function [ f ] = getStructHMT( s )

    warning off MATLAB:javaclasspath:duplicateEntry;
    javaaddpath('./hmt/hmt_struct');
    f=javaObject('waveForest',round(s)); % the quadtree structure

end

