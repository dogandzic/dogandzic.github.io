
public class waveTree {
	

	private waveNode root;
	private int [] rootLocation = {0, 0};
	

	public waveTree(int[] s, int [] rootLocation) {
//		System.out.println("Root location: ["+rootLocation[0]+","+rootLocation[1]+"]");
		this.rootLocation[0]=rootLocation[0];
		this.rootLocation[1]=rootLocation[1];
		int level = 0;
		int [] matrixDim = {s[(s.length)/2-1], s[(s.length)-1]};
		root = new waveNode(rootLocation, level, matrixDim);
		root.createTree();
		
	}

	public void setPot(double[] c, String msgType) {
		// System.out.println("["+rootLocation[0]+", "+rootLocation[1]+"]");
		root.setPot(c, msgType);
	}

	public void readPot(double[] outPot, String msgType) {
		root.readPot(outPot, msgType);	
	}

	public void forwardBackward() {
		root.upwardPass();
		root.downwardPass();
	}

	public void computePot(double[] outPot, String potType) {
		root.computePot(outPot,potType);
	}

	public void returnLevel(int[] levelArray) {
		root.returnLevel(levelArray);
		
	}

	public void genSample(double[] sampleArray) {
		root.genSample(sampleArray);
		
	}

	public void readState(boolean[] stateArray) {
		root.readState(stateArray);	
	}

	public void setState(boolean[] stateArray) {
		root.setState(stateArray);
	}

	public void freqTransition(double[] freqArray, int parentLevel, boolean parentState) {
		root.freqTransition(freqArray, parentLevel, parentState);
	}

	public void freqActive(double[] freqArray, int level) {
		root.freqActive(freqArray, level);
	}
	

}
