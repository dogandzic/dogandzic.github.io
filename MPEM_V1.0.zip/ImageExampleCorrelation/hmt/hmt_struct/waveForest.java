import java.util.ArrayList;
import java.util.Iterator;


public class waveForest {

	private ArrayList<waveTree> treeList = new ArrayList<waveTree>();
	private int[] s;
	private int numLevels = -1;
	// This node is manipulated to update static variables
	private waveNode staticNode = new waveNode(); 

	public waveForest(int[] s) {
		
		int [] rootLocation = {0, 0};
		this.s = s;
		waveTree root = null;
		
		for(int i=0; i<s[1]; i++){
			for(int j=0;j<s[1+(s.length)/2]; j++){
                // Do h first
				rootLocation[0]=i;
				rootLocation[1]=s[(s.length)/2]+j;
				root = new waveTree(s, rootLocation);
				treeList.add(root);
				
                // Do v next
				rootLocation[0]=s[0]+i;
				rootLocation[1]=j;
				treeList.add(new waveTree(s, rootLocation));
				
                // Do d last
				rootLocation[0]=s[0]+i;
				rootLocation[1]=s[(s.length)/2]+j;
				treeList.add(new waveTree(s, rootLocation));
				
			} // for(int j=0;j<s[1+(s.length)/2]; j++)
		} // for(int i=0; i<s[1]; i++)
		
		this.numLevels = (s.length)/2-2;
		// staticNode.createTrans(this.numLevels);
		staticNode.setNumLevels(this.numLevels);
	} // waveForest(int[] s)
	
	public void setPot(double[] c, String msgType){
		if(msgType.equals("nodePot")){
			Iterator<waveTree> itr = treeList.iterator(); 
			while(itr.hasNext()) {
			    waveTree tree = itr.next(); 
			    tree.setPot(c, msgType);
			} 
		} else {
			System.out.println("Invalid msgType: "+msgType);
			return;
		}
	}

	public double[] readPot(String msgType) {
		double [] outPot = new double[s[(s.length)/2-1]*s[s.length-1]];
		Iterator<waveTree> itr = treeList.iterator(); 
		while(itr.hasNext()) {
		    waveTree tree = itr.next(); 
		    tree.readPot(outPot, msgType);
		}
		return outPot;
	}

	public void forwardBackward() {
		Iterator<waveTree> itr = treeList.iterator(); 
		while(itr.hasNext()) {
		    waveTree tree = itr.next(); 
		    tree.forwardBackward();
		}
		
	}


	public double[] computePot(String potType) {
		if(potType.equals("marginal") || potType.equals("extrinsic")){
			double [] outPot = new double[s[(s.length)/2-1]*s[s.length-1]];
			Iterator<waveTree> itr = treeList.iterator(); 
			while(itr.hasNext()) {
			    waveTree tree = itr.next(); 
			    tree.computePot(outPot,potType);
			}
			return outPot;
		} else {
			System.out.println("Invalid potential to compute: "+potType);
			return null;
		}
	}

	public int[] returnLevel() {
		int [] levelArray = new int[s[(s.length)/2-1]*s[s.length-1]];
  		for(int i=0;i<levelArray.length;i++){
  			levelArray[i]=-1;
  		}
		Iterator<waveTree> itr = treeList.iterator(); 
		while(itr.hasNext()) {
		    waveTree tree = itr.next(); 
		    tree.returnLevel(levelArray);
		}
		return levelArray;
		
	}

	public double[] genSample() {
		double [] sampleArray = new double[s[(s.length)/2-1]*s[s.length-1]];
		Iterator<waveTree> itr = treeList.iterator(); 
		while(itr.hasNext()) {
		    waveTree tree = itr.next(); 
		    tree.genSample(sampleArray);
		}
		return sampleArray;
		
	}

	public boolean[] readState() {
		boolean [] stateArray = new boolean[s[(s.length)/2-1]*s[s.length-1]];
		Iterator<waveTree> itr = treeList.iterator(); 
		while(itr.hasNext()) {
		    waveTree tree = itr.next(); 
		    tree.readState(stateArray);
		}
		return stateArray;
	}

	public void setState(boolean[] stateArray){
		Iterator<waveTree> itr = treeList.iterator(); 
		while(itr.hasNext()) {
		    waveTree tree = itr.next(); 
		    tree.setState(stateArray);
		} 
	}

	public double[] freqTransition(int parentLevel, boolean parentState){
		double [] freqArray = new double[2];
		Iterator<waveTree> itr = treeList.iterator(); 
		while(itr.hasNext()) {
		    waveTree tree = itr.next(); 
		    tree.freqTransition(freqArray, parentLevel, parentState);
		} 
		return freqArray;
	}
	
	public double[] freqActive(int level){
		double [] freqArray = new double[2];
		Iterator<waveTree> itr = treeList.iterator(); 
		while(itr.hasNext()) {
		    waveTree tree = itr.next(); 
		    tree.freqActive(freqArray, level);
		} 
		return freqArray;
	}
	

	 public void updateProbParams(boolean [] stateArray){
	 	this.setState(stateArray);
	 	double [] P00Array = new double[numLevels-1];
	 	double [] P11Array = new double[numLevels-1];
	 	double P1;
	 	double [] freq;
	 	double [] P1_beta1 = staticNode.getBetaParams("P1_beta1");
	 	double [] P1_beta0 = staticNode.getBetaParams("P1_beta0");
	 	double [] P11_beta1 = staticNode.getBetaParams("P11_beta1");
	 	double [] P11_beta0 = staticNode.getBetaParams("P11_beta0");
	 	double [] P00_beta1 = staticNode.getBetaParams("P00_beta1");
	 	double [] P00_beta0 = staticNode.getBetaParams("P00_beta0");
		int j;

	 	freq = this.freqActive(0);
	 	P1 = (freq[1] + P1_beta1[0])/(freq[0]+freq[1]+P1_beta0[0]+P1_beta1[0]);
	 	System.out.println("Level 0: P1="+P1);
	 	for(int i=0; i<numLevels-1; i++){
			j=i+1;
	 		freq = this.freqTransition(i, false);
	 		P00Array[i]=(freq[0]+P00_beta0[i])/(freq[0]+freq[1]+P00_beta0[i]+P00_beta1[i]);
	 		freq = this.freqTransition(i, true);
	 		P11Array[i]=(freq[1]+P11_beta1[i])/(freq[0]+freq[1]+P11_beta0[i]+P11_beta1[i]);
	 		System.out.println("Level:"+j+" P00="+P00Array[i]+", P11="+P11Array[i]);
	 	}
	 	staticNode.setTrans(P00Array, P11Array, P1);
	 }


	public void setBetaParams(double[] p1_beta1, double[] p1_beta0, double[] p11_beta1, double[] p11_beta0, double[] p00_beta1, double[] p00_beta0) {
		staticNode.setBetaParams(p1_beta1, p1_beta0, p11_beta1, p11_beta0, p00_beta1, p00_beta0);
	}
	

}
