import java.util.Random;


public class waveNode {
	

	private int [] location = {-1, -1};
	private int level = -1;
	private static int [] matrixDim = {-1, -1};
	private static int numLevels = -1;
	
	private waveNode parent = null; 
	private static int numChildren = 4;
	private waveNode[] children = null;
	private int childIndex = -1;
	
	private boolean stateActive = false; // false = inactive, true = active
	private double nodeVal = 0;
	
	// Use convention like C, rows are concatenated
	private double[] nodePot = {0.5, 0.5};  
	// Size 2x1
	private double[] msgToTop = {0.5, 0.5};
	// Size depends on number of branches in the tree;
	// hence initialized in the constructor
	private double[] msgToBottom; 
	
	
	private static double P1;
	private static double [] P00Array;
	private static double [] P11Array;

	private static double [] P1_beta1;  // Scalar, but made array for compatibility
	private static double [] P1_beta0;  // Scalar, but made array for compatibility
	private static double [] P11_beta1;
	private static double [] P11_beta0;
	private static double [] P00_beta1;
	private static double [] P00_beta0;
	// private static double P1_beta1 = 0.9;
	// private static double P1_beta0 = 0.1;
	// private static double P11_beta1 = 0.5;
	// private static double P11_beta0 = 0.5;
	// private static double P00_beta1 = 0.1;
	// private static double P00_beta0 = 0.9;
	
	

	public waveNode(){
		// Do nothing
	}

	public waveNode(int[] rootLocation, int level, int [] matrixDim2) {
		// Constructor for root node
		this.location[0] =rootLocation[0];
		this.location[1] =rootLocation[1];
		this.level=level;
		matrixDim[0]=matrixDim2[0];
		matrixDim[1]=matrixDim2[1];
		
		msgToBottom = new double[2*numChildren];
		for(int i=0; i<msgToBottom.length; i++){
			msgToBottom[i]=0.5;
		}
		// System.out.println(location[0]+location[1]*matrixDim[0]);
	}
	
	
		
	public waveNode(waveNode parent, int[] location, int level, int childIndex) {
		// Constructor for non-root nodes 
		this.location[0]=location[0];
		this.location[1]=location[1];
		this.level=level;
		this.parent=parent;
		this.childIndex=childIndex;
		
		msgToBottom = new double[2*numChildren];
		for(int i=0; i<msgToBottom.length; i++){
			msgToBottom[i]=0.5;
		}
		// System.out.println(location[0]+location[1]*matrixDim[0]);

	}
	
	public void createTree() {
		if(location[0]*2 >= matrixDim[0] || location[1]*2 >= matrixDim[1]){
			return;
		}
		int i;
		int [] childLocation = new int[2];
		
		children = new waveNode[numChildren];
		for(i=0;i<numChildren;i++){
			switch(i) {
			case 0 : childLocation[0]=location[0]*2; 
			         childLocation[1]=location[1]*2; 
			         break;
			case 1 : childLocation[0]=location[0]*2+1; 
			         childLocation[1]=location[1]*2; 
			         break;
			case 2 : childLocation[0]=location[0]*2; 
			         childLocation[1]=location[1]*2+1;
			         break; 
			case 3 : childLocation[0]=location[0]*2+1; 
			         childLocation[1]=location[1]*2+1; 
			         break; 
			}
			children[i] = new waveNode(this, childLocation, level+1, i);
			children[i].createTree();
		}
	}

	public void setPot(double[] c, String msgType) {
		//System.out.println(location[0]+location[1]*matrixDim[0]);
		if(msgType.equals("nodePot")){
			nodePot[1]=c[location[0]+location[1]*matrixDim[0]];
			nodePot[0]=1-nodePot[1];
		} 
		if(children!=null){
			for(int i=0; i<numChildren; i++){
				children[i].setPot(c, msgType);
			}
		}
		
	}

	public void readPot(double[] outPot, String msgType) {
		if(msgType.equals("nodePot")){
			outPot[location[0]+location[1]*matrixDim[0]]=nodePot[1];
		} 
		if(children!=null){
			for(int i=0; i<numChildren; i++){
				children[i].readPot(outPot, msgType);
			}
		}	
	}

	public void upwardPass() {
		if(children!=null){
			for(int i = 0; i < numChildren; i++){
				children[i].upwardPass();
			}
		}
		if(level==0){
			return;
		}
		
		double prod0;//=0.5;
		double prod1;//=0.5;
		// double p00=P00;
		// double p11=P11;
		double p00=P00Array[level-1];
		double p11=P11Array[level-1];
		double p01=1-p00;
		double p10=1-p11;		

		double [] inMsg; 
		
		prod0=nodePot[0];
		prod1=nodePot[1];
		
		if(this.children!=null){	
			for(int i = 0; i < numChildren; i++){
				inMsg = children[i].readPot("msgToTop");
				prod0=prod0*inMsg[0];
				prod1=prod1*inMsg[1];
			}
		}
		msgToTop[0]=prod0*p00 + prod1*p01;
		msgToTop[1]=prod0*p10 + prod1*p11;
		
		// Normalize the message
		double sum = msgToTop[0] + msgToTop[1];
		msgToTop[0]=msgToTop[0]/sum;
		msgToTop[1]=msgToTop[1]/sum;
				
	}

	public void downwardPass() {
		if(children==null){
			return;
		}
		double [] inMsg; 
		double prod0t;//=0.5;
		double prod1t;//=0.5;
		double prod0, prod1;
		// double p00=P00;
		// double p11=P11;
		double p00=P00Array[level];
		double p11=P11Array[level];
		double p01=1-p00;
		double p10=1-p11;
		
		
		if(this.level==0){
			prod0t=(1-P1)*nodePot[0];
			prod1t=P1*nodePot[1];
		} else{
			inMsg = this.parent.readPot("msgToBottom");
			prod0t=inMsg[this.childIndex]*nodePot[0];
			prod1t=inMsg[this.childIndex+numChildren]*nodePot[1];
		}
		

		
		for(int i=0; i<numChildren; i++){
			prod0=prod0t;
			prod1=prod1t;
			for(int j = 0; j < numChildren; j++){
				if(j!=i){
					inMsg = children[j].readPot("msgToTop");
					prod0=prod0*inMsg[0];
					prod1=prod1*inMsg[1];
				}
			}
			msgToBottom[i]=prod0*p00+prod1*p10;
			msgToBottom[i+numChildren]=prod0*p01+prod1*p11;

			// Normalize the message
			double sum = msgToBottom[i] + msgToBottom[i+numChildren];
			msgToBottom[i]=msgToBottom[i]/sum;
			msgToBottom[i+numChildren]=msgToBottom[i+numChildren]/sum;
		}
		
		// Repeat for children
		for(int i = 0; i < numChildren; i++){
			children[i].downwardPass();
		}
	}
	
	
	public double[] readPot(String msgType) { 
		// Should modify to implement exception
		if(msgType.equals("msgToTop")){
			return this.msgToTop;
		}else if(msgType.equals("msgToBottom")) {
			return this.msgToBottom;
		}else if(msgType.equals("nodePot")){
			return this.nodePot;
		}else {
			System.out.println("Invalid readpot() call.");
			return null;
		}
	}

	public void computePot(double[] outPot, String potType) {
		double prod0;
		double prod1;
		double [] inMsg;
		if(level!=0){
			inMsg=this.parent.readPot("msgToBottom");
			prod0=inMsg[childIndex];
			prod1=inMsg[childIndex+numChildren];
		}else{
			prod0=(1-P1);
			prod1=P1;
		}
		if(this.children!=null){
			for(int i=0; i<numChildren; i++){
				inMsg=this.children[i].readPot("msgToTop");
				prod0=prod0*inMsg[0];
				prod1=prod1*inMsg[1];
			}
		}
		if(potType.equals("marginal")){
			prod0=prod0*nodePot[0];
			prod1=prod1*nodePot[1];
		}
		outPot[location[0]+location[1]*matrixDim[0]]=prod1/(prod0+prod1);
		if(this.children!=null){
			for(int i=0; i<numChildren; i++){
				children[i].computePot(outPot,potType);
			}
		}		
		
	}

	public void returnLevel(int[] levelArray) {
		levelArray[location[0]+location[1]*matrixDim[0]]=level;
		if(children!=null){
			for(int i=0; i<numChildren; i++){
				children[i].returnLevel(levelArray);
			}
		}
		
	}

	public void genSample(double[] sampleArray) {
		Random generator = new Random();
		double randomNum = generator.nextDouble();

		// double p00=P00;
		// double p11=P11;
		double p00=P00Array[level];
		double p11=P11Array[level];
		double p01=1-p00;
		double p10=1-p11;

		// System.out.println("Level:"+level+",p00="+p00+",p11="+p11+",P1="+P1);

		if(level==0){
			stateActive = (randomNum < P1);
		} else{
			if(parent.readState()){
				stateActive = (randomNum < p11);
			} else {
				stateActive = (randomNum < (p01));
			}
		}
		
		if(stateActive){
			nodeVal = generator.nextGaussian();
		}
		sampleArray[location[0]+location[1]*matrixDim[0]]=nodeVal;
		
		if(children!=null){
			for(int i=0; i<numChildren; i++){
				children[i].genSample(sampleArray);
			}
		}
	}

	private boolean readState() {
		return stateActive;
	}


	public void readState(boolean[] stateArray) {
		stateArray[location[0]+location[1]*matrixDim[0]]=stateActive;
		if(children!=null){
			for(int i=0; i<numChildren; i++){
				children[i].readState(stateArray);
			}
		}	
	}

	public void setState(boolean[] stateArray) {
		stateActive=stateArray[location[0]+location[1]*matrixDim[0]];
		if(children!=null){
			for(int i=0; i<numChildren; i++){
				children[i].setState(stateArray);
			}
		}
		
	}

	public void freqTransition(double[] freqArray, int parentLevel, boolean parentState) {

		if(level==parentLevel+1){
			if(parentState==parent.readState()){
				if(stateActive){
					freqArray[1]=freqArray[1]+1;
				}else{
					freqArray[0]=freqArray[0]+1;
				}
			}
			return;
		}
		if((children!=null) && parentLevel >=level){
			for(int i=0; i<numChildren; i++){
				children[i].freqTransition(freqArray, parentLevel, parentState);
			}
		}
		
	}


	public void setNumLevels(int numLevelsIn) {
		numLevels = numLevelsIn;
	}

	public void createTrans(int numLevelsIn) {
		numLevels = numLevelsIn;
		P00Array = new double[numLevels-1];
		P11Array = new double[numLevels-1];	
		for(int i=0; i<numLevels-1; i++){
			P00Array[i]=P00_beta0[i]/(P00_beta1[i]+P00_beta0[i]);
			P11Array[i]=P11_beta1[i]/(P11_beta1[i]+P11_beta0[i]);
		}
		P1 = P1_beta1[0]/(P1_beta1[0]+P1_beta0[0]);
	}
	
	
	public void setTrans(double[] P00Array2, double[] P11Array2, double P12) {
		P00Array = P00Array2;
		P11Array = P11Array2;
		P1 = P12;
	}
	
	public void freqActive(double[] freqArray, int level2) {
		if(level==level2){
			if(stateActive){
				freqArray[1]=freqArray[1]+1;
			}else{
				freqArray[0]=freqArray[0]+1;
			}
			return;
		}
		if(children!=null){
			for(int i=0; i<numChildren; i++){
				children[i].freqActive(freqArray, level2);
			}
		}
		
	}
	
	
	public void setBetaParams(double[] p1_beta1, double[] p1_beta0, double[] p11_beta1, double[] p11_beta0, double[] p00_beta1, double[] p00_beta0) {
		P1_beta1 =  p1_beta1;
		P1_beta0 =  p1_beta0;
		P11_beta1 = p11_beta1;
		P11_beta0 = p11_beta0;
		P00_beta1 = p00_beta1;
		P00_beta0 = p00_beta0;
		this.createTrans(this.numLevels);
	}

	public double [] getBetaParams(String paramType) {
		if(paramType.equals("P1_beta1")){
		    return P1_beta1;
		}
		if(paramType.equals("P1_beta0")){
		    return P1_beta0;
		}
		if(paramType.equals("P11_beta1")){
		    return P11_beta1;
		}
		if(paramType.equals("P11_beta0")){
		    return P11_beta0;
		}
		if(paramType.equals("P00_beta1")){
		    return P00_beta1;
		}
		if(paramType.equals("P00_beta0")){
		    return P00_beta0;
		}
		return null;
	}
	


}	 
