% This Matlab function sets the hyperparameters and some derived variables 
% for the Turbo AMP reconstruction for Compressive Imaging. 
% 
% turboAMP version 1.1 
% Copyright (c) Subhojit Som and Philip Schniter, 2011
% Email: som.4@osu.edu, schniter@ece.osu.edu
%
% Last modified: February 10, 2013

function [ modelParams, f ] = initializeModelParams( params, modelParams )

    dim=params.s(end,:);
    N=prod(dim);
    
%     if ~isfield(params,'Le_max')
%         params.Le_max=20;
%     end


    if params.highSNR
        sig2w =1e-6; 
    else
        sig2w =1e-2; 
    end
    if exist('modelParams','var')
        if ~isfield(modelParams,'Gamma')
            modelParams.Gamma=[1 sig2w];
        end
    else 
        modelParams.Gamma=[1 sig2w];
    end
    modelParams.sig2w = modelParams.Gamma(2)/modelParams.Gamma(1);


    f=getStructHMT(params.s(:));
    level=double(reshape(f.returnLevel(),dim));
    Nl=zeros(max(level(:))+1,1);
    for l=1:numel(Nl)
        Nl(l)=sum(level(:)==l-1);
    end
    
    if exist('modelParams','var')
        if ~isfield(modelParams,'Gamma_j')
            modelParams.Gamma_j=ones(params.numLevels+1,2);
            modelParams.Gamma_j(1,2)=10;
            modelParams.Gamma_j(2:3,2)=1;
            modelParams.Gamma_j(4:end,2)=0.1;
        end
    end

    
    if(params.gmm)
        if exist('modelParams','var')
            if ~isfield(modelParams,'GammaSmall_j')
                modelParams.GammaSmall_j=modelParams.Gamma_j;
                modelParams.GammaSmall_j(:,2)=1e-6*modelParams.GammaSmall_j(:,2);
            end
        end
    end
    
    if(params.projOnImage)
        modelParams.sig2x=conv_viz2mat(estimate_sigma(f,zeros(N,1),zeros(N,1),modelParams.Gamma_j),params.s);
        if(params.gmm)
            modelParams.sig2x_small=conv_viz2mat(estimate_sigma(f,zeros(N,1),zeros(N,1),modelParams.GammaSmall_j),params.s);
        end
    else
        modelParams.sig2x=estimate_sigma(f,zeros(N,1),zeros(N,1),modelParams.Gamma_j);
        if(params.gmm)
            modelParams.sig2x_small=estimate_sigma(f,zeros(N,1),zeros(N,1),modelParams.GammaSmall_j);
        end
    end
    

    if exist('modelParams','var')
        if ~isfield(modelParams,'Beta_0')
            modelParams.Beta_0_1=[(1-1/N)*Nl(1) 1/N*Nl(1)];
%             modelParams.Beta_0_1=[0.9*Nl(1) 0.1*Nl(1)];
        end
        if ~isfield(modelParams,'Beta_j_11')
            modelParams.Beta_j_11=[0.5*Nl(2:end) 0.5*Nl(2:end)];
        end
        if ~isfield(modelParams,'Beta_j_00')
            modelParams.Beta_j_00=[1/N*Nl(2:end), (1-1/N)*Nl(2:end)];
%             modelParams.Beta_j_00=[0.1*Nl(2:end), 0.9*Nl(2:end)];
        end
    end
    f.setBetaParams(modelParams.Beta_0_1(1), modelParams.Beta_0_1(2), modelParams.Beta_j_11(:,1), ...
        modelParams.Beta_j_11(:,2), modelParams.Beta_j_00(:,1), modelParams.Beta_j_00(:,2));
  
    if exist('modelParams','var')
        if ~isfield(modelParams,'Beta_approx')
            p1_approx=1-1e-6;
            p1_WT=sum(level(:)==-1);
            modelParams.p1_approx=p1_approx;
            modelParams.Beta_approx=p1_WT*[p1_approx (1-p1_approx)];
        else
            modelParams.p1_approx=modelParams.Beta_approx(1)/sum(modelParams.Beta_approx);
        end
    end
    
    
    
    if exist('modelParams','var')
        if ~isfield(modelParams,'Le_spdec')
            Le_spdec=zeros(dim);

            TransA=[0.9 0.1; 0.5 0.5];
            p0=modelParams.Beta_0_1';
            for l=-1:max(level(:))
                if(l==-1)
                    Le_spdec(find(level==l))=log(p1_approx/(1-p1_approx));
                else
                    Le_spdec(find(level==l))=log(p0(2)/p0(1));
                    p0=TransA*p0;
                end
            end

            Le_spdec=Le_spdec(:);	
            modelParams.Le_spdec = max(-params.Le_max,min(params.Le_max,Le_spdec));
        end
    end


    
end

