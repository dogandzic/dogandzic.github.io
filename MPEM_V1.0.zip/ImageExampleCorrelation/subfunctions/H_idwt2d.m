% Written by Zhao Song, ISU, Dec., 2011

function b=H_idwt2d(A,alpha,s)

% alpha: sparse vector which is taken from Wavelet transform of image x
% A: random projection matrix N x p
% s: bookkeeeping matrix
% Return b: vector N x 1

% convert wavelet coefficients (sparse representation) into samples
im=waverec2(alpha',s,'db1');

% convert samples into measurements
x = im(:);    
if ~isa(A, 'function_handle')
    b = A*x;
else
    b = A(x);
end
    
   