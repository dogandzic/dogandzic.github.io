% Written by Zhao Song, ISU, Dec., 2011

function alpha = Ht_dwt2d(At,b,L,m,n)

% b: measurement vector N x 1
% At: random projection matrix p x N
% L: level of decomposition
% m, n: size of image
% Return alpha: vector p x 1

% convert measurements into samples
if ~isa(At, 'function_handle')
    x=At*b;
else
    x=At(b);
end
% convert samples into wavelet coefficients (sparse representation)
im=reshape(x,m,n);
u=wavedec2(im,L,'db1');
alpha=u';


