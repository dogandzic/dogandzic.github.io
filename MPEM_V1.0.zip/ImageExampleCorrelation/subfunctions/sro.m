function y = sro(operation_mode, x, I, M, N, m, n, trans_mode, Phi_r, Phi_c, sample_lattice, pre_proc);
% SRO: Structurally Random Operator

% I: currently active set (for greedy pursuit only, otherwise it is assigned = [1:N])
% [m n]:  size of the 2d signal. N = n*m
% operation_mode = 1: forward transform
% operation_mode = 2: transposed transform
% if trans_mode = '2DDCT', Phi_r = Phi_c = []
% if sample_lattice = [], uniformly random downsampling
% otherwise, e.g. sample_lattice = Meyer_lattice, ....

Pstate = 4972169;
Qstate = 7256157;

if isempty(sample_lattice) % uniformly random sampling
    rand('state', Qstate);
    q = randperm(N);
    sample_lattice =q(1:M);
end

if (operation_mode == 1)

    u = zeros(N, 1);
    u(I) = x;
    
    % pre-processing
    if strcmp(pre_proc, 'RP')
        rand('state', Pstate);
        p = randperm(N); 
        v = u(p);
    
    elseif strcmp(pre_proc, 'RS')
        rand('state', Pstate);
        p = 2*round(rand(N,1))-1;
        v = u.*p;
        v = v(:);
    else
        v = u(:);
    end
    
    % forward transform
    if strcmp(trans_mode, '2DDCT')
        v = reshape(v, [m n]);
        v = dct2(v);
    else
        v = reshape(v, [m n]);
        v = Phi_r*v*Phi_c;      
    end
    
    % downsampling
    y = zeros(M,1);
    v = v(:);
    y = v(sample_lattice);
    
    
% operation_mode = 2: adjoint operator (At) 
elseif (operation_mode == 2)
    
    % upsampling
    u = zeros(N,1);
    u(sample_lattice) = x;

    % transposed transform
    if strcmp(trans_mode, '2DDCT')
        u= reshape(u,[m n]);
        u = idct2(u);
        u = u(:);
    else
        u= reshape(u,[m n]);
        u = Phi_r'*u*Phi_c';
        u = u(:);
    end

    % post-processing
    if strcmp(pre_proc, 'RP')
        rand('state', Pstate);
        p = randperm(N); 
        v = zeros(N,1);
        v(p) = u;
        
    elseif strcmp(pre_proc, 'RS')
        rand('state', Pstate);
        p = 2*round(rand(N,1))-1;
        v = u.*p;
        v = v(:);
    else
        v = u(:);
    end
    
    y = v(I);
end