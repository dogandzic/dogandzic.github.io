function qpairs=numpair(q,L)
% compute the number of paris for q given its parent in a tree structure
% used in computing the posteriors

%===============================INPUT===========================================
% q: state variables with the tree structure
% L: wavelet decomposition levels
%===============================================================================

%==============================OUTPUT===========================================
% qparis: a 6x1 vector with each element having the following meaning
% qparis[1]: number of "1"s in root level
% qparis[2]: number of "0"s in root level
% qparis[3]: number of pairs for a state variable is "1" given its parent is "1"
% qparis[4]: number of pairs for a state variable is "1" given its parent is "0"
% qparis[5]: number of pairs for a state variable is "0" given its parent is "1"
% qparis[6]: number of pairs for a state variable is "0" given its parent is "0"
%===============================================================================

%-------------------------------------------------------------------------------
% Coded by Zhao Song, ECpE, Iowa State University
% Last modified on Oct. 11, 2012
%-------------------------------------------------------------------------------

qpairs=zeros(6,1);

rows=sqrt(length(q(:)));
scale_length=rows/(2^L);


qpairs(1)=qpairs(1)+sum(sum(q(1:scale_length,scale_length+1:scale_length*2)==1));
qpairs(1)=qpairs(1)+sum(sum(q(scale_length+1:scale_length*2,1:scale_length)==1));
qpairs(1)=qpairs(1)+sum(sum(q(1+scale_length:scale_length*2,scale_length+1:scale_length*2)==1));


qpairs(2)=qpairs(2)+sum(sum(q(1:scale_length,scale_length+1:scale_length*2)==0));
qpairs(2)=qpairs(2)+sum(sum(q(scale_length+1:scale_length*2,1:scale_length)==0));
qpairs(2)=qpairs(2)+sum(sum(q(1+scale_length:scale_length*2,scale_length+1:scale_length*2)==0));


for k=1:L-1
    for i=1:rows/2^(L-k)
        for j=rows/2^(L-k)+1:rows/2^(L-k-1)
            
            if q(i,j)==1 && q(ceil(i/2),ceil(j/2))==1
                qpairs(3)=qpairs(3)+1;
            end
            if q(i,j)==1 && q(ceil(i/2),ceil(j/2))==0
                qpairs(4)=qpairs(4)+1;
            end
            if q(i,j)==0 && q(ceil(i/2),ceil(j/2))==1
                qpairs(5)=qpairs(5)+1;
            end
            if q(i,j)==0 && q(ceil(i/2),ceil(j/2))==0
                qpairs(6)=qpairs(6)+1;
            end                       
            
            if q(j,i)==1 && q(ceil(j/2),ceil(i/2))==1
                qpairs(3)=qpairs(3)+1;
            end
            if q(j,i)==1 && q(ceil(j/2),ceil(i/2))==0
                qpairs(4)=qpairs(4)+1;
            end
            if q(j,i)==0 && q(ceil(j/2),ceil(i/2))==1
                qpairs(5)=qpairs(5)+1;
            end
            if q(j,i)==0 && q(ceil(j/2),ceil(i/2))==0
                qpairs(6)=qpairs(6)+1;
            end            
            
            if q(i+rows/2^(L-k),j)==1 && q(ceil((i+rows/2^(L-k))/2),ceil(j/2))==1
                qpairs(3)=qpairs(3)+1;
            end
            if q(i+rows/2^(L-k),j)==1 && q(ceil((i+rows/2^(L-k))/2),ceil(j/2))==0
                qpairs(4)=qpairs(4)+1;
            end
            if q(i+rows/2^(L-k),j)==0 && q(ceil((i+rows/2^(L-k))/2),ceil(j/2))==1
                qpairs(5)=qpairs(5)+1;
            end
            if q(i+rows/2^(L-k),j)==0 && q(ceil((i+rows/2^(L-k))/2),ceil(j/2))==0
                qpairs(6)=qpairs(6)+1;
            end            
            
        end
    end
end

end

