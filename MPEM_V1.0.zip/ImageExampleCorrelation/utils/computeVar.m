function [ var ] = computeVar( s )



f=javaObject('waveForest',round(s(:)));
level=f.returnLevel();
level=double(level);
var=ones(size(level));

load sigma2Array;


for i=1:numel(sigma2Array)
    l=i-1;
    index=find(level==l);
    var(index)=sigma2Array(i);
    
end   
index=find(level==-1);
var(index)=sigma2Scaling;
end

