function [ W ] = wave_vec2mat( c, s )

W=NaN*ones(s(end,:));
numLevels=size(s,1)-2;

startIndex=1;
W(1:s(1,1),1:s(1,2))=reshape(c(startIndex:startIndex+prod(s(1,:))-1),s(1,:));
startIndex=startIndex+prod(s(1,:));

for l=1:numLevels
    h=c(startIndex:startIndex+prod(s(l+1,:))-1);
    h=reshape(h,s(l+1,:));
    W(1:s(l+1,1),(1:s(l+1,2))+sum(s(1:l,2)))=h;
    startIndex=startIndex+prod(s(l+1,:));
    
    h=c(startIndex:startIndex+prod(s(l+1,:))-1);
    h=reshape(h,s(l+1,:));
    W((1:s(l+1,1))+sum(s(1:l,1)),1:s(l+1,2))=h;
    startIndex=startIndex+prod(s(l+1,:));
    
    h=c(startIndex:startIndex+prod(s(l+1,:))-1);
    h=reshape(h,s(l+1,:));
    W((1:s(l+1,1))+sum(s(1:l,1)),(1:s(l+1,2))+sum(s(1:l,2)))=h;
    startIndex=startIndex+prod(s(l+1,:));
end

end

