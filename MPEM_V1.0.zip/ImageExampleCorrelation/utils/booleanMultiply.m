function [ y ] = booleanMultiply( A, x )

% A is boolean, x is double
% y is double

%%%%%%%%% IMPORTANT --- the 1/sqrt(M) multiplication should be done outside

[M, N] =size(A);

y=zeros(M,1);

for n=1:N
    y=y+(double(A(:,n))-0.5)*x(n);
end
y=2*y;


end

