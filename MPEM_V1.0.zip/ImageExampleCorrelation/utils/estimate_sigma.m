function [ sig2x ] = estimate_sigma( f, x_hat, s_hat, Gamma_param )

level=f.returnLevel();
level=double(level);

% Gamma_param: n x 2 matrix
% first column a, second column b
% first row level -1
% second row level 0

sig2x=zeros(size(level));

for i=1:(max(level)+2)
    l=i-2;
    index_active=find((level==l) & (s_hat==1));
    index_level=find(level==l);

    x=x_hat(index_active);
    a=Gamma_param(i,1)+numel(index_active)/2;
    b=Gamma_param(i,2)+0.5*(sum(x.^2));
%     display(['Level:' num2str(l) ', sig2x=' num2str(b/a)])
    
%     if(l==-1)
        sig2x(index_level)=b/a;
%     else
%         sig2x(index_level)=b/a;
%     end
end   

end

