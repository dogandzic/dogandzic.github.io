clear all; close all; clc;

javaaddpath('../HMT_JAVA');

load lena128;
X=lena;
% load cameraman128;
% X=cameraman;
% X = phantom('Modified Shepp-Logan',128);

dim=size(X);
N=prod(dim);
numLevel=4;

[waveC, signature]=wavedec2(X,numLevel,'db1');
W=wave_vec2mat(waveC,signature);
WT=W;
% WT(1:signature(1,1),1:signature(1,2))=0;
x_true=WT(:);
% delta=0.5;  
% M = round(delta*N); % measurement length
% Csigma=2^11;%2^11;
% alphaL=2.25;%2.25



%%%%%%%%%%%%%%%%%%%%%%%%%%% Compute sigma for every level %%%%%%%%%%%%%%%%
f=javaObject('waveForest',round(signature(:)));
level=f.returnLevel();
level=double(level);

sigma2Array=zeros(4,1);
threshold=[0.7; 0.2; 0.07; 0.05; 0.02];


for i=1:numel(sigma2Array)
    l=i-1;
    index=find(level==l);
    x_temp=x_true(index);
    activeIndex=find(abs(x_temp)>threshold(i));
    numel(activeIndex)/numel(index)
    sigma2Array(i)=var(x_temp(activeIndex));
%     stem(x_temp);
%     title(['level=' num2str(l)])
end


index=find(level==-1);
x_temp=x_true(index);
activeIndex=find(abs(x_temp)>threshold(i));
numel(activeIndex)/numel(index)
sigma2Scaling=mean((x_temp(activeIndex)).^2)

% save sigma2Array.mat sigma2Array sigma2Scaling;
sigma2Array
    

%%%%%%%%%%%%%%%%%%%%%%%%%% Compute P0L %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x_temp=waveC(prod(signature(1,:))+(1:3*prod(signature(2,:))));
activeIndex=find(abs(x_temp)>threshold(i));
P0L=numel(activeIndex)/numel(x_temp)


state=zeros(N,1);
for i=1:numel(sigma2Array)
    l=i-1;
    state=state+(abs(x_true)>threshold(i)).*(level==l);
end
state=(state>0.5);
f.setState(state);

% structure of pTrans 
% first row parent level 0, [p00 p11]
pTrans=zeros(numLevel-1,2);
for i=1:size(pTrans,1)
    freq=f.freqTransition(i-1,0);
    pTrans(i,1)=freq(1)/sum(freq);
    freq=f.freqTransition(i-1,1);
    pTrans(i,2)=freq(2)/sum(freq);
end

pTrans
    