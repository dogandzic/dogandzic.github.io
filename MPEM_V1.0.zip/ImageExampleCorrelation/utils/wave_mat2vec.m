function [ c ] = wave_mat2vec( W, s )

c=NaN*ones(prod(s(end,:)),1);
numLevels=size(s,1)-2;

startIndex=1;
t=W(1:s(1,1),1:s(1,2));
c(startIndex:startIndex+prod(s(1,:))-1)=t(:);
startIndex=startIndex+prod(s(1,:));

for l=1:numLevels
    t=W(1:s(l+1,1),(1:s(l+1,2))+sum(s(1:l,2)));
    c(startIndex:startIndex+prod(s(l+1,:))-1)=t(:);
    startIndex=startIndex+prod(s(l+1,:));
    
    t=W((1:s(l+1,1))+sum(s(1:l,2)),(1:s(l+1,2)));
    c(startIndex:startIndex+prod(s(l+1,:))-1)=t(:);
    startIndex=startIndex+prod(s(l+1,:));
    
    t=W((1:s(l+1,1))+sum(s(1:l,1)),(1:s(l+1,2))+sum(s(1:l,2)));
    c(startIndex:startIndex+prod(s(l+1,:))-1)=t(:);
    startIndex=startIndex+prod(s(l+1,:));
end


end

