function [ A, X, M ] = getA( X, img, M, A_type)

    A=zeros(1,1);
    
    N=numel(X);

    tryGenA=true;
    k=1;
    while (tryGenA)
        try % see if the computer can support this problem size
            if A_type==1, % iid Gaussian
                A = (randn(M,N))/sqrt(M);     
            elseif A_type==2, % Rademacher
                A = sign(randn(M,N))/sqrt(M);
            end
        catch err % if not, then reduce the problem size
        if (strcmp(err.identifier,'MATLAB:nomem'))
            M=round(M/2);
            X=img{k}; 
            N=numel(X); 
            k=k+1;
            display('Reduced problem size since measurement matrix could not fit into memory!')
                continue;
        end
        end
        tryGenA=false;
    end


end

