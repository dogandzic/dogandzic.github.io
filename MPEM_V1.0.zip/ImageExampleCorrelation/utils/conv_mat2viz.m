function [ out ] = conv_mat2viz( in, s )
%CONV_MAT2VIZ Summary of this function goes here
%   Detailed explanation goes here

out=reshape(wave_vec2mat(in, s),prod(s(end,:)),1);

end

