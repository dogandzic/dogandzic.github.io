function [ out ] = conv_viz2mat( in, s )
%CONV_VIZ2MAT Summary of this function goes here
%   Detailed explanation goes here

out=wave_mat2vec(reshape(in,s(end,:)),s);

end

