function lbfgsb_callback (t, f, x)
    fprintf('it=%d f=%4.2e; ', t, f);
end