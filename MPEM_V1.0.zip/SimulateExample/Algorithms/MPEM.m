function [s_hat_out,q_hat_out,logP,object_prob,count,sigma2_out,sparsity,error]=MPEM(y,H,Ht,L,paras)

% MPEM: Max-Product EM algorithm for Structured Sparse Signal Reconstruction
% -------------------------------------------------------------------------
% Coded by Zhao Song, ECpE, Iowa State University
% Last updated on Aug. 4th, 2013
% -------------------------------------------------------------------------

%===============================INPUT======================================
% y:     the Nx1 measurement vector
% H:     the Nxp sensing matrix or sensing operator that computes H*x
% Ht:    the transpose of matrix H or the sensing operator that computes H'*x
% L:     wavelet decomposition levels
% paras: the structure that contains the parameters for the algorithm
%==========================================================================

%==============================OUTPUT======================================
% s_hat_out:   the px1 signal coefficient vector
% q_hat_out:   the px1 state varaible vector
% logP:        the Kx1 vector for the logarithm of marginal posterior 
% object_prob: the Kx1 vector for the logarithm of converged objective posterior
% count:       the number of total iterations
% sigma2_out:  the Kx1 vector for \sigma^2 
% sparsity:    the Kx1 vector for the number of significant state variables
% error:       the Kx1 vector for the reconstruction error(if applied)
%==========================================================================


if ~isa(H, 'function_handle')
    Ht=@(x) H'*x;
    H=@(x) H*x;
end

% -------------------
% Data Specifications
% -------------------
N=length(y);     % number of measurements
p=length(Ht(y)); % number of signal coefficients
mx=sqrt(p);      % number of rows 
my=sqrt(p);      % number of columns


% ---------------
% Initializations
% ---------------
s_hat_pre=zeros(p,1);  % signal coefficients estimate in previous iteration
s_hat=zeros(my,mx);    % signal coefficients estimate in current iteration
q_hat=zeros(my,mx);    % state variables estimate in current iteration
exit_flag1=0;
count=0;
p1=0;                  
p3=0;                  
sigma2=y'*y/(1*(N+p)); % initial value for sigma^2 in the grid search
max_iter_inner=5000;   % maximum value for inner loop iterations


% ------------------------
% Read the input arguments
% ------------------------
Ph=paras.Ph;
Pl=paras.Pl;
Proot=paras.Proot;
gamma2=paras.gamma2;
gamma=sqrt(gamma2);
epsilon2=paras.epsilon2;
epsilon=sqrt(epsilon2);
d=paras.d;
signature=paras.signature;
threshold=paras.threshold;        
max_iter_sigma2=paras.gridlength;    

if isfield(paras,'strue')
    s_true=paras.strue;
    error=zeros(max_iter_sigma2,1);
else
    error=[];
end

if isfield(paras,'sinit')
    s_hat_pre=paras.sinit;
end


% -----------------
% Define the output
% -----------------
s_hat_out=zeros(p,1);
q_hat_out=zeros(p,1);
sigma2_out=zeros(max_iter_sigma2,1);
sigma2_out(1)=sigma2;
sparsity=zeros(max_iter_sigma2,1);
logP=zeros(max_iter_sigma2,1);         % log of marginal posterior
object_prob=zeros(max_iter_sigma2,1);  % log of converged value for objective posterior

while (~exit_flag1)
    p1=p1+1;
    p3=p3+1;
    p2=0;
    exit_flag2=0;
    
    epsilon_tilde=epsilon*sqrt(sigma2);
    gamma_tilde=gamma*sqrt(sigma2);
        
    while (~exit_flag2)
        p2=p2+1;
        z=s_hat_pre+Ht((y-H(s_hat_pre)));
        if (paras.projonimage)
            z=wave_vec2mat(z,signature);
        else
            z=reshape(z,my,mx);
        end
        s_hat=epsilon2/(1+epsilon2)*z;
        q_hat=zeros(my,mx); 
    
        msgupL0=zeros(my,mx);        % upward messages corresponding to q_i = 0
        msgupL1=zeros(my,mx);        % upward messages corresponding to q_i = 1
        msgdownL0=zeros(my,mx);      % downward messages corresponding to q_i = 0
        msgdownL1=zeros(my,mx);      % downward messages corresponding to q_i = 1

        beliefL0=zeros(my,mx);
        beliefL1=zeros(my,mx);
        
        beliefL0_log=zeros(my,mx);
        beliefL1_log=zeros(my,mx);
                
    %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% compute the upward messages 
    
        % calculate the upward messages from lowest level first
        cprmatrix_buttom_1_log=log((1-Pl)/epsilon_tilde)-z(1:my/2,mx/2+1:mx).^2/(2*sigma2*(1+epsilon2));
        cprmatrix_buttom_3_log=log((1-Ph)/epsilon_tilde)-z(1:my/2,mx/2+1:mx).^2/(2*sigma2*(1+epsilon2));
        
        cpresultL0=cprmatrix_buttom_1_log>=log(Pl/gamma_tilde)-z(1:my/2,mx/2+1:mx).^2/(2*sigma2*(1+gamma2));
        cpresultL1=cprmatrix_buttom_3_log>=log(Ph/gamma_tilde)-z(1:my/2,mx/2+1:mx).^2/(2*sigma2*(1+gamma2));
        msgupL0_temp=log(Pl/gamma_tilde)-z(1:my/2,mx/2+1:mx).^2/(2*sigma2*(1+gamma2));
        msgupL0_temp(cpresultL0==1)=cprmatrix_buttom_1_log(cpresultL0==1);
        msgupL1_temp=log(Ph/gamma_tilde)-z(1:my/2,mx/2+1:mx).^2/(2*sigma2*(1+gamma2));
        msgupL1_temp(cpresultL1==1)=cprmatrix_buttom_3_log(cpresultL1==1);
        msgupL0(1:my/2,mx/2+1:mx)=exp(msgupL0_temp-msgupL1_temp)./(exp(msgupL0_temp-msgupL1_temp)+1);
        msgupL1(1:my/2,mx/2+1:mx)=1./(exp(msgupL0_temp-msgupL1_temp)+1);

       
        cprmatrix_buttom_1_log=log((1-Pl)/epsilon_tilde)-z(mx/2+1:mx,1:my/2).^2/(2*sigma2*(1+epsilon2));
        cprmatrix_buttom_3_log=log((1-Ph)/epsilon_tilde)-z(mx/2+1:mx,1:my/2).^2/(2*sigma2*(1+epsilon2));
       
        cpresultL0=cprmatrix_buttom_1_log>=log(Pl/gamma_tilde)-z(mx/2+1:mx,1:my/2).^2/(2*sigma2*(1+gamma2));
        cpresultL1=cprmatrix_buttom_3_log>=log(Ph/gamma_tilde)-z(mx/2+1:mx,1:my/2).^2/(2*sigma2*(1+gamma2));
        msgupL0_temp=log(Pl/gamma_tilde)-z(mx/2+1:mx,1:my/2).^2/(2*sigma2*(1+gamma2));
        msgupL0_temp(cpresultL0==1)=cprmatrix_buttom_1_log(cpresultL0==1);    
        msgupL1_temp=log(Ph/gamma_tilde)-z(mx/2+1:mx,1:my/2).^2/(2*sigma2*(1+gamma2));
        msgupL1_temp(cpresultL1==1)=cprmatrix_buttom_3_log(cpresultL1==1);
        msgupL0(mx/2+1:mx,1:my/2)=exp(msgupL0_temp-msgupL1_temp)./(exp(msgupL0_temp-msgupL1_temp)+1);
        msgupL1(mx/2+1:mx,1:my/2)=1./(exp(msgupL0_temp-msgupL1_temp)+1);

    
        cprmatrix_buttom_1_log=log((1-Pl)/epsilon_tilde)-z(my/2+1:my,mx/2+1:mx).^2/(2*sigma2*(1+epsilon2));
        cprmatrix_buttom_3_log=log((1-Ph)/epsilon_tilde)-z(my/2+1:my,mx/2+1:mx).^2/(2*sigma2*(1+epsilon2));

        cpresultL0=cprmatrix_buttom_1_log>=log(Pl/gamma_tilde)-z(my/2+1:my,mx/2+1:mx).^2/(2*sigma2*(1+gamma2));
        cpresultL1=cprmatrix_buttom_3_log>=log(Ph/gamma_tilde)-z(my/2+1:my,mx/2+1:mx).^2/(2*sigma2*(1+gamma2));
        msgupL0_temp=log(Pl/gamma_tilde)-z(my/2+1:my,mx/2+1:mx).^2/(2*sigma2*(1+gamma2));
        msgupL0_temp(cpresultL0==1)=cprmatrix_buttom_1_log(cpresultL0==1);
        msgupL1_temp=log(Ph/gamma_tilde)-z(my/2+1:my,mx/2+1:mx).^2/(2*sigma2*(1+gamma2));
        msgupL1_temp(cpresultL1==1)=cprmatrix_buttom_3_log(cpresultL1==1);
        msgupL0(my/2+1:my,mx/2+1:mx)=exp(msgupL0_temp-msgupL1_temp)./(exp(msgupL0_temp-msgupL1_temp)+1);
        msgupL1(my/2+1:my,mx/2+1:mx)=1./(exp(msgupL0_temp-msgupL1_temp)+1);
        
        clear msgupL0_temp;
        clear msgupL1_temp;
        clear cprmatrix_buttom_1;
        clear cprmatrix_buttom_3;
        
        % calculate the remaining upward messages 
        for k=1:L-2        
            % messages product from children
            childrencluster_upL0=msgupL0(1:2:my/2^k-1,mx/2^k+1:2:mx/2^(k-1)-1).*msgupL0(1:2:my/2^k-1,mx/2^k+2:2:mx/2^(k-1)).*...,
                                 msgupL0(2:2:my/2^k,mx/2^k+1:2:mx/2^(k-1)-1).*msgupL0(2:2:my/2^k,mx/2^k+2:2:mx/2^(k-1));
            childrencluster_upL1=msgupL1(1:2:my/2^k-1,mx/2^k+1:2:mx/2^(k-1)-1).*msgupL1(1:2:my/2^k-1,mx/2^k+2:2:mx/2^(k-1)).*...,
                                 msgupL1(2:2:my/2^k,mx/2^k+1:2:mx/2^(k-1)-1).*msgupL1(2:2:my/2^k,mx/2^k+2:2:mx/2^(k-1));
        
            cprmatrix_upL1_log=log((1-Pl)/epsilon_tilde)-z(1:my/2^(k+1),mx/2^(k+1)+1:mx/2^k).^2/(2*sigma2*(1+epsilon2))+log(childrencluster_upL0);
            cprmatrix_upL2_log=log(Pl/gamma_tilde)-z(1:my/2^(k+1),mx/2^(k+1)+1:mx/2^k).^2/(2*sigma2*(1+gamma2))+log(childrencluster_upL1);
            cprmatrix_upL3_log=log((1-Ph)/epsilon_tilde)-z(1:my/2^(k+1),mx/2^(k+1)+1:mx/2^k).^2/(2*sigma2*(1+epsilon2))+log(childrencluster_upL0);
            cprmatrix_upL4_log=log(Ph/gamma_tilde)-z(1:my/2^(k+1),mx/2^(k+1)+1:mx/2^k).^2/(2*sigma2*(1+gamma2))+log(childrencluster_upL1);
                        
            msgupL0_temp=cprmatrix_upL2_log;
            msgupL0_temp(cprmatrix_upL1_log>=cprmatrix_upL2_log)=cprmatrix_upL1_log(cprmatrix_upL1_log>=cprmatrix_upL2_log);
            msgupL1_temp=cprmatrix_upL4_log;
            msgupL1_temp(cprmatrix_upL3_log>=cprmatrix_upL4_log)=cprmatrix_upL3_log(cprmatrix_upL3_log>=cprmatrix_upL4_log);
            msgupL0(1:my/2^(k+1),mx/2^(k+1)+1:mx/2^k)=exp(msgupL0_temp-msgupL1_temp)./(exp(msgupL0_temp-msgupL1_temp)+1);
            msgupL1(1:my/2^(k+1),mx/2^(k+1)+1:mx/2^k)=1./(exp(msgupL0_temp-msgupL1_temp)+1);

            
            childrencluster_upL0=msgupL0(mx/2^k+1:2:mx/2^(k-1)-1,1:2:my/2^k-1).* msgupL0(mx/2^k+1:2:mx/2^(k-1)-1,2:2:my/2^k).*...,
                                 msgupL0(mx/2^k+2:2:mx/2^(k-1),1:2:my/2^k-1).*msgupL0(mx/2^k+2:2:mx/2^(k-1),2:2:my/2^k);
            childrencluster_upL1=msgupL1(mx/2^k+1:2:mx/2^(k-1)-1,1:2:my/2^k-1).*msgupL1(mx/2^k+1:2:mx/2^(k-1)-1,2:2:my/2^k).*...,
                                 msgupL1(mx/2^k+2:2:mx/2^(k-1),1:2:my/2^k-1).*msgupL1(mx/2^k+2:2:mx/2^(k-1),2:2:my/2^k);
           
            cprmatrix_upL1_log=log((1-Pl)/epsilon_tilde)-z(mx/2^(k+1)+1:mx/2^k,1:my/2^(k+1)).^2/(2*sigma2*(1+epsilon2))+log(childrencluster_upL0);
            cprmatrix_upL2_log=log(Pl/gamma_tilde)-z(mx/2^(k+1)+1:mx/2^k,1:my/2^(k+1)).^2/(2*sigma2*(1+gamma2))+log(childrencluster_upL1);
            cprmatrix_upL3_log=log((1-Ph)/epsilon_tilde)-z(mx/2^(k+1)+1:mx/2^k,1:my/2^(k+1)).^2/(2*sigma2*(1+epsilon2))+log(childrencluster_upL0);
            cprmatrix_upL4_log=log(Ph/gamma_tilde)-z(mx/2^(k+1)+1:mx/2^k,1:my/2^(k+1)).^2/(2*sigma2*(1+gamma2))+log(childrencluster_upL1);

            msgupL0_temp=cprmatrix_upL2_log;
            msgupL0_temp(cprmatrix_upL1_log>=cprmatrix_upL2_log)=cprmatrix_upL1_log(cprmatrix_upL1_log>=cprmatrix_upL2_log);
            msgupL1_temp=cprmatrix_upL4_log;
            msgupL1_temp(cprmatrix_upL3_log>=cprmatrix_upL4_log)=cprmatrix_upL3_log(cprmatrix_upL3_log>=cprmatrix_upL4_log);
            msgupL0(mx/2^(k+1)+1:mx/2^k,1:my/2^(k+1))=exp(msgupL0_temp-msgupL1_temp)./(exp(msgupL0_temp-msgupL1_temp)+1);
            msgupL1(mx/2^(k+1)+1:mx/2^k,1:my/2^(k+1))=1./(exp(msgupL0_temp-msgupL1_temp)+1);
            
        
            childrencluster_upL0=msgupL0(1+my/2^k:2:my/2^(k-1)-1,mx/2^k+1:2:mx/2^(k-1)-1).*msgupL0(1+my/2^k:2:my/2^(k-1)-1,mx/2^k+2:2:mx/2^(k-1)).*...,
                                 msgupL0(2+my/2^k:2:my/2^(k-1),mx/2^k+1:2:mx/2^(k-1)-1).*msgupL0(2+my/2^k:2:my/2^(k-1),mx/2^k+2:2:mx/2^(k-1));
            childrencluster_upL1=msgupL1(1+my/2^k:2:my/2^(k-1)-1,mx/2^k+1:2:mx/2^(k-1)-1).*msgupL1(1+my/2^k:2:my/2^(k-1)-1,mx/2^k+2:2:mx/2^(k-1)).*...,
                                 msgupL1(2+my/2^k:2:my/2^(k-1),mx/2^k+1:2:mx/2^(k-1)-1).*msgupL1(2+my/2^k:2:my/2^(k-1),mx/2^k+2:2:mx/2^(k-1));
                      
            cprmatrix_upL1_log=log((1-Pl)/epsilon_tilde)-z(1+my/2^(k+1):my/2^(k),mx/2^(k+1)+1:mx/2^k).^2/(2*sigma2*(1+epsilon2))+log(childrencluster_upL0);
            cprmatrix_upL2_log=log(Pl/gamma_tilde)-z(1+my/2^(k+1):my/2^(k),mx/2^(k+1)+1:mx/2^k).^2/(2*sigma2*(1+gamma2))+log(childrencluster_upL1);
            cprmatrix_upL3_log=log((1-Ph)/epsilon_tilde)-z(1+my/2^(k+1):my/2^(k),mx/2^(k+1)+1:mx/2^k).^2/(2*sigma2*(1+epsilon2))+log(childrencluster_upL0);
            cprmatrix_upL4_log=log(Ph/gamma_tilde)-z(1+my/2^(k+1):my/2^(k),mx/2^(k+1)+1:mx/2^k).^2/(2*sigma2*(1+gamma2))+log(childrencluster_upL1);
            
            msgupL0_temp=cprmatrix_upL2_log;
            msgupL0_temp(cprmatrix_upL1_log>=cprmatrix_upL2_log)=cprmatrix_upL1_log(cprmatrix_upL1_log>=cprmatrix_upL2_log);
            msgupL1_temp=cprmatrix_upL4_log;
            msgupL1_temp(cprmatrix_upL3_log>=cprmatrix_upL4_log)=cprmatrix_upL3_log(cprmatrix_upL3_log>=cprmatrix_upL4_log);
            msgupL0(1+my/2^(k+1):my/2^(k),mx/2^(k+1)+1:mx/2^k)=exp(msgupL0_temp-msgupL1_temp)./(exp(msgupL0_temp-msgupL1_temp)+1);
            msgupL1(1+my/2^(k+1):my/2^(k),mx/2^(k+1)+1:mx/2^k)=1./(exp(msgupL0_temp-msgupL1_temp)+1);
        end
 
        %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% compute the downward messages
        
        % calculate the messages from the top level first
        
        % compute the horizontal part
        % messages product from siblings
        childrenupL0_1=msgupL0(1:2:my/2^(L-1)-1,mx/2^(L-1)+2:2:mx/2^(L-2)).*msgupL0(2:2:my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*...,
                       msgupL0(2:2:my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2));
        childrenupL0_2=msgupL0(1:2:my/2^(L-1)-1,mx/2^(L-1)+1:2:mx/2^(L-2)-1).*msgupL0(2:2:my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*...,
                       msgupL0(2:2:my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2)); 
        childrenupL0_3=msgupL0(1:2:my/2^(L-1)-1,mx/2^(L-1)+1:2:mx/2^(L-2)-1).*msgupL0(1:2:my/2^(L-1)-1,mx/2^(L-1)+2:2:mx/2^(L-2)).*...,
                       msgupL0(2:2:my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2));
        childrenupL0_4=msgupL0(1:2:my/2^(L-1)-1,mx/2^(L-1)+1:2:mx/2^(L-2)-1).*msgupL0(1:2:my/2^(L-1)-1,mx/2^(L-1)+2:2:mx/2^(L-2)).*...,
                       msgupL0(2:2:my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1); 
               
        childrenupL1_1=msgupL1(1:2:my/2^(L-1)-1,mx/2^(L-1)+2:2:mx/2^(L-2)).*msgupL1(2:2:my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*...,
                       msgupL1(2:2:my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2));
        childrenupL1_2=msgupL1(1:2:my/2^(L-1)-1,mx/2^(L-1)+1:2:mx/2^(L-2)-1).*msgupL1(2:2:my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*...,
                       msgupL1(2:2:my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2)); 
        childrenupL1_3=msgupL1(1:2:my/2^(L-1)-1,mx/2^(L-1)+1:2:mx/2^(L-2)-1).*msgupL1(1:2:my/2^(L-1)-1,mx/2^(L-1)+2:2:mx/2^(L-2)).*...,
                       msgupL1(2:2:my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2));
        childrenupL1_4=msgupL1(1:2:my/2^(L-1)-1,mx/2^(L-1)+1:2:mx/2^(L-2)-1).*msgupL1(1:2:my/2^(L-1)-1,mx/2^(L-1)+2:2:mx/2^(L-2)).*...,
                       msgupL1(2:2:my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1);
              
        cprmatrix1_1_log=log((1-Proot)*(1-Pl)/epsilon_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_1);
        cprmatrix1_2_log=log(Proot*(1-Ph)/gamma_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_1);
        cprmatrix1_3_log=log((1-Proot)*Pl/epsilon_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_1);
        cprmatrix1_4_log=log(Proot*Ph/gamma_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_1);
        
        cprmatrix2_1_log=log((1-Proot)*(1-Pl)/epsilon_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_2);
        cprmatrix2_2_log=log(Proot*(1-Ph)/gamma_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_2);
        cprmatrix2_3_log=log((1-Proot)*Pl/epsilon_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_2);
        cprmatrix2_4_log=log(Proot*Ph/gamma_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_2);
        
        cprmatrix3_1_log=log((1-Proot)*(1-Pl)/epsilon_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_3);
        cprmatrix3_2_log=log(Proot*(1-Ph)/gamma_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_3);
        cprmatrix3_3_log=log((1-Proot)*Pl/epsilon_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_3);
        cprmatrix3_4_log=log(Proot*Ph/gamma_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_3);
        
        cprmatrix4_1_log=log((1-Proot)*(1-Pl)/epsilon_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_4);
        cprmatrix4_2_log=log(Proot*(1-Ph)/gamma_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_4);
        cprmatrix4_3_log=log((1-Proot)*Pl/epsilon_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_4);
        cprmatrix4_4_log=log(Proot*Ph/gamma_tilde)-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_4);           
          
        msgdownL0_temp=cprmatrix1_2_log;
        msgdownL0_temp(cprmatrix1_1_log>=cprmatrix1_2_log)=cprmatrix1_1_log(cprmatrix1_1_log>=cprmatrix1_2_log);
        msgdownL1_temp=cprmatrix1_4_log;
        msgdownL1_temp(cprmatrix1_3_log>=cprmatrix1_4_log)=cprmatrix1_3_log(cprmatrix1_3_log>=cprmatrix1_4_log);
        msgdownL0(1:2:my/2^(L-1)-1,mx/2^(L-1)+1:2:mx/2^(L-2)-1)=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        msgdownL1(1:2:my/2^(L-1)-1,mx/2^(L-1)+1:2:mx/2^(L-2)-1)=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
        msgdownL0_temp=cprmatrix2_2_log;
        msgdownL0_temp(cprmatrix2_1_log>=cprmatrix2_2_log)=cprmatrix2_1_log(cprmatrix2_1_log>=cprmatrix2_2_log);
        msgdownL1_temp=cprmatrix2_4_log;
        msgdownL1_temp(cprmatrix2_3_log>=cprmatrix2_4_log)=cprmatrix2_3_log(cprmatrix2_3_log>=cprmatrix2_4_log);
        msgdownL0(1:2:my/2^(L-1)-1,mx/2^(L-1)+2:2:mx/2^(L-2))=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        msgdownL1(1:2:my/2^(L-1)-1,mx/2^(L-1)+2:2:mx/2^(L-2))=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
        msgdownL0_temp=cprmatrix3_2_log;
        msgdownL0_temp(cprmatrix3_1_log>=cprmatrix3_2_log)=cprmatrix3_1_log(cprmatrix3_1_log>=cprmatrix3_2_log);
        msgdownL1_temp=cprmatrix3_4_log;
        msgdownL1_temp(cprmatrix3_3_log>=cprmatrix3_4_log)=cprmatrix3_3_log(cprmatrix3_3_log>=cprmatrix3_4_log);
        msgdownL0(2:2:my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1)=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        msgdownL1(2:2:my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1)=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
        msgdownL0_temp=cprmatrix4_2_log;
        msgdownL0_temp(cprmatrix4_1_log>=cprmatrix4_2_log)=cprmatrix4_1_log(cprmatrix4_1_log>=cprmatrix4_2_log);
        msgdownL1_temp=cprmatrix4_4_log;
        msgdownL1_temp(cprmatrix4_3_log>=cprmatrix4_4_log)=cprmatrix4_3_log(cprmatrix4_3_log>=cprmatrix4_4_log);
        msgdownL0(2:2:my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2))=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        msgdownL1(2:2:my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2))=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
        
        % compute the vertical part
        childrenupL0_1=msgupL0(mx/2^(L-1)+2:2:mx/2^(L-2),1:2:my/2^(L-1)-1).*msgupL0(mx/2^(L-1)+1:2:mx/2^(L-2)-1,2:2:my/2^(L-1)).*...,
                       msgupL0(mx/2^(L-1)+2:2:mx/2^(L-2),2:2:my/2^(L-1));
        childrenupL0_3=msgupL0(mx/2^(L-1)+1:2:mx/2^(L-2)-1,1:2:my/2^(L-1)-1).*msgupL0(mx/2^(L-1)+1:2:mx/2^(L-2)-1,2:2:my/2^(L-1)).*...,
                       msgupL0(mx/2^(L-1)+2:2:mx/2^(L-2),2:2:my/2^(L-1)); 
        childrenupL0_2=msgupL0(mx/2^(L-1)+1:2:mx/2^(L-2)-1,1:2:my/2^(L-1)-1).*msgupL0(mx/2^(L-1)+2:2:mx/2^(L-2),1:2:my/2^(L-1)-1).*...,
                       msgupL0(mx/2^(L-1)+2:2:mx/2^(L-2),2:2:my/2^(L-1));
        childrenupL0_4=msgupL0(mx/2^(L-1)+1:2:mx/2^(L-2)-1,1:2:my/2^(L-1)-1).*msgupL0(mx/2^(L-1)+2:2:mx/2^(L-2),1:2:my/2^(L-1)-1).*...,
                       msgupL0(mx/2^(L-1)+1:2:mx/2^(L-2)-1,2:2:my/2^(L-1)); 
               
        childrenupL1_1=msgupL1(mx/2^(L-1)+2:2:mx/2^(L-2),1:2:my/2^(L-1)-1).*msgupL1(mx/2^(L-1)+1:2:mx/2^(L-2)-1,2:2:my/2^(L-1)).*...,
                       msgupL1(mx/2^(L-1)+2:2:mx/2^(L-2),2:2:my/2^(L-1));
        childrenupL1_3=msgupL1(mx/2^(L-1)+1:2:mx/2^(L-2)-1,1:2:my/2^(L-1)-1).*msgupL1(mx/2^(L-1)+1:2:mx/2^(L-2)-1,2:2:my/2^(L-1)).*...,
                       msgupL1(mx/2^(L-1)+2:2:mx/2^(L-2),2:2:my/2^(L-1)); 
        childrenupL1_2=msgupL1(mx/2^(L-1)+1:2:mx/2^(L-2)-1,1:2:my/2^(L-1)-1).*msgupL1(mx/2^(L-1)+2:2:mx/2^(L-2),1:2:my/2^(L-1)-1).*...,
                       msgupL1(mx/2^(L-1)+2:2:mx/2^(L-2),2:2:my/2^(L-1));
        childrenupL1_4=msgupL1(mx/2^(L-1)+1:2:mx/2^(L-2)-1,1:2:my/2^(L-1)-1).*msgupL1(mx/2^(L-1)+2:2:mx/2^(L-2),1:2:my/2^(L-1)-1).*...,
                       msgupL1(mx/2^(L-1)+1:2:mx/2^(L-2)-1,2:2:my/2^(L-1));
                   
        cprmatrix1_1_log=log((1-Proot)*(1-Pl)/epsilon_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_1);
        cprmatrix1_2_log=log(Proot*(1-Ph)/gamma_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_1);
        cprmatrix1_3_log=log((1-Proot)*Pl/epsilon_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_1);
        cprmatrix1_4_log=log(Proot*Ph/gamma_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_1);
        
        cprmatrix2_1_log=log((1-Proot)*(1-Pl)/epsilon_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_2);
        cprmatrix2_2_log=log(Proot*(1-Ph)/gamma_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_2);
        cprmatrix2_3_log=log((1-Proot)*Pl/epsilon_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_2);
        cprmatrix2_4_log=log(Proot*Ph/gamma_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_2);
        
        cprmatrix3_1_log=log((1-Proot)*(1-Pl)/epsilon_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_3);
        cprmatrix3_2_log=log(Proot*(1-Ph)/gamma_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_3);
        cprmatrix3_3_log=log((1-Proot)*Pl/epsilon_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_3);
        cprmatrix3_4_log=log(Proot*Ph/gamma_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_3);
        
        cprmatrix4_1_log=log((1-Proot)*(1-Pl)/epsilon_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_4);
        cprmatrix4_2_log=log(Proot*(1-Ph)/gamma_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_4);
        cprmatrix4_3_log=log((1-Proot)*Pl/epsilon_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_4);
        cprmatrix4_4_log=log(Proot*Ph/gamma_tilde)-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_4);           
   
        msgdownL0_temp=cprmatrix1_2_log;
        msgdownL0_temp(cprmatrix1_1_log>=cprmatrix1_2_log)=cprmatrix1_1_log(cprmatrix1_1_log>=cprmatrix1_2_log);
        msgdownL1_temp=cprmatrix1_4_log;
        msgdownL1_temp(cprmatrix1_3_log>=cprmatrix1_4_log)=cprmatrix1_3_log(cprmatrix1_3_log>=cprmatrix1_4_log);
        msgdownL0(mx/2^(L-1)+1:2:mx/2^(L-2)-1,1:2:my/2^(L-1)-1)=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        msgdownL1(mx/2^(L-1)+1:2:mx/2^(L-2)-1,1:2:my/2^(L-1)-1)=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
        msgdownL0_temp=cprmatrix2_2_log;
        msgdownL0_temp(cprmatrix2_1_log>=cprmatrix2_2_log)=cprmatrix2_1_log(cprmatrix2_1_log>=cprmatrix2_2_log);
        msgdownL1_temp=cprmatrix2_4_log;
        msgdownL1_temp(cprmatrix2_3_log>=cprmatrix2_4_log)=cprmatrix2_3_log(cprmatrix2_3_log>=cprmatrix2_4_log);
        msgdownL0(mx/2^(L-1)+1:2:mx/2^(L-2)-1,2:2:my/2^(L-1))=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        msgdownL1(mx/2^(L-1)+1:2:mx/2^(L-2)-1,2:2:my/2^(L-1))=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
        msgdownL0_temp=cprmatrix3_2_log;
        msgdownL0_temp(cprmatrix3_1_log>=cprmatrix3_2_log)=cprmatrix3_1_log(cprmatrix3_1_log>=cprmatrix3_2_log);
        msgdownL1_temp=cprmatrix3_4_log;
        msgdownL1_temp(cprmatrix3_3_log>=cprmatrix3_4_log)=cprmatrix3_3_log(cprmatrix3_3_log>=cprmatrix3_4_log);
        msgdownL0(mx/2^(L-1)+2:2:mx/2^(L-2),1:2:my/2^(L-1)-1)=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        msgdownL1(mx/2^(L-1)+2:2:mx/2^(L-2),1:2:my/2^(L-1)-1)=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
        msgdownL0_temp=cprmatrix4_2_log;
        msgdownL0_temp(cprmatrix4_1_log>=cprmatrix4_2_log)=cprmatrix4_1_log(cprmatrix4_1_log>=cprmatrix4_2_log);
        msgdownL1_temp=cprmatrix4_4_log;
        msgdownL1_temp(cprmatrix4_3_log>=cprmatrix4_4_log)=cprmatrix4_3_log(cprmatrix4_3_log>=cprmatrix4_4_log);
        msgdownL0(mx/2^(L-1)+2:2:mx/2^(L-2),2:2:my/2^(L-1))=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        msgdownL1(mx/2^(L-1)+2:2:mx/2^(L-2),2:2:my/2^(L-1))=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
        % compute the diagonal part
        childrenupL0_1=msgupL0(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2)).*msgupL0(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*...,
                       msgupL0(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2));
        childrenupL0_2=msgupL0(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*msgupL0(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*...,
                       msgupL0(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2)); 
        childrenupL0_3=msgupL0(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*msgupL0(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2)).*...,
                       msgupL0(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2));
        childrenupL0_4=msgupL0(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*msgupL0(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2)).*...,
                       msgupL0(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1); 
               
        childrenupL1_1=msgupL1(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2)).*msgupL1(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*...,
                       msgupL1(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2));
        childrenupL1_2=msgupL1(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*msgupL1(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*...,
                       msgupL1(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2)); 
        childrenupL1_3=msgupL1(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*msgupL1(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2)).*...,
                       msgupL1(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2));
        childrenupL1_4=msgupL1(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1).*msgupL1(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2)).*...,
                       msgupL1(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1);   
        
        cprmatrix1_1_log=log((1-Proot)*(1-Pl)/epsilon_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_1);
        cprmatrix1_2_log=log(Proot*(1-Ph)/gamma_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_1);
        cprmatrix1_3_log=log((1-Proot)*Pl/epsilon_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_1);
        cprmatrix1_4_log=log(Proot*Ph/gamma_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_1);
        
        cprmatrix2_1_log=log((1-Proot)*(1-Pl)/epsilon_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_2);
        cprmatrix2_2_log=log(Proot*(1-Ph)/gamma_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_2);
        cprmatrix2_3_log=log((1-Proot)*Pl/epsilon_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_2);
        cprmatrix2_4_log=log(Proot*Ph/gamma_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_2);
        
        cprmatrix3_1_log=log((1-Proot)*(1-Pl)/epsilon_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_3);
        cprmatrix3_2_log=log(Proot*(1-Ph)/gamma_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_3);
        cprmatrix3_3_log=log((1-Proot)*Pl/epsilon_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_3);
        cprmatrix3_4_log=log(Proot*Ph/gamma_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_3);
        
        cprmatrix4_1_log=log((1-Proot)*(1-Pl)/epsilon_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_4);
        cprmatrix4_2_log=log(Proot*(1-Ph)/gamma_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_4);
        cprmatrix4_3_log=log((1-Proot)*Pl/epsilon_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_4);
        cprmatrix4_4_log=log(Proot*Ph/gamma_tilde)-z(1+my/2^(L):my/2^(L)+my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_4);
           
        msgdownL0_temp=cprmatrix1_2_log;
        msgdownL0_temp(cprmatrix1_1_log>=cprmatrix1_2_log)=cprmatrix1_1_log(cprmatrix1_1_log>=cprmatrix1_2_log);
        msgdownL1_temp=cprmatrix1_4_log;
        msgdownL1_temp(cprmatrix1_3_log>=cprmatrix1_4_log)=cprmatrix1_3_log(cprmatrix1_3_log>=cprmatrix1_4_log);
        msgdownL0(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1)=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        msgdownL1(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1)=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
        msgdownL0_temp=cprmatrix2_2_log;
        msgdownL0_temp(cprmatrix2_1_log>=cprmatrix2_2_log)=cprmatrix2_1_log(cprmatrix2_1_log>=cprmatrix2_2_log);
        msgdownL1_temp=cprmatrix2_4_log;
        msgdownL1_temp(cprmatrix2_3_log>=cprmatrix2_4_log)=cprmatrix2_3_log(cprmatrix2_3_log>=cprmatrix2_4_log);
        msgdownL0(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2))=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        msgdownL1(1+my/2^(L-1):2:my/2^(L-1)-1+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2))=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
        msgdownL0_temp=cprmatrix3_2_log;
        msgdownL0_temp(cprmatrix3_1_log>=cprmatrix3_2_log)=cprmatrix3_1_log(cprmatrix3_1_log>=cprmatrix3_2_log);
        msgdownL1_temp=cprmatrix3_4_log;
        msgdownL1_temp(cprmatrix3_3_log>=cprmatrix3_4_log)=cprmatrix3_3_log(cprmatrix3_3_log>=cprmatrix3_4_log);
        msgdownL0(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1)=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        msgdownL1(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1)=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
        msgdownL0_temp=cprmatrix4_2_log;
        msgdownL0_temp(cprmatrix4_1_log>=cprmatrix4_2_log)=cprmatrix4_1_log(cprmatrix4_1_log>=cprmatrix4_2_log);
        msgdownL1_temp=cprmatrix4_4_log;
        msgdownL1_temp(cprmatrix4_3_log>=cprmatrix4_4_log)=cprmatrix4_3_log(cprmatrix4_3_log>=cprmatrix4_4_log);
        msgdownL0(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2))=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        msgdownL1(2+my/2^(L-1):2:my/2^(L-1)+my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2))=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
          
              
        
        % compute the remaining downward messages
        lastrow=zeros(L-1,1);
        lastcolumn=zeros(L-1,1);
        diag_shift=zeros(L-1,1);
        for k=2:L-1
            lastrow(k)=my/2^(L-k);
            lastcolumn(k)=mx/2^(L-1-k);
            % horizontal part
            childrenupL0_1=msgupL0(1:2:lastrow(k)-1,lastrow(k)+2:2:lastcolumn(k)).*msgupL0(2:2:lastrow(k),lastrow(k)+1:2:lastcolumn(k)-1).*...,
                           msgupL0(2:2:lastrow(k),lastrow(k)+2:2:lastcolumn(k));
            childrenupL0_2=msgupL0(1:2:lastrow(k)-1,lastrow(k)+1:2:lastcolumn(k)-1).*msgupL0(2:2:lastrow(k),lastrow(k)+1:2:lastcolumn(k)-1).*...,
                           msgupL0(2:2:lastrow(k),lastrow(k)+2:2:lastcolumn(k)); 
            childrenupL0_3=msgupL0(1:2:lastrow(k)-1,lastrow(k)+1:2:lastcolumn(k)-1).*msgupL0(1:2:lastrow(k)-1,lastrow(k)+2:2:lastcolumn(k)).*...,
                           msgupL0(2:2:lastrow(k),lastrow(k)+2:2:lastcolumn(k));
            childrenupL0_4=msgupL0(1:2:lastrow(k)-1,lastrow(k)+1:2:lastcolumn(k)-1).*msgupL0(1:2:lastrow(k)-1,lastrow(k)+2:2:lastcolumn(k)).*...,
                           msgupL0(2:2:lastrow(k),lastrow(k)+1:2:lastcolumn(k)-1); 
               
            childrenupL1_1=msgupL1(1:2:lastrow(k)-1,lastrow(k)+2:2:lastcolumn(k)).*msgupL1(2:2:lastrow(k),lastrow(k)+1:2:lastcolumn(k)-1).*...,
                           msgupL1(2:2:lastrow(k),lastrow(k)+2:2:lastcolumn(k));
            childrenupL1_2=msgupL1(1:2:lastrow(k)-1,lastrow(k)+1:2:lastcolumn(k)-1).*msgupL1(2:2:lastrow(k),lastrow(k)+1:2:lastcolumn(k)-1).*...,
                           msgupL1(2:2:lastrow(k),lastrow(k)+2:2:lastcolumn(k)); 
            childrenupL1_3=msgupL1(1:2:lastrow(k)-1,lastrow(k)+1:2:lastcolumn(k)-1).*msgupL1(1:2:lastrow(k)-1,lastrow(k)+2:2:lastcolumn(k)).*...,
                           msgupL1(2:2:lastrow(k),lastrow(k)+2:2:lastcolumn(k));
            childrenupL1_4=msgupL1(1:2:lastrow(k)-1,lastrow(k)+1:2:lastcolumn(k)-1).*msgupL1(1:2:lastrow(k)-1,lastrow(k)+2:2:lastcolumn(k)).*...,
                           msgupL1(2:2:lastrow(k),lastrow(k)+1:2:lastcolumn(k)-1); 
                          
            cprmatrix1_1_log=log((1-Pl)/epsilon_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_1)+log(msgdownL0(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix1_2_log=log((1-Ph)/gamma_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_1)+log(msgdownL1(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix1_3_log=log(Pl/epsilon_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_1)+log(msgdownL0(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix1_4_log=log(Ph/gamma_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_1)+log(msgdownL1(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
        
            cprmatrix2_1_log=log((1-Pl)/epsilon_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_2)+log(msgdownL0(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix2_2_log=log((1-Ph)/gamma_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_2)+log(msgdownL1(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix2_3_log=log(Pl/epsilon_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_2)+log(msgdownL0(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix2_4_log=log(Ph/gamma_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_2)+log(msgdownL1(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
        
            cprmatrix3_1_log=log((1-Pl)/epsilon_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_3)+log(msgdownL0(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix3_2_log=log((1-Ph)/gamma_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_3)+log(msgdownL1(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix3_3_log=log(Pl/epsilon_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_3)+log(msgdownL0(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix3_4_log=log(Ph/gamma_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_3)+log(msgdownL1(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
        
            cprmatrix4_1_log=log((1-Pl)/epsilon_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_4)+log(msgdownL0(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix4_2_log=log((1-Ph)/gamma_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_4)+log(msgdownL1(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix4_3_log=log(Pl/epsilon_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_4)+log(msgdownL0(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix4_4_log=log(Ph/gamma_tilde)-z(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_4)+log(msgdownL1(1:lastrow(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));

            msgdownL0_temp=cprmatrix1_2_log;
            msgdownL0_temp(cprmatrix1_1_log>=cprmatrix1_2_log)=cprmatrix1_1_log(cprmatrix1_1_log>=cprmatrix1_2_log);
            msgdownL1_temp=cprmatrix1_4_log;
            msgdownL1_temp(cprmatrix1_3_log>=cprmatrix1_4_log)=cprmatrix1_3_log(cprmatrix1_3_log>=cprmatrix1_4_log);
            msgdownL0(1:2:lastrow(k)-1,lastrow(k)+1:2:lastcolumn(k)-1)=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
            msgdownL1(1:2:lastrow(k)-1,lastrow(k)+1:2:lastcolumn(k)-1)=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
            msgdownL0_temp=cprmatrix2_2_log;
            msgdownL0_temp(cprmatrix2_1_log>=cprmatrix2_2_log)=cprmatrix2_1_log(cprmatrix2_1_log>=cprmatrix2_2_log);
            msgdownL1_temp=cprmatrix2_4_log;
            msgdownL1_temp(cprmatrix2_3_log>=cprmatrix2_4_log)=cprmatrix2_3_log(cprmatrix2_3_log>=cprmatrix2_4_log);
            msgdownL0(1:2:lastrow(k)-1,lastrow(k)+2:2:lastcolumn(k))=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
            msgdownL1(1:2:lastrow(k)-1,lastrow(k)+2:2:lastcolumn(k))=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
            msgdownL0_temp=cprmatrix3_2_log;
            msgdownL0_temp(cprmatrix3_1_log>=cprmatrix3_2_log)=cprmatrix3_1_log(cprmatrix3_1_log>=cprmatrix3_2_log);
            msgdownL1_temp=cprmatrix3_4_log;
            msgdownL1_temp(cprmatrix3_3_log>=cprmatrix3_4_log)=cprmatrix3_3_log(cprmatrix3_3_log>=cprmatrix3_4_log);
            msgdownL0(2:2:lastrow(k),lastrow(k)+1:2:lastcolumn(k)-1)=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
            msgdownL1(2:2:lastrow(k),lastrow(k)+1:2:lastcolumn(k)-1)=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
            msgdownL0_temp=cprmatrix4_2_log;
            msgdownL0_temp(cprmatrix4_1_log>=cprmatrix4_2_log)=cprmatrix4_1_log(cprmatrix4_1_log>=cprmatrix4_2_log);
            msgdownL1_temp=cprmatrix4_4_log;
            msgdownL1_temp(cprmatrix4_3_log>=cprmatrix4_4_log)=cprmatrix4_3_log(cprmatrix4_3_log>=cprmatrix4_4_log);
            msgdownL0(2:2:lastrow(k),lastrow(k)+2:2:lastcolumn(k))=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
            msgdownL1(2:2:lastrow(k),lastrow(k)+2:2:lastcolumn(k))=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);


            % vertical part
            childrenupL0_1=msgupL0(lastrow(k)+2:2:lastcolumn(k),1:2:lastrow(k)-1).*msgupL0(lastrow(k)+1:2:lastcolumn(k)-1,2:2:lastrow(k)).*...,
                           msgupL0(lastrow(k)+2:2:lastcolumn(k),2:2:lastrow(k));
            childrenupL0_3=msgupL0(lastrow(k)+1:2:lastcolumn(k)-1,1:2:lastrow(k)-1).*msgupL0(lastrow(k)+1:2:lastcolumn(k)-1,2:2:lastrow(k)).*...,
                           msgupL0(lastrow(k)+2:2:lastcolumn(k),2:2:lastrow(k)); 
            childrenupL0_2=msgupL0(lastrow(k)+1:2:lastcolumn(k)-1,1:2:lastrow(k)-1).*msgupL0(lastrow(k)+2:2:lastcolumn(k),1:2:lastrow(k)-1).*...,
                           msgupL0(lastrow(k)+2:2:lastcolumn(k),2:2:lastrow(k));
            childrenupL0_4=msgupL0(lastrow(k)+1:2:lastcolumn(k)-1,1:2:lastrow(k)-1).*msgupL0(lastrow(k)+2:2:lastcolumn(k),1:2:lastrow(k)-1).*...,
                           msgupL0(lastrow(k)+1:2:lastcolumn(k)-1,2:2:lastrow(k)); 
               
            childrenupL1_1=msgupL1(lastrow(k)+2:2:lastcolumn(k),1:2:lastrow(k)-1).*msgupL1(lastrow(k)+1:2:lastcolumn(k)-1,2:2:lastrow(k)).*...,
                           msgupL1(lastrow(k)+2:2:lastcolumn(k),2:2:lastrow(k));
            childrenupL1_3=msgupL1(lastrow(k)+1:2:lastcolumn(k)-1,1:2:lastrow(k)-1).*msgupL1(lastrow(k)+1:2:lastcolumn(k)-1,2:2:lastrow(k)).*...,
                           msgupL1(lastrow(k)+2:2:lastcolumn(k),2:2:lastrow(k)); 
            childrenupL1_2=msgupL1(lastrow(k)+1:2:lastcolumn(k)-1,1:2:lastrow(k)-1).*msgupL1(lastrow(k)+2:2:lastcolumn(k),1:2:lastrow(k)-1).*...,
                           msgupL1(lastrow(k)+2:2:lastcolumn(k),2:2:lastrow(k));
            childrenupL1_4=msgupL1(lastrow(k)+1:2:lastcolumn(k)-1,1:2:lastrow(k)-1).*msgupL1(lastrow(k)+2:2:lastcolumn(k),1:2:lastrow(k)-1).*...,
                           msgupL1(lastrow(k)+1:2:lastcolumn(k)-1,2:2:lastrow(k));                           
            
            cprmatrix1_1_log=log((1-Pl)/epsilon_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_1)+log(msgdownL0(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
            cprmatrix1_2_log=log((1-Ph)/gamma_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_1)+log(msgdownL1(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
            cprmatrix1_3_log=log(Pl/epsilon_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_1)+log(msgdownL0(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
            cprmatrix1_4_log=log(Ph/gamma_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_1)+log(msgdownL1(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
        
            cprmatrix2_1_log=log((1-Pl)/epsilon_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_2)+log(msgdownL0(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
            cprmatrix2_2_log=log((1-Ph)/gamma_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_2)+log(msgdownL1(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
            cprmatrix2_3_log=log(Pl/epsilon_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_2)+log(msgdownL0(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
            cprmatrix2_4_log=log(Ph/gamma_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_2)+log(msgdownL1(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
        
            cprmatrix3_1_log=log((1-Pl)/epsilon_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_3)+log(msgdownL0(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
            cprmatrix3_2_log=log((1-Ph)/gamma_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_3)+log(msgdownL1(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
            cprmatrix3_3_log=log(Pl/epsilon_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_3)+log(msgdownL0(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
            cprmatrix3_4_log=log(Ph/gamma_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_3)+log(msgdownL1(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
        
            cprmatrix4_1_log=log((1-Pl)/epsilon_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_4)+log(msgdownL0(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
            cprmatrix4_2_log=log((1-Ph)/gamma_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_4)+log(msgdownL1(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
            cprmatrix4_3_log=log(Pl/epsilon_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_4)+log(msgdownL0(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));
            cprmatrix4_4_log=log(Ph/gamma_tilde)-z(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_4)+log(msgdownL1(lastrow(k)/2+1:lastcolumn(k)/2,1:lastrow(k)/2));

            msgdownL0_temp=cprmatrix1_2_log;
            msgdownL0_temp(cprmatrix1_1_log>=cprmatrix1_2_log)=cprmatrix1_1_log(cprmatrix1_1_log>=cprmatrix1_2_log);
            msgdownL1_temp=cprmatrix1_4_log;
            msgdownL1_temp(cprmatrix1_3_log>=cprmatrix1_4_log)=cprmatrix1_3_log(cprmatrix1_3_log>=cprmatrix1_4_log);
            msgdownL0(lastrow(k)+1:2:lastcolumn(k)-1,1:2:lastrow(k)-1)=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
            msgdownL1(lastrow(k)+1:2:lastcolumn(k)-1,1:2:lastrow(k)-1)=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
            msgdownL0_temp=cprmatrix2_2_log;
            msgdownL0_temp(cprmatrix2_1_log>=cprmatrix2_2_log)=cprmatrix2_1_log(cprmatrix2_1_log>=cprmatrix2_2_log);
            msgdownL1_temp=cprmatrix2_4_log;
            msgdownL1_temp(cprmatrix2_3_log>=cprmatrix2_4_log)=cprmatrix2_3_log(cprmatrix2_3_log>=cprmatrix2_4_log);
            msgdownL0(lastrow(k)+1:2:lastcolumn(k)-1,2:2:lastrow(k))=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
            msgdownL1(lastrow(k)+1:2:lastcolumn(k)-1,2:2:lastrow(k))=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
            msgdownL0_temp=cprmatrix3_2_log;
            msgdownL0_temp(cprmatrix3_1_log>=cprmatrix3_2_log)=cprmatrix3_1_log(cprmatrix3_1_log>=cprmatrix3_2_log);
            msgdownL1_temp=cprmatrix3_4_log;
            msgdownL1_temp(cprmatrix3_3_log>=cprmatrix3_4_log)=cprmatrix3_3_log(cprmatrix3_3_log>=cprmatrix3_4_log);
            msgdownL0(lastrow(k)+2:2:lastcolumn(k),1:2:lastrow(k)-1)=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
            msgdownL1(lastrow(k)+2:2:lastcolumn(k),1:2:lastrow(k)-1)=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
            msgdownL0_temp=cprmatrix4_2_log;
            msgdownL0_temp(cprmatrix4_1_log>=cprmatrix4_2_log)=cprmatrix4_1_log(cprmatrix4_1_log>=cprmatrix4_2_log);
            msgdownL1_temp=cprmatrix4_4_log;
            msgdownL1_temp(cprmatrix4_3_log>=cprmatrix4_4_log)=cprmatrix4_3_log(cprmatrix4_3_log>=cprmatrix4_4_log);
            msgdownL0(lastrow(k)+2:2:lastcolumn(k),2:2:lastrow(k))=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
            msgdownL1(lastrow(k)+2:2:lastcolumn(k),2:2:lastrow(k))=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);


            % diagonal part
            diag_shift(k)=my/(2^(L-k));
            
            childrenupL0_1=msgupL0(1+diag_shift(k):2:lastrow(k)-1+ diag_shift(k),lastrow(k)+2:2:lastcolumn(k)).*msgupL0(2+ diag_shift(k):2:lastrow(k)+ diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1).*...,
                           msgupL0(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+2:2:lastcolumn(k));   
            childrenupL0_2=msgupL0(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1).*msgupL0(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1).*...,
                           msgupL0(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+2:2:lastcolumn(k));  
            childrenupL0_3=msgupL0(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1).*msgupL0(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+2:2:lastcolumn(k)).*...,
                           msgupL0(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+2:2:lastcolumn(k)); 
            childrenupL0_4=msgupL0(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1).*msgupL0(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+2:2:lastcolumn(k)).*...,
                           msgupL0(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1); 
               
               
            childrenupL1_1=msgupL1(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+2:2:lastcolumn(k)).*msgupL1(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1).*...,
                           msgupL1(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+2:2:lastcolumn(k));
            childrenupL1_2=msgupL1(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1).*msgupL1(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1).*...,
                           msgupL1(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+2:2:lastcolumn(k)); 
            childrenupL1_3=msgupL1(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1).*msgupL1(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+2:2:lastcolumn(k)).*...,
                           msgupL1(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+2:2:lastcolumn(k));
            childrenupL1_4=msgupL1(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1).*msgupL1(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+2:2:lastcolumn(k)).*...,
                           msgupL1(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1); 
               
           
            cprmatrix1_1_log=log((1-Pl)/epsilon_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_1)+log(msgdownL0(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix1_2_log=log((1-Ph)/gamma_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_1)+log(msgdownL1(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix1_3_log=log(Pl/epsilon_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_1)+log(msgdownL0(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix1_4_log=log(Ph/gamma_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_1)+log(msgdownL1(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
        
            cprmatrix2_1_log=log((1-Pl)/epsilon_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_2)+log(msgdownL0(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix2_2_log=log((1-Ph)/gamma_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_2)+log(msgdownL1(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix2_3_log=log(Pl/epsilon_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_2)+log(msgdownL0(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix2_4_log=log(Ph/gamma_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_2)+log(msgdownL1(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
        
            cprmatrix3_1_log=log((1-Pl)/epsilon_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_3)+log(msgdownL0(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix3_2_log=log((1-Ph)/gamma_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_3)+log(msgdownL1(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix3_3_log=log(Pl/epsilon_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_3)+log(msgdownL0(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix3_4_log=log(Ph/gamma_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_3)+log(msgdownL1(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
        
            cprmatrix4_1_log=log((1-Pl)/epsilon_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_4)+log(msgdownL0(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix4_2_log=log((1-Ph)/gamma_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_4)+log(msgdownL1(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix4_3_log=log(Pl/epsilon_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+epsilon2))+log(childrenupL0_4)+log(msgdownL0(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));
            cprmatrix4_4_log=log(Ph/gamma_tilde)-z(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2).^2/(2*sigma2*(1+gamma2))+log(childrenupL1_4)+log(msgdownL1(1+diag_shift(k)/2:lastrow(k)/2+diag_shift(k)/2,lastrow(k)/2+1:lastcolumn(k)/2));

            
            msgdownL0_temp=cprmatrix1_2_log;
            msgdownL0_temp(cprmatrix1_1_log>=cprmatrix1_2_log)=cprmatrix1_1_log(cprmatrix1_1_log>=cprmatrix1_2_log);
            msgdownL1_temp=cprmatrix1_4_log;
            msgdownL1_temp(cprmatrix1_3_log>=cprmatrix1_4_log)=cprmatrix1_3_log(cprmatrix1_3_log>=cprmatrix1_4_log);
            msgdownL0(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1)=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
            msgdownL1(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1)=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
            msgdownL0_temp=cprmatrix2_2_log;
            msgdownL0_temp(cprmatrix2_1_log>=cprmatrix2_2_log)=cprmatrix2_1_log(cprmatrix2_1_log>=cprmatrix2_2_log);
            msgdownL1_temp=cprmatrix2_4_log;
            msgdownL1_temp(cprmatrix2_3_log>=cprmatrix2_4_log)=cprmatrix2_3_log(cprmatrix2_3_log>=cprmatrix2_4_log);
            msgdownL0(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+2:2:lastcolumn(k))=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
            msgdownL1(1+diag_shift(k):2:lastrow(k)-1+diag_shift(k),lastrow(k)+2:2:lastcolumn(k))=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
            msgdownL0_temp=cprmatrix3_2_log;
            msgdownL0_temp(cprmatrix3_1_log>=cprmatrix3_2_log)=cprmatrix3_1_log(cprmatrix3_1_log>=cprmatrix3_2_log);
            msgdownL1_temp=cprmatrix3_4_log;
            msgdownL1_temp(cprmatrix3_3_log>=cprmatrix3_4_log)=cprmatrix3_3_log(cprmatrix3_3_log>=cprmatrix3_4_log);
            msgdownL0(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1)=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
            msgdownL1(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+1:2:lastcolumn(k)-1)=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        
            msgdownL0_temp=cprmatrix4_2_log;
            msgdownL0_temp(cprmatrix4_1_log>=cprmatrix4_2_log)=cprmatrix4_1_log(cprmatrix4_1_log>=cprmatrix4_2_log);
            msgdownL1_temp=cprmatrix4_4_log;
            msgdownL1_temp(cprmatrix4_3_log>=cprmatrix4_4_log)=cprmatrix4_3_log(cprmatrix4_3_log>=cprmatrix4_4_log);
            msgdownL0(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+2:2:lastcolumn(k))=exp(msgdownL0_temp-msgdownL1_temp)./(exp(msgdownL0_temp-msgdownL1_temp)+1);
            msgdownL1(2+diag_shift(k):2:lastrow(k)+diag_shift(k),lastrow(k)+2:2:lastcolumn(k))=1./(exp(msgdownL0_temp-msgdownL1_temp)+1);
        end
        
      %%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% computation of beliefs
        
        % beliefs in the top level
        diagshift=my/2^(L-1);
        
        beliefL0_log(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1))=log((1-Proot)/epsilon_tilde)+log(msgupL0(1:2:my/2^(L-1)-1,mx/2^(L-1)+1:2:mx/2^(L-2)-1))+log(msgupL0(1:2:my/2^(L-1)-1,mx/2^(L-1)+2:2:mx/2^(L-2)))+...,
                                                       log(msgupL0(2:2:my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1))+log(msgupL0(2:2:my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2)))-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2));
        beliefL1_log(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1))=log(Proot/gamma_tilde)+log(msgupL1(1:2:my/2^(L-1)-1,mx/2^(L-1)+1:2:mx/2^(L-2)-1))+log(msgupL1(1:2:my/2^(L-1)-1,mx/2^(L-1)+2:2:mx/2^(L-2)))+...,
                                                       log(msgupL1(2:2:my/2^(L-1),mx/2^(L-1)+1:2:mx/2^(L-2)-1))+log(msgupL1(2:2:my/2^(L-1),mx/2^(L-1)+2:2:mx/2^(L-2)))-z(1:my/2^(L),mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2));

        beliefL0_log(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L))=log((1-Proot)/epsilon_tilde)+log(msgupL0(mx/2^(L-1)+1:2:mx/2^(L-2)-1,1:2:my/2^(L-1)-1))+log(msgupL0(mx/2^(L-1)+2:2:mx/2^(L-2),1:2:my/2^(L-1)-1))+...,
                                                       log(msgupL0(mx/2^(L-1)+1:2:mx/2^(L-2)-1,2:2:my/2^(L-1)))+log(msgupL0(mx/2^(L-1)+2:2:mx/2^(L-2),2:2:my/2^(L-1)))-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+epsilon2));
        beliefL1_log(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L))=log(Proot/gamma_tilde)+log(msgupL1(mx/2^(L-1)+1:2:mx/2^(L-2)-1,1:2:my/2^(L-1)-1))+log(msgupL1(mx/2^(L-1)+2:2:mx/2^(L-2),1:2:my/2^(L-1)-1))+...,
                                                       log(msgupL1(mx/2^(L-1)+1:2:mx/2^(L-2)-1,2:2:my/2^(L-1)))+log(msgupL1(mx/2^(L-1)+2:2:mx/2^(L-2),2:2:my/2^(L-1)))-z(mx/2^(L)+1:mx/2^(L-1),1:my/2^(L)).^2/(2*sigma2*(1+gamma2));
                                        
        beliefL0_log(1+diagshift/2:my/2^(L)+diagshift/2,mx/2^(L)+1:mx/2^(L-1))=log((1-Proot)/epsilon_tilde)+log(msgupL0(1+diagshift:2:my/2^(L-1)-1+diagshift,mx/2^(L-1)+1:2:mx/2^(L-2)-1))+log(msgupL0(1+diagshift:2:my/2^(L-1)-1+diagshift,mx/2^(L-1)+2:2:mx/2^(L-2)))+...,
                                                                               log(msgupL0(2+diagshift:2:my/2^(L-1)+diagshift,mx/2^(L-1)+1:2:mx/2^(L-2)-1))+log(msgupL0(2+diagshift:2:my/2^(L-1)+diagshift,mx/2^(L-1)+2:2:mx/2^(L-2)))-z(1+diagshift/2:my/2^(L)+diagshift/2,mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+epsilon2));                                                               
        beliefL1_log(1+diagshift/2:my/2^(L)+diagshift/2,mx/2^(L)+1:mx/2^(L-1))=log(Proot/gamma_tilde)+log(msgupL1(1+diagshift:2:my/2^(L-1)-1+diagshift,mx/2^(L-1)+1:2:mx/2^(L-2)-1))+log(msgupL1(1+diagshift:2:my/2^(L-1)-1+diagshift,mx/2^(L-1)+2:2:mx/2^(L-2)))+...,
                                                                               log(msgupL1(2+diagshift:2:my/2^(L-1)+diagshift,mx/2^(L-1)+1:2:mx/2^(L-2)-1))+log(msgupL1(2+diagshift:2:my/2^(L-1)+diagshift,mx/2^(L-1)+2:2:mx/2^(L-2)))-z(1+diagshift/2:my/2^(L)+diagshift/2,mx/2^(L)+1:mx/2^(L-1)).^2/(2*sigma2*(1+gamma2));
        
        % beliefs in the lowest level
        diagshift=my/2;
        
        beliefL0_log(1:my/2,mx/2+1:mx)=log(msgdownL0(1:my/2,mx/2+1:mx))-z(1:my/2,mx/2+1:mx).^2/(2*sigma2*(1+epsilon2))-log(epsilon_tilde);
        beliefL1_log(1:my/2,mx/2+1:mx)=log(msgdownL1(1:my/2,mx/2+1:mx))-z(1:my/2,mx/2+1:mx).^2/(2*sigma2*(1+gamma2))-log(gamma_tilde); 

        beliefL0_log(mx/2+1:mx,1:my/2)=log(msgdownL0(mx/2+1:mx,1:my/2))-z(mx/2+1:mx,1:my/2).^2/(2*sigma2*(1+epsilon2))-log(epsilon_tilde);
        beliefL1_log(mx/2+1:mx,1:my/2)=log(msgdownL1(mx/2+1:mx,1:my/2))-z(mx/2+1:mx,1:my/2).^2/(2*sigma2*(1+gamma2))-log(gamma_tilde); 

        beliefL0_log(1+diagshift:my/2+diagshift,mx/2+1:mx)=log(msgdownL0(1+diagshift:my/2+diagshift,mx/2+1:mx))-z(1+diagshift:my/2+diagshift,mx/2+1:mx).^2/(2*sigma2*(1+epsilon2))-log(epsilon_tilde);
        beliefL1_log(1+diagshift:my/2+diagshift,mx/2+1:mx)=log(msgdownL1(1+diagshift:my/2+diagshift,mx/2+1:mx))-z(1+diagshift:my/2+diagshift,mx/2+1:mx).^2/(2*sigma2*(1+gamma2))-log(gamma_tilde); 

        
        % beliefs in the remaining levels
        diag_shift_b=zeros(L-1,1);
        for k=2:(L-1)
            diag_shift_b(k)=my/2^(L+1-k);
                        
            beliefL0_log(1:my/2^(L+1-k),my/2^(L+1-k)+1:my/2^(L-k))=log(msgdownL0(1:my/2^(L+1-k),my/2^(L+1-k)+1:my/2^(L-k)))+log(msgupL0(2*(1:my/2^(L+1-k))-1,2*(my/2^(L+1-k)+1:my/2^(L-k))-1))+log(msgupL0(2*(1:my/2^(L+1-k))-1,2*(my/2^(L+1-k)+1:my/2^(L-k))))+...,
                                                                   log(msgupL0(2*(1:my/2^(L+1-k)),2*(my/2^(L+1-k)+1:my/2^(L-k))-1))+log(msgupL0(2*(1:my/2^(L+1-k)),2*(my/2^(L+1-k)+1:my/2^(L-k))))-z(1:my/2^(L+1-k),my/2^(L+1-k)+1:my/2^(L-k)).^2/(2*sigma2*(1+epsilon2))-log(epsilon_tilde);
            beliefL1_log(1:my/2^(L+1-k),my/2^(L+1-k)+1:my/2^(L-k))=log(msgdownL1(1:my/2^(L+1-k),my/2^(L+1-k)+1:my/2^(L-k)))+log(msgupL1(2*(1:my/2^(L+1-k))-1,2*(my/2^(L+1-k)+1:my/2^(L-k))-1))+log(msgupL1(2*(1:my/2^(L+1-k))-1,2*(my/2^(L+1-k)+1:my/2^(L-k))))+...,
                                                                   log(msgupL1(2*(1:my/2^(L+1-k)),2*(my/2^(L+1-k)+1:my/2^(L-k))-1))+log(msgupL1(2*(1:my/2^(L+1-k)),2*(my/2^(L+1-k)+1:my/2^(L-k))))-z(1:my/2^(L+1-k),my/2^(L+1-k)+1:my/2^(L-k)).^2/(2*sigma2*(1+gamma2))-log(gamma_tilde);
            
                                                               
            beliefL0_log(my/2^(L+1-k)+1:my/2^(L-k),1:my/2^(L+1-k))=log(msgdownL0(my/2^(L+1-k)+1:my/2^(L-k),1:my/2^(L+1-k)))+log(msgupL0(2*(my/2^(L+1-k)+1:my/2^(L-k))-1,2*(1:my/2^(L+1-k))-1))+log(msgupL0(2*(my/2^(L+1-k)+1:my/2^(L-k))-1,2*(1:my/2^(L+1-k))))+...,
                                                                   log(msgupL0(2*(my/2^(L+1-k)+1:my/2^(L-k)),2*(1:my/2^(L+1-k))-1))+log(msgupL0(2*(my/2^(L+1-k)+1:my/2^(L-k)),2*(1:my/2^(L+1-k))))-z(my/2^(L+1-k)+1:my/2^(L-k),1:my/2^(L+1-k)).^2/(2*sigma2*(1+epsilon2))-log(epsilon_tilde);
            beliefL1_log(my/2^(L+1-k)+1:my/2^(L-k),1:my/2^(L+1-k))=log(msgdownL1(my/2^(L+1-k)+1:my/2^(L-k),1:my/2^(L+1-k)))+log(msgupL1(2*(my/2^(L+1-k)+1:my/2^(L-k))-1,2*(1:my/2^(L+1-k))-1))+log(msgupL1(2*(my/2^(L+1-k)+1:my/2^(L-k))-1,2*(1:my/2^(L+1-k))))+...,
                                                                   log(msgupL1(2*(my/2^(L+1-k)+1:my/2^(L-k)),2*(1:my/2^(L+1-k))-1))+log(msgupL1(2*(my/2^(L+1-k)+1:my/2^(L-k)),2*(1:my/2^(L+1-k))))-z(my/2^(L+1-k)+1:my/2^(L-k),1:my/2^(L+1-k)).^2/(2*sigma2*(1+gamma2))-log(gamma_tilde);
                                               
            
            beliefL0_log(1+diag_shift_b(k):my/2^(L+1-k)+ diag_shift_b(k),my/2^(L+1-k)+1:my/2^(L-k))=log(msgdownL0((1:my/2^(L+1-k))+ diag_shift_b(k),my/2^(L+1-k)+1:my/2^(L-k)))+log(msgupL0((2*(1:my/2^(L+1-k))-1)+2*diag_shift_b(k),2*(my/2^(L+1-k)+1:my/2^(L-k))-1))+log(msgupL0((2*(1:my/2^(L+1-k))-1)+2*diag_shift_b(k),2*(my/2^(L+1-k)+1:my/2^(L-k))))+...,
                                                                                                    log(msgupL0(2*(1:my/2^(L+1-k))+2*diag_shift_b(k),2*(my/2^(L+1-k)+1:my/2^(L-k))-1))+log(msgupL0(2*(1:my/2^(L+1-k))+2*diag_shift_b(k),2*(my/2^(L+1-k)+1:my/2^(L-k))))-z((1:my/2^(L+1-k))+ diag_shift_b(k),my/2^(L+1-k)+1:my/2^(L-k)).^2/(2*sigma2*(1+epsilon2))-log(epsilon_tilde);
            beliefL1_log(1+diag_shift_b(k):my/2^(L+1-k)+ diag_shift_b(k),my/2^(L+1-k)+1:my/2^(L-k))=log(msgdownL1((1:my/2^(L+1-k))+ diag_shift_b(k),my/2^(L+1-k)+1:my/2^(L-k)))+log(msgupL1((2*(1:my/2^(L+1-k))-1)+2*diag_shift_b(k),2*(my/2^(L+1-k)+1:my/2^(L-k))-1))+log(msgupL1((2*(1:my/2^(L+1-k))-1)+2*diag_shift_b(k),2*(my/2^(L+1-k)+1:my/2^(L-k))))+...,
                                                                                                    log(msgupL1(2*(1:my/2^(L+1-k))+2*diag_shift_b(k),2*(my/2^(L+1-k)+1:my/2^(L-k))-1))+log(msgupL1(2*(1:my/2^(L+1-k))+2*diag_shift_b(k),2*(my/2^(L+1-k)+1:my/2^(L-k))))-z((1:my/2^(L+1-k))+ diag_shift_b(k),my/2^(L+1-k)+1:my/2^(L-k)).^2/(2*sigma2*(1+gamma2))-log(gamma_tilde);
                                                                                                                                                                                      
                                                                                    
        end
             
                        
        beliefL0=exp(beliefL0_log-beliefL1_log)./(1+exp(beliefL0_log-beliefL1_log));
        beliefL1=1./(1+exp(beliefL0_log-beliefL1_log));
        
        s_hat(beliefL1>=beliefL0)=z(beliefL1>=beliefL0)*gamma2/(1+gamma2);
        q_hat(beliefL1>=beliefL0)=1;

        stDinvs=sum(s_hat(beliefL1>=beliefL0).^2)/gamma2 + sum(s_hat(beliefL1<beliefL0).^2)/epsilon2;
        
        % compute the number of state variable pairs in Markov tree 
        q_pairs=numpair(q_hat,L); 
        q_rooth=q_pairs(1);
        q_rootl=q_pairs(2);
        q_hh=q_pairs(3);
        q_lh=q_pairs(4);
        q_hl=q_pairs(5);
        q_ll=q_pairs(6);
        
        if Proot==1
            logPq=q_hh*log(Ph)+q_hl*log(1-Ph)+q_lh*log(Pl)+q_ll*log(1-Pl);
        else
            logPq=q_rooth*log(Proot)+q_rootl*log(1-Proot)+q_hh*log(Ph)+q_hl*log(1-Ph)+q_lh*log(Pl)+q_ll*log(1-Pl);
        end
        
        if (paras.projonimage)
            s_hat=wave_mat2vec(s_hat,signature);
            q_hat=wave_mat2vec(q_hat,signature);
        else
            s_hat=s_hat(:);
            q_hat=q_hat(:);
        end

               
        Hs_hat=H(s_hat);
        r_q=sum(q_hat);
                
        
        residual2=(y-Hs_hat)'*(y-Hs_hat);
        
        posterior_qsgiveny(p2)=-0.5*residual2/sigma2-0.5*stDinvs/sigma2+logPq-0.5*r_q*log(gamma2)-0.5*(p-r_q)*log(epsilon2); 
        gap=norm(s_hat-s_hat_pre)^2/p;
        s_hat_pre=s_hat;
        
        if gap < threshold || p2==max_iter_inner
           exit_flag2=1;
        end
           
        if rem(p2,50)==0 && paras.visibility
              clc;
              display(['p1=',num2str(p1),'_p2=',num2str(p2),'_sparsity=',num2str(r_q),'_residual=',num2str(gap),'_sigma2=',num2str(sigma2)]);
        end
    
    end
        
    object_prob(p1)=posterior_qsgiveny(p2); 
    count=count+p2;
    sparsity(p1)=r_q; 
    logP(p1)=-0.5*(N+p)*log((residual2+stDinvs)./(N+p))-0.5*r_q*log(gamma2)-0.5*(p-r_q)*log(epsilon2)+logPq;

    sigma2=sigma2/d;
    sigma2_out(p1+1)=sigma2;
    
    if isfield(paras,'strue')
        error(p1)=norm(s_hat-s_true)^2/p;
    end
    
    clear posterior_qsgiveny
       
    if p1==max_iter_sigma2 
        exit_flag1=1;
    end
   
    if p1==1
       s_hat_out=s_hat;
       q_hat_out=q_hat;
       p3=0;
    else
             if logP(p1-p3)<logP(p1)
                 s_hat_out=s_hat;
                 q_hat_out=q_hat;
                 p3=0;
             end    
    end
end

sigma2_out=sigma2_out(1:max_iter_sigma2);

end
