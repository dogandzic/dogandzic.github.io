%%%% Simulated Small-scale Signal Example %%%%
% 
% Coded by Zhao Song, ECpE, ISU
% Email: zhaosong@iastate.edu
% Last modified on: Aug. 4th, 2013


clear all;
close all; 
clc;

path(path,'./utils/');
path(path,'./hmt/');
path(path,'./turbo/');
path(path, './subfunctions');
path(path,'./Algorithms');
addpath(genpath(fullfile(pwd,'./Algorithms/FPC_AS')));

Nratio=0.4;         % N/p

thresh=1e-10;       % convergence threshold for hard thresholding methods 
num_MC=500;         % number of MCMC
covc=0.2;
correlation_row=1;  % 1/0 rows/columns correlated

%%%%%%%%%%%%%%%%%%%%% Generate the simulated signal
numLevels=4;                  % tree depth
p=1024;                       % length of signal
my=sqrt(p);
mx=sqrt(p);
q_pattern=zeros(my);
alength=my/(2^numLevels); 

% parameters for HMT
Proot=0.5;
Ph=0.5;
Pl=1e-4;
gamma2=1e4;
epsilon2=1e0;
sigma2=1e-6;
    
TotalSparsity=EmpSparsity(Proot, Pl);
sigmaTurbo=sqrt((TotalSparsity*gamma2*sigma2+(p-TotalSparsity)*epsilon2*sigma2)/p);
    
Nerror_tAMP=zeros(num_MC,1);
Nerror_mpem=zeros(num_MC,1);
Nerror_mpem_opt=zeros(num_MC,1);
Nerror_fpc_as1=zeros(num_MC,1);
Nerror_fpc_as2=zeros(num_MC,1);
Nerror_fpc_as3=zeros(num_MC,1);
Nerror_fpc_as4=zeros(num_MC,1);
Nerror_fpc_as5=zeros(num_MC,1);
Nerror_fpc_as6=zeros(num_MC,1);
Nerror_fpc_as7=zeros(num_MC,1);
Nerror_fpc_as8=zeros(num_MC,1);
Nerror_fpc_as9=zeros(num_MC,1);
Nerror_GPSR1=zeros(num_MC,1);
Nerror_GPSR2=zeros(num_MC,1);
Nerror_GPSR3=zeros(num_MC,1);
Nerror_GPSR4=zeros(num_MC,1);
Nerror_GPSR5=zeros(num_MC,1);
Nerror_GPSR6=zeros(num_MC,1);
Nerror_GPSR7=zeros(num_MC,1);
Nerror_GPSR8=zeros(num_MC,1);
Nerror_GPSR9=zeros(num_MC,1);
Nerror_GPSRdb1=zeros(num_MC,1);
Nerror_GPSRdb2=zeros(num_MC,1);
Nerror_GPSRdb3=zeros(num_MC,1);
Nerror_GPSRdb4=zeros(num_MC,1);
Nerror_GPSRdb5=zeros(num_MC,1);
Nerror_GPSRdb6=zeros(num_MC,1);
Nerror_GPSRdb7=zeros(num_MC,1);
Nerror_GPSRdb8=zeros(num_MC,1);
Nerror_GPSRdb9=zeros(num_MC,1);
Nerror_IHT_tree=zeros(num_MC,1);
Nerror_NIHT=zeros(num_MC,1);
Nerror_vb=zeros(num_MC,1);
Nerror_vb2=zeros(num_MC,1);

t_tAMP=zeros(num_MC,1);
t_mpem=zeros(num_MC,1);
t_fpc_as1=zeros(num_MC,1);
t_fpc_as2=zeros(num_MC,1);
t_fpc_as3=zeros(num_MC,1);
t_fpc_as4=zeros(num_MC,1);
t_fpc_as5=zeros(num_MC,1);
t_fpc_as6=zeros(num_MC,1);
t_fpc_as7=zeros(num_MC,1);
t_fpc_as8=zeros(num_MC,1);
t_fpc_as9=zeros(num_MC,1);
t_GPSR1=zeros(num_MC,1);
t_GPSR2=zeros(num_MC,1);
t_GPSR3=zeros(num_MC,1);
t_GPSR4=zeros(num_MC,1);
t_GPSR5=zeros(num_MC,1);
t_GPSR6=zeros(num_MC,1);
t_GPSR7=zeros(num_MC,1);
t_GPSR8=zeros(num_MC,1);
t_GPSR9=zeros(num_MC,1);
t_IHT_tree=zeros(num_MC,1);
t_DORE=zeros(num_MC,1);
t_NIHT=zeros(num_MC,1);
t_vb=zeros(num_MC,1);
t_vb2=zeros(num_MC,1);

sparsity=zeros(num_MC,1);

for ii=1:num_MC
    %%%%%%%%%%%%%%%%%%%%% Generate the simulated signal

    q_pattern=zeros(my);
    wavecoeff=sqrt(epsilon2*sigma2)*randn(my); 
    s=wavecoeff(:); 
    
    % generate the pattern for indicators q
    q_pattern(1:alength,1:alength)=1;
    q_pattern(1:alength,alength+1:2*alength)=binornd(1,Proot*ones(alength));
    q_pattern(alength+1:2*alength,1:alength)=binornd(1,Proot*ones(alength));
    q_pattern(alength+1:2*alength,alength+1:2*alength)=binornd(1,Proot*ones(alength));

    prob_matrix=zeros(my); % define the probability matrix of q=1 for each position
    for i=1:numLevels-1      
        % horizontal part 
        rlength=my/2^(numLevels+1-i);
        prob_temp=Pl*ones(rlength);
        prob_temp(q_pattern(1:rlength,rlength+1:2*rlength)==1)=Ph;
        prob_matrix(1:2:2*rlength-1,2*rlength+1:2:4*rlength-1)=prob_temp;
        prob_matrix(1:2:2*rlength-1,2*rlength+2:2:4*rlength)=prob_temp;
        prob_matrix(2:2:2*rlength,2*rlength+1:2:4*rlength-1)=prob_temp;
        prob_matrix(2:2:2*rlength,2*rlength+2:2:4*rlength)=prob_temp;
        q_pattern(1:2*rlength,2*rlength+1:4*rlength)=binornd(1,prob_matrix(1:2*rlength,2*rlength+1:4*rlength));
    
        % vertical part 
        prob_temp=Pl*ones(rlength);
        prob_temp(q_pattern(rlength+1:2*rlength,1:rlength)==1)=Ph;
        prob_matrix(2*rlength+1:2:4*rlength-1,1:2:2*rlength-1)=prob_temp;
        prob_matrix(2*rlength+2:2:4*rlength,1:2:2*rlength-1)=prob_temp;
        prob_matrix(2*rlength+1:2:4*rlength-1,2:2:2*rlength)=prob_temp;
        prob_matrix(2*rlength+2:2:4*rlength,2:2:2*rlength)=prob_temp;
        q_pattern(2*rlength+1:4*rlength,1:2*rlength)=binornd(1,prob_matrix(2*rlength+1:4*rlength,1:2*rlength));
    
        % diagonal part 
        prob_temp=Pl*ones(rlength);
        prob_temp(q_pattern(1+rlength:2*rlength,rlength+1:2*rlength)==1)=Ph;
        prob_matrix(1+2*rlength:2:4*rlength-1,2*rlength+1:2:4*rlength-1)=prob_temp;
        prob_matrix(1+2*rlength:2:4*rlength-1,2*rlength+2:2:4*rlength)=prob_temp;
        prob_matrix(2+2*rlength:2:4*rlength,2*rlength+1:2:4*rlength-1)=prob_temp;
        prob_matrix(2+2*rlength:2:4*rlength,2*rlength+2:2:4*rlength)=prob_temp;
        q_pattern(1+2*rlength:4*rlength,2*rlength+1:4*rlength)=binornd(1,prob_matrix(1+2*rlength:4*rlength,2*rlength+1:4*rlength));
    end

    q_temp=q_pattern(:);
    sparsity(ii)=sum(q_temp);
    s(q_temp==1)=sqrt(gamma2*sigma2)*randn(sparsity(ii),1); % simulated signal coefficients;

    Imgtemp=randn(my);
    [ctemp,signature]=wavedec2(Imgtemp,numLevels,'db1'); % generate 'signature'
    
    [IdxParent, IdxChildren, Ms]=WaveRelation2D(ctemp, signature);
    
    N=round(p*Nratio);             % number of measurements 
        
    if correlation_row==1
        Phi0=randn(N,p);
        cov=covc.^(toeplitz([0:N-1]));
        Phi0=(chol(cov))'*Phi0;        
    else
        PhiT=randn(p,N);
        cov=covc.^(toeplitz([0:p-1]));
        PhiT=(chol(cov))'*PhiT;
        Phi0=PhiT';
    end

    
    rho_H=max(svds(Phi0));         % maximum of singular values for sampling matrix
    Phi=Phi0/rho_H;                % we plan to add aribitary rho_Phi in the future
    Phit=Phi';
    projonimage=0;

    H=@(z) Phi*z;
    Ht=@(z) Phit*z;
    HHtInv=inv(Phi*Phit);

    % Take the measurement
    y=Phi*s;
    w=sqrt(sigma2)*randn(N,1);
    y=y+w;    

    s_temp=reshape(s, my, mx);
    s_temp=wave_mat2vec(s_temp, signature);    
    y_temp=Phi*s_temp+w;
     
    %%%%%%%%%%%%%%%%%%%%% Solve by TSWCSvb
    display('Now VB');
    tic;
    s_vb = TSWCSvb_mod(Phi, y_temp, Ms, IdxParent', IdxChildren');
    t_vb(ii) = toc;
    s_vb = s_vb(:);
    Nerror_vb(ii)= norm(s_vb-s_temp)^2/norm(s_temp)^2;
    
    tic;
    s_vb2 = TSWCSvb(Phi, y_temp, Ms, IdxParent', IdxChildren');
    t_vb2(ii) = toc;
    s_vb2 = s_vb2(:);
    Nerror_vb2(ii)= norm(s_vb2-s_temp)^2/norm(s_temp)^2;

    %%%%%%%%%%%%%%%%%%%%% Solve by turbo-AMP 
    
    
    %%% settings for turbo AMP algorithm
    params = getConfigTurboAMP();
    params.projOnImage=0;  % 0: proj on wavelet trandsform, 1: proj on image
    
    params.numLevels=numLevels;
    params.s=signature;
    
    xRange=6*sigmaTurbo;
        
    A=Phi;
    % matrix form - default model parameters
    tic
    [x_hat, s_hat]=turboAMP(y,A,[],params,xRange);
    t_tAMP(ii)=toc;
    Nerror_tAMP(ii)=norm(x_hat(:)-s)^2/norm(s)^2;
    clear params modelParams f
% 
%     %%%%%%%%%%%%%%%%%%%%% Solve by MP-EM
% 
%     
    paras.Ph=0.2;
    paras.Pl=1e-5;
    paras.Proot=0.2;
    paras.gamma2=1e3;
    paras.epsilon2=1e-1;
    paras.signature=signature;
    paras.threshold=thresh;
    paras.projonimage=0;
    paras.visibility=0;
    paras.strue=s;
    paras.gridlength=16;
    paras.d=2;
    
    display('Now MP-EM');
    tic;
    [s_hat_mpem,q_hat_mpem,posterior_mpem,object_prob_mpem,Count_mpem(ii),sigma2_mpem,sparsity_mpem,error]=MPEM(y,H,Ht,numLevels,paras);
    t_mpem(ii)=toc;
    Nerror_mpem(ii)=norm(s_hat_mpem(:)-s)^2/norm(s)^2;
    Nerror_mpem_opt(ii)=min(error)*p/norm(s)^2;

    
% 
%     %%%%%%%%%%%%%%%%%%%%% Solve by FPC_AS
% 
    display('Now FPCAS');
    M=[];
    opts.record=-1;  
    
    mu_as1=1e-1*max(abs(Ht(y)));
    tic
    [s_fpc_as1,fpc_as_out1]=FPC_AS(p,Phi,y,mu_as1,M,opts);
    t_fpc_as1(ii)=toc;
    Nerror_fpc_as1(ii)=norm(s_fpc_as1(:)-s)^2/norm(s)^2;
 
    mu_as2=1e-2*max(abs(Ht(y)));
    tic
    [s_fpc_as2,fpc_as_out2]=FPC_AS(p,Phi,y,mu_as2,M,opts);
    t_fpc_as2(ii)=toc;
    Nerror_fpc_as2(ii)=norm(s_fpc_as2(:)-s)^2/norm(s)^2;
    
    mu_as3=1e-3*max(abs(Ht(y)));
    tic
    [s_fpc_as3,fpc_as_out3]=FPC_AS(p,Phi,y,mu_as3,M,opts);
    t_fpc_as3(ii)=toc;
    Nerror_fpc_as3(ii)=norm(s_fpc_as3(:)-s)^2/norm(s)^2;
 
    mu_as4=1e-4*max(abs(Ht(y)));
    tic
    [s_fpc_as4,fpc_as_out4]=FPC_AS(p,Phi,y,mu_as4,M,opts);
    t_fpc_as4(ii)=toc;
    Nerror_fpc_as4(ii)=norm(s_fpc_as4(:)-s)^2/norm(s)^2;

    mu_as5=1e-5*max(abs(Ht(y)));
    tic
    [s_fpc_as5,fpc_as_out5]=FPC_AS(p,Phi,y,mu_as5,M,opts);
    t_fpc_as5(ii)=toc;
    Nerror_fpc_as5(ii)=norm(s_fpc_as5(:)-s)^2/norm(s)^2;
 
    mu_as6=1e-6*max(abs(Ht(y)));
    tic
    [s_fpc_as6,fpc_as_out6]=FPC_AS(p,Phi,y,mu_as6,M,opts);
    t_fpc_as6(ii)=toc;
    Nerror_fpc_as6(ii)=norm(s_fpc_as6(:)-s)^2/norm(s)^2;
 
    mu_as7=1e-7*max(abs(Ht(y)));
    tic
    [s_fpc_as7,fpc_as_out7]=FPC_AS(p,Phi,y,mu_as7,M,opts);
    t_fpc_as7(ii)=toc;
    Nerror_fpc_as7(ii)=norm(s_fpc_as7(:)-s)^2/norm(s)^2;
 
    mu_as8=1e-8*max(abs(Ht(y)));
    tic
    [s_fpc_as8,fpc_as_out8]=FPC_AS(p,Phi,y,mu_as8,M,opts);
    t_fpc_as8(ii)=toc;
    Nerror_fpc_as8(ii)=norm(s_fpc_as8(:)-s)^2/norm(s)^2;
 
    mu_as9=1e-9*max(abs(Ht(y)));
    tic
    [s_fpc_as9,fpc_as_out9]=FPC_AS(p,Phi,y,mu_as9,M,opts);
    t_fpc_as9(ii)=toc;
    Nerror_fpc_as9(ii)=norm(s_fpc_as9(:)-s)^2/norm(s)^2;


    %%%%%%%%%%%%%%%%%%%%% Solve by GPSR_BB

    display('Now GPSR');
 
    tau1=1e-1*max(abs(Ht(y)));
    tic;
    [s_GPSR1,s_GPSRdb1,objective1,times1,debias_start1,mses1]=GPSR_BB(y,Phi,tau1,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
    t_GPSR1(ii)=toc;
    Nerror_GPSR1(ii)=norm(s_GPSR1(:)-s)^2/norm(s)^2;
    if isempty(s_GPSRdb1)
        s_GPSRdb1=s_GPSR1;
    end
    Nerror_GPSRdb1(ii)=norm(s_GPSRdb1(:)-s)^2/norm(s)^2;
 
    tau2=1e-2*max(abs(Ht(y)));
    tic;
    [s_GPSR2,s_GPSRdb2,objective2,times2,debias_start2,mses2]=GPSR_BB(y,Phi,tau2,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
    t_GPSR2(ii)=toc;
    Nerror_GPSR2(ii)=norm(s_GPSR2(:)-s)^2/norm(s)^2;
    if isempty(s_GPSRdb2)
        s_GPSRdb2=s_GPSR2;
    end
    Nerror_GPSRdb2(ii)=norm(s_GPSRdb2(:)-s)^2/norm(s)^2;
    
    tau3=1e-3*max(abs(Ht(y)));
    tic;
    [s_GPSR3,s_GPSRdb3,objective3,times3,debias_start3,mses3]=GPSR_BB(y,Phi,tau3,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
    t_GPSR3(ii)=toc;
    Nerror_GPSR3(ii)=norm(s_GPSR3(:)-s)^2/norm(s)^2;
    if isempty(s_GPSRdb3)
        s_GPSRdb3=s_GPSR3;
    end
    Nerror_GPSRdb3(ii)=norm(s_GPSRdb3(:)-s)^2/norm(s)^2;
 
    tau4=1e-4*max(abs(Ht(y)));
    tic;
    [s_GPSR4,s_GPSRdb4,objective4,times4,debias_start4,mses4]=GPSR_BB(y,Phi,tau4,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
    t_GPSR4(ii)=toc;
    Nerror_GPSR4(ii)=norm(s_GPSR4(:)-s)^2/norm(s)^2;
    if isempty(s_GPSRdb4)
        s_GPSRdb4=s_GPSR4;
    end
    Nerror_GPSRdb4(ii)=norm(s_GPSRdb4(:)-s)^2/norm(s)^2;
    
    tau5=1e-5*max(abs(Ht(y)));
    tic;
    [s_GPSR5,s_GPSRdb5,objective5,times5,debias_start5,mses5]=GPSR_BB(y,Phi,tau5,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
    t_GPSR5(ii)=toc;
    Nerror_GPSR5(ii)=norm(s_GPSR5(:)-s)^2/norm(s)^2;
    if isempty(s_GPSRdb5)
        s_GPSRdb5=s_GPSR5;
    end
    Nerror_GPSRdb5(ii)=norm(s_GPSRdb5(:)-s)^2/norm(s)^2;
 
    tau6=1e-6*max(abs(Ht(y)));
    tic;
    [s_GPSR6,s_GPSRdb6,objective6,times6,debias_start6,mses6]=GPSR_BB(y,Phi,tau6,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
    t_GPSR6(ii)=toc;
    Nerror_GPSR6(ii)=norm(s_GPSR6(:)-s)^2/norm(s)^2;
    if isempty(s_GPSRdb6)
        s_GPSRdb6=s_GPSR6;
    end
    Nerror_GPSRdb6(ii)=norm(s_GPSRdb6(:)-s)^2/norm(s)^2;
 
    tau7=1e-7*max(abs(Ht(y)));
    tic;
    [s_GPSR7,s_GPSRdb7,objective7,times7,debias_start7,mses7]=GPSR_BB(y,Phi,tau7,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
    t_GPSR7(ii)=toc;
    Nerror_GPSR7(ii)=norm(s_GPSR7(:)-s)^2/norm(s)^2;
    if isempty(s_GPSRdb7)
        s_GPSRdb7=s_GPSR7;
    end
    Nerror_GPSRdb7(ii)=norm(s_GPSRdb7(:)-s)^2/norm(s)^2;
 
    tau8=1e-8*max(abs(Ht(y)));
    tic;
    [s_GPSR8,s_GPSRdb8,objective8,times8,debias_start8,mses8]=GPSR_BB(y,Phi,tau8,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
    t_GPSR8(ii)=toc;
    Nerror_GPSR8(ii)=norm(s_GPSR8(:)-s)^2/norm(s)^2;
    if isempty(s_GPSRdb8)
        s_GPSRdb8=s_GPSR8;
    end
    Nerror_GPSRdb8(ii)=norm(s_GPSRdb8(:)-s)^2/norm(s)^2;

    tau9=1e-9*max(abs(Ht(y)));
    tic;
    [s_GPSR9,s_GPSRdb9,objective9,times9,debias_start9,mses9]=GPSR_BB(y,Phi,tau9,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
    t_GPSR9(ii)=toc;
    Nerror_GPSR9(ii)=norm(s_GPSR9(:)-s)^2/norm(s)^2;
    if isempty(s_GPSRdb9)
        s_GPSRdb9=s_GPSR9;
    end
    Nerror_GPSRdb9(ii)=norm(s_GPSRdb9(:)-s)^2/norm(s)^2;


    %%%%%%%%%%%%%%%%%%%%% Solve by NIHT
    
    display('Now NIHT');

    tic;
    [s_NIHT,Count_NIHT(ii)]=hard_l0_Mterm_mod(y,Phi,p,sparsity(ii),thresh);
    t_NIHT(ii)=toc;
    Nerror_NIHT(ii)=norm(s_NIHT(:)-s)^2/norm(s)^2;

    
    %%%%%%%%%%%%%%%%%%%%% Solve by MB-IHT

    display('Now MB-IHT');

    tic;
    [s_IHT_tree,Count_IHT_tree(ii)]=IHT_tree(y,Phi,p,sparsity(ii),thresh,numLevels,signature,projonimage,'step_size',1);
    t_IHT_tree(ii)=toc;
    Nerror_IHT_tree(ii)=norm(s_IHT_tree(:)-s)^2/norm(s)^2;

    if rem(ii,20)==0
        clc;
        display(['iter = ', num2str(ii)]);
    end

end

clear Phi Phit Phi0 Phi0t H Ht A f


nmse_tAMP=mean(Nerror_tAMP);
nmse_mpem=mean(Nerror_mpem);
nmse_mpem_opt=mean(Nerror_mpem_opt);
nmse_GPSR1=mean(Nerror_GPSR1);
nmse_GPSR2=mean(Nerror_GPSR2);
nmse_GPSR3=mean(Nerror_GPSR3);
nmse_GPSR4=mean(Nerror_GPSR4);
nmse_GPSR5=mean(Nerror_GPSR5);
nmse_GPSR6=mean(Nerror_GPSR6);
nmse_GPSR7=mean(Nerror_GPSR7);
nmse_GPSR8=mean(Nerror_GPSR8);
nmse_GPSR9=mean(Nerror_GPSR9);
nmse_GPSRdb1=mean(Nerror_GPSRdb1);
nmse_GPSRdb2=mean(Nerror_GPSRdb2);
nmse_GPSRdb3=mean(Nerror_GPSRdb3);
nmse_GPSRdb4=mean(Nerror_GPSRdb4);
nmse_GPSRdb5=mean(Nerror_GPSRdb5);
nmse_GPSRdb6=mean(Nerror_GPSRdb6);
nmse_GPSRdb7=mean(Nerror_GPSRdb7);
nmse_GPSRdb8=mean(Nerror_GPSRdb8);
nmse_GPSRdb9=mean(Nerror_GPSRdb9);
nmse_fpc_as1=mean(Nerror_fpc_as1);
nmse_fpc_as2=mean(Nerror_fpc_as2);
nmse_fpc_as3=mean(Nerror_fpc_as3);
nmse_fpc_as4=mean(Nerror_fpc_as4);
nmse_fpc_as5=mean(Nerror_fpc_as5);
nmse_fpc_as6=mean(Nerror_fpc_as6);
nmse_fpc_as7=mean(Nerror_fpc_as7);
nmse_fpc_as8=mean(Nerror_fpc_as8);
nmse_fpc_as9=mean(Nerror_fpc_as9);
nmse_NIHT=mean(Nerror_NIHT);
nmse_IHT_tree=mean(Nerror_IHT_tree);
nmse_vb=mean(Nerror_vb);
nmse_vb2=mean(Nerror_vb2);

save(['MCMC_',num2str(num_MC),'signal_length_',num2str(p),'_Level_',num2str(numLevels),'_thresh_',num2str(thresh),'_sigma2_',num2str(sigma2),'_epsilon2_',num2str(epsilon2),'_gamma2_',num2str(gamma2),'_Nratio_',num2str(Nratio),'_Covariance_',num2str(covc),'.mat']);
