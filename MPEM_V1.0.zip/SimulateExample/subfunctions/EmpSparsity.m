function TotalSparsity=EmpSparsity(Proot, Pl)

p=32^2;
L=4;

% Proot=0.6;
% 
Ph=Proot;
% 
% Pl=1e-4;




Sparsity=zeros(L+1,1);

Plevel=zeros(L+1,1);

Sparsity(1)=(sqrt(p)/2^L)^2;
 
Plevel(1)=Proot;




for i=1:L

     Plevel(i+1)=Plevel(i)*Ph+(1-Plevel(i))*Pl;

     Sparsity(i+1)=(sqrt(p)/2^(L-i+1))^2*3*Plevel(i);

end




TotalSparsity=sum(Sparsity);
% SparsityRatio=TotalSparsity/p;

end