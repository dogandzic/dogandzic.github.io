%%%% Compressive Sensing 2-D Image Example %%%%
% 
% Coded by Zhao Song, ECpE, ISU
% Email: zhaosong@iastate.edu
% Last modified on: Aug. 4th, 2013


clear all;
close all; 
clc;


Nratio=0.35;  % N/p
thresh=1e-1;  % convergence threshold for hard thresholding methods   
    
path(path,'./utils/');
path(path,'./hmt/');
path(path,'./turbo/');
path(path, './subfunctions');
path(path,'./Algorithms');
addpath(genpath(fullfile(pwd,'./Algorithms/FPC_AS')));

%%% read image file %%% 
img_name='cameraman';
X=imread('cameraman.tif');
X=double(X);
Img2D=X;
[my,mx]=size(Img2D);
scale=max(Img2D(:))-min(Img2D(:));
Img2Dbar=mean(Img2D(:));
Xcntr=Img2D-Img2Dbar;
X=Xcntr;
dim=size(Img2D);       % dimension of the image
p=prod(dim);           % total number of pixels
projonimage=1;

SNRdB_true=Inf;        % SNR  in dB 
numLevels=4;           % wavelet tree depth 

%%% settings for turbo AMP algorithm

params = getConfigTurboAMP();
params.projOnImage=1;  % 0: proj on wavelet trandsform, 1: proj on image

%%% wavelet trandform of the image %%%
[waveC, signature]=wavedec2(X,numLevels,'db1');
iW=wave_vec2mat(waveC,signature);
params.numLevels=numLevels;
params.s=signature;

if(params.projOnImage) 
    x_true=X(:);
else
    x_true=iW(:);
end

N=round(Nratio*p);     % Number of measurements 


% Sampling operator using Structurally Random Matrices
Ifull=1:p;
Phi=@(z) sro(1, z, Ifull, N, p, my, mx, '2DDCT', [], [], [], 'RS');
Phit=@(z) sro(2, z, Ifull, N, p, my, mx, '2DDCT', [], [], [], 'RS');

H=@(z) H_idwt2d(Phi,z,signature);          % sensing operator
Ht=@(z) Ht_dwt2d(Phit,z,numLevels,my,mx);

W=@(z) waverec2(z,signature,'db1');
Wt=@(z) wavedec2(z,dwt_L,'db1');

% Take the measurement
y = Phi(x_true);

sig2w_true=norm(y)^2/N*10^(-SNRdB_true/10);     
w=sqrt(sig2w_true)*randn(N,1);
y=y+w;


%%%%%%%%%%%%%%%%%%%%% Solve by turbo-AMP with FunctionHandle version

xRange=255; 

tic
[x_hat, s_hat]=turboAMP(y,Phi,Phit,params,xRange);
t_turboAMP=toc;
Img_tAMP=reshape(x_hat,my,mx);
Img_tAMP=Img_tAMP+Img2Dbar;
PSNR_tAMP=psnr(Img2D,Img_tAMP,scale);
Nerror_tAMP=(norm(Img2D(:)-Img_tAMP(:)))^2/(norm(Img2D(:)))^2;

clear params f

%%%%%%%%%%%%%%%%%%%%% Solve by MP-EM

Img2Dparas.W=W;
Img2Dparas.scale=scale;
Img2Dparas.bar=Img2Dbar;
Img2Dparas.img=Img2D;
Img2Dparas.signature=signature;

% Parameters used in MP-EM
paras.Ph=0.2;
paras.Pl=1e-5;
paras.Proot=0.2;
paras.gamma2=1000;
paras.epsilon2=0.1;
paras.signature=signature;
paras.threshold=thresh;
paras.projonimage=1;
paras.visibility=0;
paras.gridlength=12;
paras.d=2;

tic;
[s_hat_mpem,q_hat_mpem,posterior_mpem,object_prob_mpem,Count_mpem,sigma2_mpem,sparsity_mpem,error_mpem, PSNRs, Errors]=MPEM(y,H,Ht,numLevels,paras,Img2Dparas);
t_mpem=toc;
Img2D_mpem=W(s_hat_mpem);
Img2D_mpem=Img2D_mpem+Img2Dbar;
PSNR_mpem=psnr(Img2D,Img2D_mpem,scale);
PSNR_mpem_opt=max(PSNRs);
Nerror_mpem=(norm(Img2D(:)-Img2D_mpem(:)))^2/(norm(Img2D(:)))^2;
Nerror_mpem_opt=min(Errors);


%%%%%%%%%%%%%%%%%%%%% Solve by FPC_AS
M=[];
opts.record=-1;
A=A_operator(@(z) H_idwt2d(Phi,z,signature),@(z) Ht_dwt2d(Phit,z,numLevels,my,mx));

mu_as1=1e-1*max(abs(Ht(y)));
tic
[s_fpc_as1,fpc_as_out1]=FPC_AS(p,A,y,mu_as1,M,opts);
t_fpc_as1=toc;
Img2D_fpc_as1=W(s_fpc_as1);
Img2D_fpc_as1=Img2D_fpc_as1+Img2Dbar;
PSNR_fpc_as1=psnr(Img2D,Img2D_fpc_as1,scale);
Nerror_fpc_as1=(norm(Img2D(:)-Img2D_fpc_as1(:)))^2/(norm(Img2D(:)))^2;

mu_as2=1e-2*max(abs(Ht(y)));
tic
[s_fpc_as2,fpc_as_out2]=FPC_AS(p,A,y,mu_as2,M,opts);
t_fpc_as2=toc;
Img2D_fpc_as2=W(s_fpc_as2);
Img2D_fpc_as2=Img2D_fpc_as2+Img2Dbar;
PSNR_fpc_as2=psnr(Img2D,Img2D_fpc_as2,scale);
Nerror_fpc_as2=(norm(Img2D(:)-Img2D_fpc_as2(:)))^2/(norm(Img2D(:)))^2;

mu_as3=1e-3*max(abs(Ht(y)));
tic
[s_fpc_as3,fpc_as_out3]=FPC_AS(p,A,y,mu_as3,M,opts);
t_fpc_as3=toc;
Img2D_fpc_as3=W(s_fpc_as3);
Img2D_fpc_as3=Img2D_fpc_as3+Img2Dbar;
PSNR_fpc_as3=psnr(Img2D,Img2D_fpc_as3,scale);
Nerror_fpc_as3=(norm(Img2D(:)-Img2D_fpc_as3(:)))^2/(norm(Img2D(:)))^2;


mu_as4=1e-4*max(abs(Ht(y)));
tic
[s_fpc_as4,fpc_as_out4]=FPC_AS(p,A,y,mu_as4,M,opts);
t_fpc_as4=toc;
Img2D_fpc_as4=W(s_fpc_as4);
Img2D_fpc_as4=Img2D_fpc_as4+Img2Dbar;
PSNR_fpc_as4=psnr(Img2D,Img2D_fpc_as4,scale);
Nerror_fpc_as4=(norm(Img2D(:)-Img2D_fpc_as4(:)))^2/(norm(Img2D(:)))^2;

mu_as5=1e-5*max(abs(Ht(y)));
tic
[s_fpc_as5,fpc_as_out5]=FPC_AS(p,A,y,mu_as5,M,opts);
t_fpc_as5=toc;
Img2D_fpc_as5=W(s_fpc_as5);
Img2D_fpc_as5=Img2D_fpc_as5+Img2Dbar;
PSNR_fpc_as5=psnr(Img2D,Img2D_fpc_as5,scale);
Nerror_fpc_as5=(norm(Img2D(:)-Img2D_fpc_as5(:)))^2/(norm(Img2D(:)))^2;

mu_as6=1e-6*max(abs(Ht(y)));
tic
[s_fpc_as6,fpc_as_out6]=FPC_AS(p,A,y,mu_as6,M,opts);
t_fpc_as6=toc;
Img2D_fpc_as6=W(s_fpc_as6);
Img2D_fpc_as6=Img2D_fpc_as6+Img2Dbar;
PSNR_fpc_as6=psnr(Img2D,Img2D_fpc_as6,scale);
Nerror_fpc_as6=(norm(Img2D(:)-Img2D_fpc_as6(:)))^2/(norm(Img2D(:)))^2;

mu_as7=1e-7*max(abs(Ht(y)));
tic
[s_fpc_as7,fpc_as_out7]=FPC_AS(p,A,y,mu_as7,M,opts);
t_fpc_as7=toc;
Img2D_fpc_as7=W(s_fpc_as7);
Img2D_fpc_as7=Img2D_fpc_as7+Img2Dbar;
PSNR_fpc_as7=psnr(Img2D,Img2D_fpc_as7,scale);
Nerror_fpc_as7=(norm(Img2D(:)-Img2D_fpc_as7(:)))^2/(norm(Img2D(:)))^2;

mu_as8=1e-8*max(abs(Ht(y)));
tic
[s_fpc_as8,fpc_as_out8]=FPC_AS(p,A,y,mu_as8,M,opts);
t_fpc_as8=toc;
Img2D_fpc_as8=W(s_fpc_as8);
Img2D_fpc_as8=Img2D_fpc_as8+Img2Dbar;
PSNR_fpc_as8=psnr(Img2D,Img2D_fpc_as8,scale);
Nerror_fpc_as8=(norm(Img2D(:)-Img2D_fpc_as8(:)))^2/(norm(Img2D(:)))^2;

mu_as9=1e-9*max(abs(Ht(y)));
tic
[s_fpc_as9,fpc_as_out9]=FPC_AS(p,A,y,mu_as9,M,opts);
t_fpc_as9=toc;
Img2D_fpc_as9=W(s_fpc_as9);
Img2D_fpc_as9=Img2D_fpc_as9+Img2Dbar;
PSNR_fpc_as9=psnr(Img2D,Img2D_fpc_as9,scale);
Nerror_fpc_as9=(norm(Img2D(:)-Img2D_fpc_as9(:)))^2/(norm(Img2D(:)))^2;


%%%%%%%%%%%%%%%%%%%%% Solve by GPSR_BB

tau1=1e-1*max(abs(Ht(y)));
tic;
[s_GPSR1,s_GPSRdb1,objective1,times1,debias_start1,mses1]=GPSR_BB(y,H,tau1,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR1=toc;
Img2D_GPSR1=W(s_GPSR1);
Img2D_GPSR1=Img2D_GPSR1+Img2Dbar;
PSNR_GPSR1=psnr(Img2D,Img2D_GPSR1,scale);
Nerror_GPSR1=(norm(Img2D(:)-Img2D_GPSR1(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb1)
    Img2D_GPSRdb1=W(s_GPSRdb1);
    Img2D_GPSRdb1=Img2D_GPSRdb1+Img2Dbar;
    PSNR_GPSRdb1=psnr(Img2D,Img2D_GPSRdb1,scale);
    Nerror_GPSRdb1=(norm(Img2D(:)-Img2D_GPSRdb1(:)))^2/(norm(Img2D(:)))^2;
end

tau2=1e-2*max(abs(Ht(y)));
tic;
[s_GPSR2,s_GPSRdb2,objective2,times2,debias_start2,mses2]=GPSR_BB(y,H,tau2,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR2=toc;
Img2D_GPSR2=W(s_GPSR2);
Img2D_GPSR2=Img2D_GPSR2+Img2Dbar;
PSNR_GPSR2=psnr(Img2D,Img2D_GPSR2,scale);
Nerror_GPSR2=(norm(Img2D(:)-Img2D_GPSR2(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb2)
    Img2D_GPSRdb2=W(s_GPSRdb2);
    Img2D_GPSRdb2=Img2D_GPSRdb2+Img2Dbar;
    PSNR_GPSRdb2=psnr(Img2D,Img2D_GPSRdb2,scale);
    Nerror_GPSRdb2=(norm(Img2D(:)-Img2D_GPSRdb2(:)))^2/(norm(Img2D(:)))^2;
end

tau3=1e-3*max(abs(Ht(y)));
tic;
[s_GPSR3,s_GPSRdb3,objective3,times3,debias_start3,mses3]=GPSR_BB(y,H,tau3,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR3=toc;
Img2D_GPSR3=W(s_GPSR3);
Img2D_GPSR3=Img2D_GPSR3+Img2Dbar;
PSNR_GPSR3=psnr(Img2D,Img2D_GPSR3,scale);
Nerror_GPSR3=(norm(Img2D(:)-Img2D_GPSR3(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb3)
    Img2D_GPSRdb3=W(s_GPSRdb3);
    Img2D_GPSRdb3=Img2D_GPSRdb3+Img2Dbar;
    PSNR_GPSRdb3=psnr(Img2D,Img2D_GPSRdb3,scale);
    Nerror_GPSRdb3=(norm(Img2D(:)-Img2D_GPSRdb3(:)))^2/(norm(Img2D(:)))^2;
end

tau4=1e-4*max(abs(Ht(y)));
tic;
[s_GPSR4,s_GPSRdb4,objective4,times4,debias_start4,mses4]=GPSR_BB(y,H,tau4,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR4=toc;
Img2D_GPSR4=W(s_GPSR4);
Img2D_GPSR4=Img2D_GPSR4+Img2Dbar;
PSNR_GPSR4=psnr(Img2D,Img2D_GPSR4,scale);
Nerror_GPSR4=(norm(Img2D(:)-Img2D_GPSR4(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb4)
    Img2D_GPSRdb4=W(s_GPSRdb4);
    Img2D_GPSRdb4=Img2D_GPSRdb4+Img2Dbar;
    PSNR_GPSRdb4=psnr(Img2D,Img2D_GPSRdb4,scale);
    Nerror_GPSRdb4=(norm(Img2D(:)-Img2D_GPSRdb4(:)))^2/(norm(Img2D(:)))^2;
end

tau5=1e-5*max(abs(Ht(y)));
tic;
[s_GPSR5,s_GPSRdb5,objective5,times5,debias_start5,mses5]=GPSR_BB(y,H,tau5,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR5=toc;
Img2D_GPSR5=W(s_GPSR5);
Img2D_GPSR5=Img2D_GPSR5+Img2Dbar;
PSNR_GPSR5=psnr(Img2D,Img2D_GPSR5,scale);
Nerror_GPSR5=(norm(Img2D(:)-Img2D_GPSR5(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb5)
    Img2D_GPSRdb5=W(s_GPSRdb5);
    Img2D_GPSRdb5=Img2D_GPSRdb5+Img2Dbar;
    PSNR_GPSRdb5=psnr(Img2D,Img2D_GPSRdb5,scale);
    Nerror_GPSRdb5=(norm(Img2D(:)-Img2D_GPSRdb5(:)))^2/(norm(Img2D(:)))^2;
end

tau6=1e-6*max(abs(Ht(y)));
tic;
[s_GPSR6,s_GPSRdb6,objective6,times6,debias_start6,mses6]=GPSR_BB(y,H,tau6,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR6=toc;
Img2D_GPSR6=W(s_GPSR6);
Img2D_GPSR6=Img2D_GPSR6+Img2Dbar;
PSNR_GPSR6=psnr(Img2D,Img2D_GPSR6,scale);
Nerror_GPSR6=(norm(Img2D(:)-Img2D_GPSR6(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb6)
    Img2D_GPSRdb6=W(s_GPSRdb6);
    Img2D_GPSRdb6=Img2D_GPSRdb6+Img2Dbar;
    PSNR_GPSRdb6=psnr(Img2D,Img2D_GPSRdb6,scale);
    Nerror_GPSRdb6=(norm(Img2D(:)-Img2D_GPSRdb6(:)))^2/(norm(Img2D(:)))^2;
end

tau7=1e-7*max(abs(Ht(y)));
tic;
[s_GPSR7,s_GPSRdb7,objective7,times7,debias_start7,mses7]=GPSR_BB(y,H,tau7,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR7=toc;
Img2D_GPSR7=W(s_GPSR7);
Img2D_GPSR7=Img2D_GPSR7+Img2Dbar;
PSNR_GPSR7=psnr(Img2D,Img2D_GPSR7,scale);
Nerror_GPSR7=(norm(Img2D(:)-Img2D_GPSR7(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb7)
    Img2D_GPSRdb7=W(s_GPSRdb7);
    Img2D_GPSRdb7=Img2D_GPSRdb7+Img2Dbar;
    PSNR_GPSRdb7=psnr(Img2D,Img2D_GPSRdb7,scale);
    Nerror_GPSRdb7=(norm(Img2D(:)-Img2D_GPSRdb7(:)))^2/(norm(Img2D(:)))^2;
end

tau8=1e-8*max(abs(Ht(y)));
tic;
[s_GPSR8,s_GPSRdb8,objective8,times8,debias_start8,mses8]=GPSR_BB(y,H,tau8,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR8=toc;
Img2D_GPSR8=W(s_GPSR8);
Img2D_GPSR8=Img2D_GPSR8+Img2Dbar;
PSNR_GPSR8=psnr(Img2D,Img2D_GPSR8,scale);
Nerror_GPSR8=(norm(Img2D(:)-Img2D_GPSR8(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb8)
    Img2D_GPSRdb8=W(s_GPSRdb8);
    Img2D_GPSRdb8=Img2D_GPSRdb8+Img2Dbar;
    PSNR_GPSRdb8=psnr(Img2D,Img2D_GPSRdb8,scale);
    Nerror_GPSRdb8=(norm(Img2D(:)-Img2D_GPSRdb8(:)))^2/(norm(Img2D(:)))^2;
end

tau9=1e-9*max(abs(Ht(y)));
tic;
[s_GPSR9,s_GPSRdb9,objective9,times9,debias_start9,mses9]=GPSR_BB(y,H,tau9,'AT',Ht,'Debias',1,'ToleranceA',1e-5,'Verbose',0);
t_GPSR9=toc;
Img2D_GPSR9=W(s_GPSR9);
Img2D_GPSR9=Img2D_GPSR9+Img2Dbar;
PSNR_GPSR9=psnr(Img2D,Img2D_GPSR9,scale);
Nerror_GPSR9=(norm(Img2D(:)-Img2D_GPSR9(:)))^2/(norm(Img2D(:)))^2;
if ~isempty(s_GPSRdb9)
    Img2D_GPSRdb9=W(s_GPSRdb9);
    Img2D_GPSRdb9=Img2D_GPSRdb9+Img2Dbar;
    PSNR_GPSRdb9=psnr(Img2D,Img2D_GPSRdb9,scale);
    Nerror_GPSRdb9=(norm(Img2D(:)-Img2D_GPSRdb9(:)))^2/(norm(Img2D(:)))^2;
end


%%%%%%%%%%%% Setting sparsity for hard thresholding methods
slope1=10000;
r_init1=floor(slope1*Nratio);

slope2=15000;
r_init2=floor(slope2*Nratio);

%%%%%%%%%%%%%%%%%%%%% Solve by NIHT

tic;
[s_NIHT,Count_NIHT]=hard_l0_Mterm_mod(y,H,p,r_init1,thresh,'P_trans',Ht);
t_NIHT=toc;
Img2D_NIHT=W(s_NIHT);
Img2D_NIHT=Img2D_NIHT+Img2Dbar;
PSNR_NIHT=psnr(Img2D,Img2D_NIHT,scale);
Nerror_NIHT=(norm(Img2D(:)-Img2D_NIHT(:)))^2/(norm(Img2D(:)))^2;

%%%%%%%%%%%%%%%%%%%%% Solve by MB-IHT

tic;
[s_IHT_tree,Count_IHT_tree]=IHT_tree(y,H,p,r_init2,thresh,numLevels,signature,projonimage,'P_trans',Ht,'step_size',1);
t_IHT_tree=toc;
Img2D_IHT_tree=W(s_IHT_tree);
Img2D_IHT_tree=Img2D_IHT_tree+Img2Dbar;
PSNR_IHT_tree=psnr(Img2D,Img2D_IHT_tree,scale);
Nerror_IHT_tree=(norm(Img2D(:)-Img2D_IHT_tree(:)))^2/(norm(Img2D(:)))^2;

clear f

save([img_name,num2str(my),'by',num2str(mx),'_dwtLevel_',num2str(numLevels),'_MeasurementsRatio_',num2str(Nratio),'_thresh_',num2str(thresh),'.mat']);
