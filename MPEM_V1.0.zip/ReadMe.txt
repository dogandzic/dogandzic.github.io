%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        	Matlab Codes package for		    %
% A Max-Product EM Algorithm for Reconstructing Markov-tree %
%         Sparse Signals from Compressive Samples	    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Version: 1.0
Date updated: Aug. 4th, 2013

Authors: Z. Song and A. Dogandzic
The Matlab codes are written and debugged by Zhao Song.
Tested Configurations: Matlab 7.10.0 (R2010a) on PC and Linux;

The codes in this package are free program. You are welcome to 
use them for academic purposes. If you use this code in your 
research and publications, please put a reference to our paper. 

If you find any bugs or have any suggestions, please contact the 
authors through email: zhaosong@iastate.edu and/or ald@iastate.edu.

The code provided here is used to reproduce the figures corresponding 
to the experimental results in our paper.

The folder `SimulateExample' contains the code to generate Fig. 5 
and Fig. 6 in our paper.

The folder `ImageExampleCorrelation' contains the code to generate 
Fig. 7  and Fig. 8 in our paper.

The folder `ImageExampleSRM' contains the code to generate Fig. 10 
and Fig. 11 in our paper.

%%%%%%%%%%%%%%% Files list %%%%%%%%%%%%%%%%
        
--folder "Algorithms"

  "MPEM.m":		     Our core MPEM reconstruction function.
		
  "hard_l0_Mterm_mod.m":     The (normalized) iterative hard thresholding 
                             algorithms by T. Blumensath and M. E. Davies; the 
                             original file "hard_l0_Mterm.m" can be downloaded 
                             at <http://www.personal.soton.ac.uk/tb1m08/sparsify/sparsify.html> 
                             Kun Qiu has modified the original file to 
                             incorporate a more common convergence criterion.

  "GPSR_BB.m":		     The Gradient Projection for Sparse Reconstruction 
                             method by M�rio Figueiredo, Robert D. Nowak, 
                             Stephen J. Wright, downloaded at <http://www.lx.it.pt/~mtf/GPSR/>

  "IHT_tree.m":              The model-based compressive sensing algorithm by 
 			     R. Baraniuk et al.
                             Zhao Song wrote the model-based iteraitve hard 
                             thresholding version based on the "hard_l0_Mterm_mod.m" 
                             and the tree approximation algorithms provided in the 
		             "modelcs" package, which could be downloaded at 
                             <http://dsp.rice.edu/software/model-based-compressive-sensing-toolbox-v11>

  "TSWCSvb.m"*:		     The Variational Bayesian tree-structured compressive sensing
			     algorithm by L. He et al., which is downloaded at
			     <http://people.ee.duke.edu/~lcarin/BCS>

  --folder "FPC_AS" 
			     Fixed-point continuation and active set algorithm by Z. Wen, 
			     W. Yin, etc. The original software can be found at  
			     <http://www.caam.rice.edu/~optimization/L1/FPC_AS/>


--folder "hmt, turbo, utils"   
                             The folder contains the files to run turbo-AMP algorithm by 
			     S. Som and P. Schniter, downloaded at 
                             <http://www.ece.osu.edu/~schniter/turboAMPimaging>
                                        
--folder "subfunctions"
	                     The files in this folder are useful in implementing the sensing 
                             matrix H in the function handle form.
        		     This folder also contains necessary sub-functions in implementing 			     			     "IHT_tree.m" and "MPEM.m".
 


* We modified the original code of VB to approximately normalize 
the columns of sensing matrix in the same way as the latest 
turbo-AMP code did. We name this file as ``TSWCSvb_mod'', please 
check it in the ./Algorithms folder.
